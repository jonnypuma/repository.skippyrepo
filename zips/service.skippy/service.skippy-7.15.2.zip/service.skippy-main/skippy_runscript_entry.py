# -*- coding: utf-8 -*-
"""Thin RunScript entry for service.skippy.

Kodi parses the whole script file before executing. If ``segment_marker.py`` is ever
broken (syntax), ``RunScript(..., open_segment_editor)`` still must work — that handler
runs here **without** importing ``segment_marker``.

Marker hotkey runs ``RunScript(service.skippy)`` with no args; that path imports
``segment_marker`` normally.
"""

import sys


def _addon():
    import xbmcaddon

    try:
        return xbmcaddon.Addon("service.skippy")
    except Exception:
        return None


def main():
    if len(sys.argv) > 1:
        command = (sys.argv[1] or "").strip().lower()

        # --- Editor / keymap / settings (no dependency on parsing segment_marker.py) ---
        if command == "open_segment_editor":
            from segment_editor_session import open_segment_editor

            open_segment_editor()
            return
        if command == "discover_editor_button":
            from segment_editor import discover_editor_remote_button

            addon = _addon()
            if addon:
                discover_editor_remote_button(addon)
            return
        if command == "install_editor_keymap":
            from keymap_utils import install_editor_keymap

            addon = _addon()
            install_editor_keymap(addon if addon else None, notify=True)
            return

        # --- Marker installer / discovery (heavy UI lives in segment_marker) ---
        if command == "discover_button":
            import segment_marker

            addon = segment_marker.get_addon()
            if addon:
                segment_marker.discover_remote_button(addon)
            return
        if command == "install_keymap":
            import segment_marker
            from keymap_utils import install_marker_keymap

            addon = segment_marker.get_addon()
            install_marker_keymap(addon if addon else None, notify=True)
            return

        # --- Statistics / per-title overrides ---
        if command in ("next_episode_play", "next_episode_close"):
            # Buttons of a skin's own next episode popup; the service answers the prompt.
            import xbmc

            xbmc.executebuiltin("NotifyAll(service.skippy,%s)" % command)
            return
        if command == "skip_current":
            # The service does the skip (it knows the segments and counts it); a
            # notification reaches it within a second.
            import xbmc

            xbmc.executebuiltin("NotifyAll(service.skippy,skip_current)")
            return
        if command == "show_diagnostics":
            from skippy_diagnostics_ui import show_diagnostics_modal

            show_diagnostics_modal()
            return
        if command == "show_statistics":
            from skippy_statistics_ui import show_statistics_modal

            show_statistics_modal()
            return
        if command == "reset_statistics":
            from skippy_statistics_ui import confirm_and_reset_statistics

            confirm_and_reset_statistics()
            return
        if command == "manage_show_overrides":
            from per_show_overrides_ui import show_manage_title_autoskip_modal

            show_manage_title_autoskip_modal()
            return
        if command == "manage_next_episode_shows":
            from next_episode_shows_ui import show_manage_next_episode_shows_modal

            show_manage_next_episode_shows_modal()
            return
        if command == "clear_next_episode_shows":
            from next_episode_shows import clear_all
            from settings_utils import get_localized, notify_skippy

            addon = _addon()
            removed = clear_all()
            if removed:
                message = get_localized(
                    addon, 47102, "Cleared %d saved autoplay choice(s).", removed
                )
            else:
                message = get_localized(
                    addon, 47103, "No saved autoplay choices to clear."
                )
            notify_skippy(
                addon, message, title=get_localized(addon, 43000, "Skippy")
            )
            return
        if command == "customize_skip_dialog":
            from skip_dialog_customize_ui import show_skip_dialog_customize

            show_skip_dialog_customize()
            return
        if command == "customize_next_episode_popup":
            from next_episode_customize_ui import show_next_episode_customize

            show_next_episode_customize()
            return
        if command == "label_width_probe":
            from skip_label_width_probe import run_label_width_probe

            run_label_width_probe()
            return
        if command == "skip_dialog_presets":
            from skip_dialog_presets_ui import show_skip_dialog_presets_menu

            show_skip_dialog_presets_menu()
            return
        if command == "edit_segment_types":
            from segment_types_editor_ui import show_segment_types_editor

            show_segment_types_editor()
            return
        if command == "clear_show_overrides":
            from per_show_overrides import clear_all_overrides
            from settings_utils import get_localized, notify_skippy

            addon = _addon()
            removed = clear_all_overrides()
            if removed:
                message = get_localized(
                    addon, 44009, "Cleared %d saved per-title choice(s).", removed
                )
            else:
                message = get_localized(
                    addon, 44010, "No saved per-title choices to clear."
                )
            notify_skippy(
                addon, message, title=get_localized(addon, 43000, "Skippy")
            )
            return

        # --- Backup / restore (delegated modules only) ---
        if command == "backup_settings":
            from settings_backup import run_backup_ui
            from settings_utils import skippy_notification_icon

            import segment_marker

            addon = segment_marker.get_addon()
            if addon:
                run_backup_ui(
                    addon,
                    skippy_notification_icon(addon) or "",
                    segment_marker.log,
                )
            return
        if command == "restore_settings":
            from settings_backup import run_restore_ui
            from settings_utils import skippy_notification_icon

            import segment_marker

            addon = segment_marker.get_addon()
            if addon:
                run_restore_ui(
                    addon,
                    skippy_notification_icon(addon) or "",
                    segment_marker.log,
                )
            return
        if command in ("backup_profile_data", "backup_upload_history"):
            from skippy_profile_backup import run_backup_ui
            from settings_utils import skippy_notification_icon

            import segment_marker

            addon = segment_marker.get_addon()
            if addon:
                run_backup_ui(
                    addon,
                    skippy_notification_icon(addon) or "",
                    segment_marker.log,
                )
            return
        if command in ("restore_profile_data", "restore_upload_history"):
            from skippy_profile_backup import run_restore_ui
            from settings_utils import skippy_notification_icon

            import segment_marker

            addon = segment_marker.get_addon()
            if addon:
                run_restore_ui(
                    addon,
                    skippy_notification_icon(addon) or "",
                    segment_marker.log,
                )
            return

        if command:
            # A command this version does not know (a typo, an old or future button, another
            # add-on or skin calling Skippy): do nothing. Only the hotkey, which passes no
            # command, may mark a segment.
            _log_unknown_command(command)
            return

    import segment_marker

    segment_marker.main()


def _log_unknown_command(command):
    try:
        import xbmc

        xbmc.log(
            "[service.skippy] RunScript: unknown command %r ignored (no segment marked)" % command,
            xbmc.LOGWARNING,
        )
    except Exception:
        pass


if __name__ == "__main__":
    main()
