# -*- coding: utf-8 -*-
"""Skip dialog orchestration and auto-skip for active segments."""

from __future__ import annotations

import time
import traceback
from typing import Any

import xbmc
import xbmcgui

from segment_item import segments_active_for_playback
from segment_editor_utils import get_home_window
from segment_relations import segment_id
from service_loop_per_show import (
    apply_per_show_override,
    maybe_prompt_per_show_override,
)
from skippy_stats import record_skip
from settings_utils import (
    addon_get_bool,
    addon_get_int,
    addon_get_setting_text,
    compute_skip_seek_destination_seconds,
    format_segment_label_for_ui,
    get_addon,
    get_localized,
    get_user_skip_mode,
    is_skip_enabled,
    log,
    log_service_detail,
)
from service_skip_seek_property import mark_skippy_skipping
from skip_dialog_native import is_native_skip_dialog, show_native_skip_dialog
from skipdialog import SkipDialog


# Max chained seeks in one tick (recap→intro→…); prevents runaway auto-skip loops.
_MAX_SKIP_CHAIN_DEPTH = 8
# Refuse re-opening ask for the same seg_id within this window (anti-spam).
ASK_SAME_SEG_COOLDOWN_S = 0.3


def clear_last_skipped_segment(monitor) -> None:
    monitor.last_skipped_seg_id = None
    monitor.last_skipped_seg_bounds = None


def mark_last_skipped_segment(monitor, segment, seg_id) -> None:
    """Remember a Skippy skip so keyframe snap back into the same window is ignored."""
    monitor.last_skipped_seg_id = seg_id
    monitor.last_skipped_seg_bounds = (
        float(segment.start_seconds),
        float(segment.end_seconds),
    )


def _player_time_or(ctx, fallback):
    try:
        return float(ctx.player.getTime())
    except (RuntimeError, TypeError, ValueError):
        return float(fallback)


def _record_skip_stats(segment, position_before, jump_to) -> None:
    """Count the skip and the playback time it actually saved."""
    try:
        saved = max(0.0, float(jump_to) - float(position_before))
    except (TypeError, ValueError):
        saved = 0.0
    record_skip(getattr(segment, "segment_type_label", ""), saved)


def _resolved_seek_land(jump_to, actual_time) -> float:
    """Prefer the playhead after seekTime; fall back to the requested target."""
    try:
        actual = float(actual_time)
    except (TypeError, ValueError):
        actual = -1.0
    if actual >= 0.0:
        return actual
    return float(jump_to)


def _skipped_bounds(monitor):
    bounds = getattr(monitor, "last_skipped_seg_bounds", None)
    if not isinstance(bounds, (tuple, list)) or len(bounds) != 2:
        return None
    try:
        return float(bounds[0]), float(bounds[1])
    except (TypeError, ValueError):
        return None


def clear_last_skipped_if_outside(monitor, current_time: float) -> None:
    bounds = _skipped_bounds(monitor)
    if not bounds:
        return
    start, end = bounds
    t = float(current_time)
    if t < start or t > end:
        clear_last_skipped_segment(monitor)


def should_ignore_as_just_skipped(monitor, seg_id, current_time: float) -> bool:
    """True while playhead is still inside the segment we just Skippy-skipped."""
    if getattr(monitor, "last_skipped_seg_id", None) != seg_id:
        return False
    bounds = _skipped_bounds(monitor)
    if not bounds:
        return False
    start, end = bounds
    t = float(current_time)
    return start <= t <= end


def ask_still_valid_after_wait(ctx, segment) -> bool:
    """Re-check the world after any wait: still playing, playhead still in the segment."""
    monitor = ctx.monitor
    try:
        playing = ctx.player.isPlayingVideo()
        paused = xbmc.getCondVisibility("Player.Paused")
    except RuntimeError:
        return False
    # Kodi briefly reports Paused right after our own seek.
    grace = getattr(monitor, "skippy_skipping_since", None) is not None
    if not playing or (paused and not grace):
        return False
    try:
        now = float(ctx.player.getTime())
    except (RuntimeError, TypeError, ValueError):
        return True
    start = float(getattr(segment, "start_seconds", 0) or 0)
    end = float(getattr(segment, "end_seconds", 0) or 0)
    return (start - 0.5) <= now <= end


def ask_same_seg_on_cooldown(monitor, seg_id) -> bool:
    last_id = getattr(monitor, "last_ask_seg_id", None)
    last_mono = getattr(monitor, "last_ask_mono", None)
    if last_id != seg_id or last_mono is None:
        return False
    try:
        return (time.monotonic() - float(last_mono)) < ASK_SAME_SEG_COOLDOWN_S
    except (TypeError, ValueError):
        return False


def stamp_ask_opened(monitor, seg_id) -> None:
    monitor.last_ask_seg_id = seg_id
    monitor.last_ask_mono = time.monotonic()


def process_segment_skips(
    ctx: Any,
    *,
    video: str,
    playback_type: str,
    show_dialogs: bool,
    current_time: float,
    major_rewind_detected: bool,
    _chain_depth: int = 0,
    _skip_ask_debounce: bool = False,
) -> None:
    monitor = ctx.monitor
    addon = get_addon()

    if not monitor.playback_ready:
        ctx.log_if_changed(
            "playback_ready", "⏳ Playback not ready — waiting before processing segments"
        )
        monitor.last_time = current_time
        return

    clear_last_skipped_if_outside(monitor, current_time)

    segments_to_process = monitor.current_segments
    if major_rewind_detected:
        log("🔄 Major rewind detected — re-evaluating all segments for active dialogs")
        monitor._last_log_state.clear()

    ctx.log_if_changed(
        "state_summary",
        "📊 Current state: prompted=%d items, recently_dismissed=%d items, skipped_to_nested=%d items"
        % (
            len(monitor.prompted),
            len(monitor.recently_dismissed),
            len(monitor.skipped_to_nested_segment),
        ),
    )

    active_for_playback = segments_active_for_playback(monitor.current_segments, current_time)
    active_playback_ids = {segment_id(s) for s in active_for_playback}

    land_time = None

    for segment in segments_to_process:
        seg_id = segment_id(segment)

        if should_ignore_as_just_skipped(monitor, seg_id, current_time):
            ctx.log_if_changed(
                "just_skipped_%s" % (seg_id,),
                "🚫 Segment %s (%s) ignored — still inside just-skipped window"
                % (seg_id, segment.segment_type_label),
            )
            continue

        if seg_id in monitor.recently_dismissed:
            ctx.log_if_changed(
                "dismissed_%s" % (seg_id,),
                "🚫 Segment %s (%s) was dismissed — skipping ALL processing"
                % (seg_id, segment.segment_type_label),
            )
            monitor.prompted.add(seg_id)
            continue

        if seg_id in monitor.prompted:
            continue

        if seg_id not in active_playback_ids:
            continue

        if ctx.should_suppress_segment_dialog(
            segment,
            monitor.current_segments,
            current_time,
            monitor.recently_dismissed,
        ):
            ctx.log_if_changed(
                "suppressed_%s" % (seg_id,),
                "🚫 Segment %s dialog suppressed due to overlapping/nested segment priority"
                % (seg_id,),
            )
            continue

        if seg_id in monitor.skipped_to_nested_segment:
            nested_segment = monitor.skipped_to_nested_segment[seg_id]
            if nested_segment.is_active(current_time):
                ctx.log_if_changed(
                    "nested_%s" % (seg_id,),
                    "🚫 Segment %s dialog suppressed — still in nested segment '%s'"
                    % (seg_id, nested_segment.segment_type_label),
                )
                continue
            nested_seg_id_defensive = segment_id(nested_segment)
            if nested_seg_id_defensive in monitor.recently_dismissed:
                monitor.recently_dismissed.remove(nested_seg_id_defensive)
            del monitor.skipped_to_nested_segment[seg_id]
            if seg_id not in monitor.recently_dismissed and seg_id in monitor.prompted:
                monitor.prompted.remove(seg_id)

        ctx.log_if_changed(
            "active_seg_%s" % (seg_id,),
            "🔎 Processing active segment: '%s' [%s-%s]"
            % (
                segment.segment_type_label,
                segment.start_seconds,
                segment.end_seconds,
            ),
        )
        behavior = apply_per_show_override(
            monitor,
            addon,
            video,
            segment.segment_type_label,
            get_user_skip_mode(segment.segment_type_label),
        )
        ctx.log_if_changed(
            "behavior_%s" % (seg_id,),
            "🧪 Segment behavior: %s" % behavior,
        )

        if behavior == "never":
            ctx.log_if_changed(
                "never_%s" % (seg_id,),
                "🚫 Skipping dialog for '%s' (never)" % segment.segment_type_label,
            )
            # Mark prompted so we do not re-resolve skip mode every monitor tick.
            monitor.prompted.add(seg_id)
            continue

        if not is_skip_enabled(playback_type):
            log("🚫 Skipping disabled for %s — segment %s" % (playback_type, seg_id))
            monitor.prompted.add(seg_id)
            continue

        ctx.log_if_changed(
            "active_behavior_%s" % (seg_id,),
            "🕒 Active segment: %s [%s-%s] → %s"
            % (
                segment.segment_type_label,
                segment.start_seconds,
                segment.end_seconds,
                behavior,
            ),
        )

        jump_to = compute_skip_seek_destination_seconds(segment, addon)

        if behavior == "auto":
            landed = _handle_auto_skip(ctx, segment, seg_id, jump_to, addon)
            if landed is not None:
                land_time = landed
                break
        elif not show_dialogs:
            ctx.log_if_changed(
                "dialogs_disabled_%s" % (seg_id,),
                "🚫 Skip dialogs disabled — suppressing ask for segment %s" % (seg_id,),
            )
            monitor.prompted.add(seg_id)
            continue
        elif behavior == "ask":
            landed = _handle_ask_skip(
                ctx,
                segment,
                seg_id,
                jump_to,
                addon,
                video=video,
                skip_debounce=_skip_ask_debounce,
            )
            if landed is not None:
                land_time = landed
                break

    if (
        land_time is not None
        and _chain_depth < _MAX_SKIP_CHAIN_DEPTH
        and monitor.playback_ready
    ):
        log_service_detail(
            "⛓️ Chaining skip processing at %.2fs (depth %d)"
            % (land_time, _chain_depth + 1),
            tag="playback",
        )
        process_segment_skips(
            ctx,
            video=video,
            playback_type=playback_type,
            show_dialogs=show_dialogs,
            current_time=float(land_time),
            major_rewind_detected=False,
            _chain_depth=_chain_depth + 1,
            _skip_ask_debounce=True,
        )

    if _chain_depth == 0:
        pending = getattr(monitor, "pending_per_show_override", None)
        if isinstance(pending, tuple) and len(pending) >= 2:
            monitor.pending_per_show_override = None
            maybe_prompt_per_show_override(ctx, addon, pending[0], pending[1])


# next_segment_start is assigned from start_seconds in-process; allow a tiny
# float gap so nested rewind bookkeeping is not dropped on a rounding mismatch.
_NESTED_START_MATCH_S = 0.05


def _segment_start_times_match(left, right, tol=_NESTED_START_MATCH_S) -> bool:
    try:
        return abs(float(left) - float(right)) <= float(tol)
    except (TypeError, ValueError):
        return False


def _track_skip_to_nested(ctx: Any, segment, seg_id) -> None:
    monitor = ctx.monitor
    if segment.next_segment_start is None:
        return
    target_segment = None
    for seg in monitor.current_segments:
        if _segment_start_times_match(seg.start_seconds, segment.next_segment_start):
            target_segment = seg
            break
    if not target_segment or not ctx.is_nested_segment(segment, target_segment):
        return
    monitor.skipped_to_nested_segment[seg_id] = target_segment
    monitor.prompted.add(seg_id)
    if seg_id in monitor.recently_dismissed:
        nested_seg_id = segment_id(target_segment)
        clearance_key = (seg_id, nested_seg_id)
        if clearance_key not in monitor.cleared_parent_dismissals:
            monitor.recently_dismissed.remove(seg_id)
            monitor.cleared_parent_dismissals.add(clearance_key)


def _handle_auto_skip(ctx: Any, segment, seg_id, jump_to, addon) -> float | None:
    monitor = ctx.monitor
    log(
        "⚙ Auto-skip behavior triggered for segment ID %s (%s)"
        % (seg_id, segment.segment_type_label)
    )
    _track_skip_to_nested(ctx, segment, seg_id)
    log_service_detail("🎯 Auto-skip: Issuing seekTime(%s) now..." % jump_to, tag="playback")
    position_before = _player_time_or(ctx, segment.start_seconds)
    mark_skippy_skipping(monitor, addon)
    ctx.player.seekTime(jump_to)
    try:
        actual_time = ctx.player.getTime() if ctx.player.isPlaying() else -1
    except RuntimeError:
        actual_time = -1
    log_service_detail(
        "🎯 Auto-skip: After seek: requested=%s, actual=%s" % (jump_to, actual_time),
        tag="playback",
    )
    land = float(jump_to)
    monitor.last_time = land
    mark_last_skipped_segment(monitor, segment, seg_id)
    if seg_id not in monitor.prompted:
        monitor.prompted.add(seg_id)
    _record_skip_stats(
        segment, position_before, _resolved_seek_land(jump_to, actual_time)
    )
    _maybe_show_skip_toast(ctx, addon, segment, "auto")
    log("⚡ Auto-skipped to %s" % jump_to)
    return land


def _handle_ask_skip(
    ctx: Any,
    segment,
    seg_id,
    jump_to,
    addon,
    *,
    video: str = "",
    skip_debounce: bool = False,
) -> float | None:
    monitor = ctx.monitor
    log(
        "🧠 Ask-skip behavior triggered for segment ID %s (%s)"
        % (seg_id, segment.segment_type_label)
    )

    try:
        dialog_is_playing = ctx.player.isPlayingVideo()
        dialog_is_paused = xbmc.getCondVisibility("Player.Paused")
    except RuntimeError:
        dialog_is_playing = False
        dialog_is_paused = True

    # After seekTime, Kodi often reports Paused briefly; allow ask while we hold
    # Skippy.Skipping so chained intro/recap dialogs are not deferred a full tick.
    post_skip_grace = getattr(monitor, "skippy_skipping_since", None) is not None
    if (dialog_is_paused or not dialog_is_playing) and not post_skip_grace:
        log("⏸️ Video paused/stopped right before dialog — skipping segment %s" % (seg_id,))
        return None

    try:
        home = get_home_window(ctx.monitor)
        editor_modal_open = (
            home is not None
            and home.getProperty("skippy_editor_modal_open") == "true"
        )
    except RuntimeError:
        editor_modal_open = False
    if editor_modal_open:
        ctx.log_if_changed(
            "skip_dlg_segment_editor_open",
            "⏸️ Skip dialog suppressed — Segment Editor is open",
        )
        return None

    if monitor.skip_dialog_modal_active:
        ctx.log_if_changed(
            "skip_dialog_in_flight",
            "⏳ Skip dialog already active — skipping duplicate ask for segment %s"
            % (seg_id,),
        )
        return None

    if ask_same_seg_on_cooldown(monitor, seg_id):
        ctx.log_if_changed(
            "ask_cooldown_%s" % (seg_id,),
            "⏳ Ask cooldown — same segment %s refused within %.0fms"
            % (seg_id, ASK_SAME_SEG_COOLDOWN_S * 1000),
        )
        return None

    monitor.skip_dialog_modal_active = True
    stamp_ask_opened(monitor, seg_id)
    try:
        debounce_ms = addon_get_int(addon, "ask_dialog_debounce_ms", 0, minimum=0, maximum=500)
        if debounce_ms > 0 and not skip_debounce:
            log("🛑 Debouncing skip dialog for %dms" % debounce_ms)
            xbmc.sleep(debounce_ms)
            if not ask_still_valid_after_wait(ctx, segment):
                log(
                    "⏸️ Playback changed during the %dms settle delay — not opening dialog for segment %s"
                    % (debounce_ms, seg_id)
                )
                return None

        if is_native_skip_dialog(addon):
            log("📐 Using native skip dialog (skin Yes/No)")
            response = show_native_skip_dialog(addon, segment, ctx.player)
        else:
            dialog_mode = (
                addon_get_setting_text(addon, "skip_dialog_mode", "Full") or "Full"
            ).strip()
            if dialog_mode == "Minimal":
                layout_value = ctx.skip_dialog_layout_suffix(addon, "minimal_skip_dialog_position")
                dialog_name = "Minimal_Skip_Dialog_%s.xml" % layout_value
            else:
                layout_value = ctx.skip_dialog_layout_suffix(addon, "skip_dialog_position")
                dialog_name = "SkipDialog_%s.xml" % layout_value
            log("📐 Using skip dialog (%s): %s" % (dialog_mode, dialog_name))

            try:
                ctx.warm_skip_dialog_skin_textures(addon)
            except Exception as e:
                log("⚠️ Failed to update skip dialog skin XML: %s" % e)

            try:
                dialog = SkipDialog(
                    dialog_name, addon.getAddonInfo("path"), "default", segment=segment
                )
            except Exception as e:
                log("❌ Failed to create skip dialog: %s" % e)
                monitor.prompted.add(seg_id)
                return None

            try:
                dialog.doModal()
            except Exception as e:
                log("❌ Dialog doModal() failed: %s" % e)
                monitor.prompted.add(seg_id)
                return None

            response = getattr(dialog, "_skippy_dialog_result", None)
            if response is None:
                response = getattr(dialog, "response", None)
            try:
                del dialog
            except Exception:
                pass

        log(
            "Skip dialog closed: response=%r jump_to=%s seg=%s"
            % (response, jump_to, seg_id)
        )

        if response is not False and response is not None:
            log("✅ User confirmed skip for segment ID %s" % (seg_id,))
            _track_skip_to_nested(ctx, segment, seg_id)
            if seg_id not in monitor.prompted:
                monitor.prompted.add(seg_id)
            log_service_detail("🎯 Issuing seekTime(%s) now..." % jump_to, tag="playback")
            position_before = _player_time_or(ctx, segment.start_seconds)
            try:
                mark_skippy_skipping(monitor, addon)
                ctx.player.seekTime(float(jump_to))
            except (TypeError, ValueError, RuntimeError) as exc:
                log("❌ seekTime(%s) failed: %s" % (jump_to, exc))
                return None
            try:
                actual_time = ctx.player.getTime() if ctx.player.isPlaying() else -1
            except RuntimeError:
                actual_time = -1
            log_service_detail(
                "🎯 After seek: requested=%s, actual=%s" % (jump_to, actual_time),
                tag="playback",
            )
            land = float(jump_to)
            monitor.last_time = land
            mark_last_skipped_segment(monitor, segment, seg_id)
            _record_skip_stats(
                segment, position_before, _resolved_seek_land(jump_to, actual_time)
            )
            _maybe_show_skip_toast(ctx, addon, segment, "confirmed")
            log("🚀 Jumped to %s" % jump_to)
            monitor.pending_per_show_override = (segment, video)
            return land
        elif response is False:
            log("🙅 User dismissed skip dialog for segment ID %s" % (seg_id,))
            monitor.recently_dismissed.add(seg_id)
            monitor.prompted.add(seg_id)
        else:
            log(
                "⚠ Skip dialog closed without a choice for segment %s — will retry"
                % (seg_id,)
            )
    except RuntimeError as e:
        log("❌ Error showing skip dialog (RuntimeError): %s" % e)
        monitor.prompted.add(seg_id)
    except Exception as e:
        log(
            "❌ Error showing skip dialog (%s): %s\n%s"
            % (type(e).__name__, e, traceback.format_exc())
        )
        monitor.prompted.add(seg_id)
    finally:
        monitor.skip_dialog_modal_active = False
    return None


def _maybe_show_skip_toast(ctx: Any, addon, segment, reason: str) -> None:
    if not addon_get_bool(addon, "show_toast_for_skipped_segment", False):
        log("🔕 Skipped segment toast disabled by user setting")
        return
    log("🔔 Showing toast notification for %s skip" % reason)
    try:
        xbmcgui.Dialog().notification(
            heading=get_localized(addon, 43003, "Skipped"),
            message=get_localized(
                addon, 43004, "%s skipped", format_segment_label_for_ui(segment.segment_type_label)
            ),
            icon=ctx.icon_path,
            time=2000,
            sound=False,
        )
    except Exception as e:
        log("❌ Failed to display skip toast notification: %s" % e)
