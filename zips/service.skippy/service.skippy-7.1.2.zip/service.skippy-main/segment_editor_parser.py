import copy
import os
import stat
import subprocess
import time
import xml.etree.ElementTree as ET
import xbmcvfs
import unicodedata

from edl_format import EDL_DEFAULT_ACTION, parse_edl_line
from segment_editor_utils import get_addon, log
from segment_types import edl_write_action
from settings_utils import get_edl_type_map

# Re-exported: editor/marker/upload modules import these from here.
from time_format import hms_to_seconds, seconds_to_edl, seconds_to_hms  # noqa: F401

# Matroska-style chapter sidecars next to ``video.mkv`` (also used by ``service`` / Segment Marker).
CHAPTER_XML_SIDECAR_SUFFIXES = (
    "_chapters.xml",
    "-chapters.xml",
    ".chapters.xml",
    "-chapter.xml",
    "_chapter.xml",
    ".chapter.xml",
)
DEFAULT_NEW_CHAPTER_XML_SUFFIX = "_chapters.xml"


def normalize_matroska_chapter_xml_text(xml_data):
    """
    Fix common chapter XML issues so ElementTree can parse:
    UTF-8 BOM, whitespace/newlines before the XML declaration, and a duplicate
    ``<?xml ...?>`` immediately after the first (invalid but seen in the wild).
    """
    if xml_data is None:
        return ""
    if isinstance(xml_data, bytes):
        s = xml_data.decode("utf-8", errors="replace")
    else:
        s = str(xml_data)
    s = s.replace("\ufeff", "")
    s = s.lstrip(" \t\r\n")
    if not s:
        return s
    low = s.lower()
    if low.startswith("<?xml"):
        close1 = s.find("?>")
        if close1 != -1:
            tail_rest = s[close1 + 2 :]
            tail_stripped = tail_rest.lstrip(" \t\r\n")
            if tail_stripped.lower().startswith("<?xml"):
                close2 = tail_stripped.find("?>")
                if close2 != -1:
                    s = (
                        s[: close1 + 2]
                        + "\n"
                        + tail_stripped[close2 + 2 :].lstrip(" \t\r\n")
                    )
    return s


def _apply_skippy_file_permissions(path):
    """Apply Default / 644 / 666 from Skippy settings (same as segment marker)."""
    try:
        addon = get_addon()
        perm = (addon.getSetting("segment_editor_file_permissions") or "Default").strip()
    except Exception:
        return
    if perm == "Default" or not perm:
        return
    if path.startswith("nfs://") or path.startswith("smb://") or "://" in path:
        log(f"Skipping chmod for non-local path: {path}")
        return
    try:
        if perm == "644":
            os.chmod(
                path,
                stat.S_IRUSR
                | stat.S_IWUSR
                | stat.S_IRGRP
                | stat.S_IROTH,
            )
        elif perm == "666":
            os.chmod(
                path,
                stat.S_IRUSR
                | stat.S_IWUSR
                | stat.S_IRGRP
                | stat.S_IWGRP
                | stat.S_IROTH
                | stat.S_IWOTH,
            )
        else:
            return
        log(f"Applied permissions {perm} to {path}")
    except Exception as chmod_err:
        log(f"Could not set permissions ({chmod_err}) for {path}")


def remap_nfs_path_for_write(path):
    """Return a list of NFS path variations to try when writing.

    Kodi's NFS client sometimes strips subdirectories from mount paths on
    write; trying a few variants gives us a chance to recover automatically.
    """
    if not path.startswith('nfs://'):
        return [path]

    variations = [path]
    try:
        parts = path.split('/', 4)
        if len(parts) >= 5:
            remapped = f"{parts[0]}//{parts[2]}/{parts[4]}"
            variations.append(remapped)
            log(f"NFS path remap variation: {remapped}")
    except Exception:
        pass

    try:
        parts = path.split('/')
        if len(parts) >= 4:
            filename = parts[-1]
            server_part = '/'.join(parts[:3])
            root_path = f"{server_part}/{filename}"
            if root_path not in variations:
                variations.append(root_path)
                log(f"NFS path remap variation (root): {root_path}")
    except Exception:
        pass

    return variations


def safe_file_write(path, content, is_bytes=False):
    """Safely write a file using Kodi's VFS, falling back through NFS remaps.

    Returns ``(success, bytes_written_or_None)``.
    """
    if not is_bytes and isinstance(content, str):
        content_bytes = content.encode('utf-8')
    else:
        content_bytes = content

    path_variations = remap_nfs_path_for_write(path)
    last_error = None

    for attempt_path in path_variations:
        try:
            log(f"Attempting to write to: {attempt_path}")

            # Kodi VFS may not truncate on overwrite (NFS, SMB, some local backends);
            # delete first so a shorter file does not leave stale bytes at EOF.
            if xbmcvfs.exists(attempt_path):
                try:
                    log(f"Deleting existing file before write: {attempt_path}")
                    xbmcvfs.delete(attempt_path)
                    time.sleep(0.05)
                except Exception as del_err:
                    log(f"Could not delete existing file before write: {del_err}")

            f = xbmcvfs.File(attempt_path, 'w')
            if not f:
                log(f"Failed to create file object for: {attempt_path}")
                last_error = "Failed to create file object"
                continue

            result = f.write(content_bytes)
            f.close()

            # Kodi VFS may return bytes-written, True, None or False. Always
            # verify with xbmcvfs.exists() as a fallback check.
            if result or xbmcvfs.exists(attempt_path):
                if xbmcvfs.exists(attempt_path):
                    _apply_skippy_file_permissions(attempt_path)
                    if attempt_path != path:
                        log(f"Write succeeded with remapped path: {attempt_path} (original: {path})")
                    else:
                        log(f"Write succeeded: {path}")
                    written = result if isinstance(result, int) else len(content_bytes)
                    return True, written
                log(f"Write returned {result!r} but file doesn't exist: {attempt_path}")
                if attempt_path.startswith('nfs://') and attempt_path != path_variations[-1]:
                    log("NFS write apparently failed, trying next path variation")
                    continue

        except Exception as e:
            last_error = e
            error_msg = str(e)
            log(f"Write exception for {attempt_path}: {error_msg}")
            if ("NFS" in error_msg or "ACCESS denied" in error_msg or "NFS3ERR" in error_msg):
                if attempt_path != path_variations[-1]:
                    log("NFS error detected, trying next path variation")
                    continue
            if attempt_path == path_variations[-1]:
                break

    if last_error:
        log(f"All write attempts failed. Last error: {last_error}")
    else:
        log("All write attempts failed. Write() returned no bytes for all paths.")
        if path.startswith('nfs://'):
            log("NFS write issue detected. Check: (1) server 'rw' export, "
                "(2) 'insecure' flag, (3) path normalization in Kodi NFS client.")
    return False, None


def normalize_label(text):
    """Normalize and lowercase labels for consistent matching."""
    return unicodedata.normalize("NFKC", text or "").strip().lower()


def indent_xml(elem, level=0, indent="  "):
    """Manually indent an ElementTree (Python 3.8 compatible)."""
    i = "\n" + level * indent
    if len(elem):
        if not elem.text or not elem.text.strip():
            elem.text = i + indent
        if not elem.tail or not elem.tail.strip():
            elem.tail = i
        for child in elem:
            indent_xml(child, level + 1, indent)
        if not child.tail or not child.tail.strip():
            child.tail = i
    else:
        if level and (not elem.tail or not elem.tail.strip()):
            elem.tail = i


class SegmentItem:
    def __init__(self, start_seconds, end_seconds, label="segment", source="edl", action_type=None):
        start_seconds = float(start_seconds)
        end_seconds = float(end_seconds)

        if start_seconds < 0 or end_seconds < 0:
            raise ValueError(
                f"Segment times must be non-negative (got start={start_seconds}, end={end_seconds})"
            )
        if end_seconds <= start_seconds:
            raise ValueError(
                f"Segment end time ({end_seconds}) must be strictly after start time ({start_seconds})"
            )

        self.start_seconds = start_seconds
        self.end_seconds = end_seconds
        self.source = source
        self.segment_type_label = normalize_label(label)
        self.action_type = action_type
        self.raw_label = label

    def is_active(self, current_time):
        return self.start_seconds <= current_time <= self.end_seconds

    def get_duration(self):
        return self.end_seconds - self.start_seconds

    def __str__(self):
        return f"{self.raw_label} [{self.start_seconds:.2f}-{self.end_seconds:.2f}]"


def safe_file_read(*paths):
    """Read the first readable path. Returns content or None."""
    from service_sidecar_paths import vfs_file_exists

    for path in paths:
        if not path:
            continue
        log(f"Attempting to read: {path}")
        if not vfs_file_exists(path):
            continue
        try:
            f = xbmcvfs.File(path)
            content = f.read()
            f.close()
            if isinstance(content, bytes):
                content = content.decode('utf-8', errors='replace')
            if content:
                log(f"Successfully read file: {path}")
                return content
        except Exception as e:
            log(f"Failed to read {path}: {e}")
    return None


def _segments_from_chapter_xml(xml_data, source_label):
    """Parse Matroska-style chapter XML into SegmentItems; empty list if none."""
    normalized = normalize_matroska_chapter_xml_text(xml_data)
    try:
        root = ET.fromstring(normalized)
    except Exception as e:
        log(f"XML parse failed ({source_label}): {e}")
        return []

    result = []
    for atom in root.findall(".//ChapterAtom"):
        raw_label = atom.findtext(".//ChapterDisplay/ChapterString", default="")
        label = raw_label.strip() if raw_label else "segment"
        start = atom.findtext("ChapterTimeStart")
        end = atom.findtext("ChapterTimeEnd")
        if start and end:
            try:
                result.append(SegmentItem(
                    hms_to_seconds(start),
                    hms_to_seconds(end),
                    label,
                    source="xml"
                ))
                log(f"Parsed XML segment: {start} -> {end} | label='{label}' ({source_label})")
            except ValueError as ve:
                log(f"Skipping invalid chapter atom ({source_label}): {ve}")
    return result


def parse_chapters(video_path):
    """Parse chapter XML file and return list of SegmentItem objects.

    Tries each known sidecar path in order (sibling layouts, then ``.chapters/`` Jellyfin exporter).
    If the first file with content yields no ChapterAtom segments (placeholder or different schema),
    later paths are still tried so XML is preferred over falling back to EDL.
    """
    try:
        from service_sidecar_paths import (
            _chapter_xml_paths_to_try,
            existing_paths_from_listing,
            vfs_file_exists,
        )

        paths_to_try = list(_chapter_xml_paths_to_try(video_path))
        listed, unknown = existing_paths_from_listing(paths_to_try)
        paths_to_try = listed + [p for p in unknown if vfs_file_exists(p)]
    except ImportError:
        base = os.path.splitext(video_path)[0]
        video_dir = os.path.dirname(video_path)
        suffixes = list(CHAPTER_XML_SIDECAR_SUFFIXES)
        paths_to_try = [f"{base}{s}" for s in suffixes]
        if video_dir:
            paths_to_try.append(os.path.join(video_dir, "chapters.xml"))
        paths_to_try = [p for p in paths_to_try if xbmcvfs.exists(p)]

    log(f"Attempting chapter XML paths: {paths_to_try}")

    for path in paths_to_try:
        if not path:
            continue
        try:
            f = xbmcvfs.File(path)
            data = f.read()
            f.close()
            if isinstance(data, bytes):
                data = data.decode("utf-8", errors="replace")
        except Exception as e:
            log(f"Failed to read {path}: {e}")
            continue

        if not data or not data.strip():
            continue
        log(f"Successfully read file: {path}")

        segments = _segments_from_chapter_xml(data, path)
        if segments:
            segments = dedupe_overlapping_same_label_segments(segments)
            log(f"Total segments parsed from XML: {len(segments)} (using {path})")
            return segments
        log(f"No usable ChapterAtom entries in {path}, trying next chapter path if any")

    log("No chapter XML with segments found")
    return None


def parse_edl(video_path):
    """Parse .edl file and return list of SegmentItem objects."""
    try:
        from service_sidecar_paths import _edl_paths_to_try

        paths_to_try = list(_edl_paths_to_try(video_path))
    except ImportError:
        base = video_path.rsplit(".", 1)[0]
        paths_to_try = [f"{base}.edl"]

    log(f"Attempting EDL paths: {paths_to_try}")
    edl_data = safe_file_read(*paths_to_try)
    if not edl_data:
        log("No EDL file found")
        return []

    log(f"Raw EDL content:\n{edl_data}")

    segments = []
    try:
        for line in edl_data.splitlines():
            parsed = parse_edl_line(line, default_action=EDL_DEFAULT_ACTION)
            if parsed is None:
                if line.strip() and not line.strip().startswith("#"):
                    log(f"Skipped invalid EDL line: {line.strip()}")
                continue
            s, e, action = parsed
            try:
                label = get_edl_type_map().get(action) or "segment"
            except Exception:
                label = "segment"
            segments.append(SegmentItem(s, e, label, source="edl", action_type=action))
            log(f"Parsed EDL line: {s} -> {e} | action={action} | label='{label}'")
    except Exception as e:
        log(f"EDL parse failed: {e}")

    log(f"Total segments parsed from EDL: {len(segments)}")
    return segments


def _mkvextract_chapters_xml(video_path, timeout=3):
    """Try to extract embedded Matroska chapters as XML using mkvextract.

    Returns the XML string if successful, otherwise None. Requires
    ``mkvextract`` to be on PATH; silently returns None if the tool is
    missing (which is the common case on Kodi boxes).
    """
    # Only supports local paths; resolve through Kodi's VFS translator.
    try:
        local_path = xbmcvfs.translatePath(video_path)
    except Exception:
        local_path = video_path

    if "://" in local_path:
        # Still a remote URI after translation; mkvextract can't read it.
        return None
    if not os.path.isfile(local_path):
        return None

    try:
        completed = subprocess.run(
            ["mkvextract", local_path, "chapters", "-"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=timeout,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError) as err:
        log(f"mkvextract not available or failed ({err})")
        return None

    if completed.returncode != 0:
        log(f"mkvextract exit {completed.returncode}: {completed.stderr.decode('utf-8', errors='replace')[:200]}")
        return None

    data = completed.stdout.decode("utf-8", errors="replace").strip()
    if not data or "<Chapters" not in data:
        return None
    return data


def parse_embedded_chapters_via_mkvextract(video_path, timeout=3):
    """Return a list of SegmentItem from chapters embedded in the video container.

    Supports Matroska/WebM via ``mkvextract`` if available. Returns None if the
    video has no embedded chapters or the tool is unavailable.
    """
    xml_data = _mkvextract_chapters_xml(video_path, timeout=timeout)
    if not xml_data:
        return None

    try:
        root = ET.fromstring(xml_data)
    except Exception as e:
        log(f"Embedded chapter XML parse failed: {e}")
        return None

    raw_chapters = []
    for atom in root.findall(".//ChapterAtom"):
        raw_label = atom.findtext(".//ChapterDisplay/ChapterString", default="")
        label = raw_label.strip() if raw_label else "chapter"
        start = atom.findtext("ChapterTimeStart")
        end = atom.findtext("ChapterTimeEnd")
        if not start:
            continue
        try:
            start_s = hms_to_seconds(start)
        except ValueError:
            continue
        end_s = None
        if end:
            try:
                end_s = hms_to_seconds(end)
            except ValueError:
                # Invalid explicit end: skip the chapter rather than guessing.
                continue
        raw_chapters.append({
            "start": start_s,
            "end": end_s,
            "label": label,
            "missing_end": end_s is None,
        })

    raw_chapters.sort(key=lambda item: item["start"])

    result = []
    for i, item in enumerate(raw_chapters):
        start_s = item["start"]
        end_s = item["end"]
        if item["missing_end"]:
            # Matroska allows chapters without an explicit end. Fill those from
            # the next chapter start; keep explicit one-second chapters intact.
            if i + 1 < len(raw_chapters) and raw_chapters[i + 1]["start"] > start_s:
                end_s = raw_chapters[i + 1]["start"]
            else:
                end_s = start_s + 1
        try:
            result.append(SegmentItem(start_s, end_s, item["label"], source="xml"))
        except ValueError:
            log(f"Skipping invalid embedded chapter at {start_s}: end={end_s}")
            continue

    if not result:
        return None
    result = dedupe_overlapping_same_label_segments(result)
    return result


def segments_chronological(segments):
    """Return segments sorted by start time, then end time (stable sidecar/UI order)."""
    if not segments:
        return segments
    return sorted(segments, key=lambda s: (s.start_seconds, s.end_seconds))


def _intervals_overlap_or_touch(s1, e1, s2, e2, tolerance=1.5):
    """True when [s1,e1] and [s2,e2] overlap or are within ``tolerance`` seconds of touching."""
    return not (e1 + tolerance <= s2 or e2 + tolerance <= s1)


def dedupe_overlapping_same_label_segments(segments, tolerance=1.5):
    """Merge consecutive same-label windows that overlap or touch (common bad chapter XML).

    Operates on objects with ``start_seconds``, ``end_seconds``, and
    ``segment_type_label``. Uses :func:`copy.copy` on the first segment of each
    merged pair so constructors / logging are not re-run.
    """
    if not segments:
        return []
    if len(segments) == 1:
        return list(segments)

    sorted_segs = sorted(
        segments,
        key=lambda s: (float(s.start_seconds), float(s.end_seconds)),
    )
    out = []
    for seg in sorted_segs:
        raw_lab = getattr(seg, "segment_type_label", None)
        lab_key = normalize_label(raw_lab) if raw_lab is not None else ""
        if not lab_key:
            out.append(seg)
            continue
        if out:
            prev = out[-1]
            prev_raw = getattr(prev, "segment_type_label", None)
            prev_key = (
                normalize_label(prev_raw) if prev_raw is not None else ""
            )
            if prev_key == lab_key:
                ps = float(prev.start_seconds)
                pe = float(prev.end_seconds)
                ss = float(seg.start_seconds)
                se = float(seg.end_seconds)
                if _intervals_overlap_or_touch(ps, pe, ss, se, tolerance):
                    merged = copy.copy(prev)
                    merged.start_seconds = min(ps, ss)
                    merged.end_seconds = max(pe, se)
                    if hasattr(merged, "next_segment_start"):
                        merged.next_segment_start = None
                    if hasattr(merged, "next_segment_info"):
                        merged.next_segment_info = None
                    out[-1] = merged
                    continue
        out.append(seg)

    if len(out) < len(segments):
        log(
            "Deduped overlapping same-label segments: %d -> %d"
            % (len(segments), len(out))
        )
    return out


def save_chapters(video_path, segments):
    """Save segments to chapter.xml file."""
    if '.' in video_path:
        base = video_path.rsplit('.', 1)[0]
    else:
        base = video_path

    output_path = None
    try:
        from service_sidecar_paths import _find_existing_sidecar_chapter_xml_path

        output_path = _find_existing_sidecar_chapter_xml_path(video_path)
    except ImportError:
        pass

    if not output_path:
        for suffix in CHAPTER_XML_SIDECAR_SUFFIXES:
            path = f"{base}{suffix}"
            if xbmcvfs.exists(path):
                output_path = path
                break
    if not output_path:
        output_path = f"{base}{DEFAULT_NEW_CHAPTER_XML_SUFFIX}"

    log(f"Saving {len(segments)} segments to: {output_path}")

    try:
        action_mapping = get_edl_type_map()
    except Exception:
        action_mapping = {}

    root = ET.Element("Chapters")
    edition = ET.SubElement(root, "EditionEntry")

    for seg in segments:
        atom = ET.SubElement(edition, "ChapterAtom")
        ET.SubElement(atom, "ChapterTimeStart").text = seconds_to_hms(seg.start_seconds)
        ET.SubElement(atom, "ChapterTimeEnd").text = seconds_to_hms(seg.end_seconds)

        display = ET.SubElement(atom, "ChapterDisplay")
        if seg.action_type is not None and seg.action_type in action_mapping:
            label = action_mapping[seg.action_type]
        else:
            label = seg.raw_label if hasattr(seg, 'raw_label') else seg.segment_type_label
        ET.SubElement(display, "ChapterString").text = label

    try:
        try:
            dir_path = '/'.join(output_path.split('/')[:-1])
            if dir_path and not xbmcvfs.exists(dir_path):
                log(f"Creating directory: {dir_path}")
                xbmcvfs.mkdirs(dir_path)
        except Exception as dir_err:
            log(f"Could not ensure directory exists: {dir_err}")

        indent_xml(root, indent="  ")
        xml_str = ET.tostring(root, encoding='unicode')
        xml_str = '<?xml version="1.0" encoding="UTF-8"?>\n' + xml_str

        log(f"Writing XML content to: {output_path} ({len(xml_str)} bytes)")
        success, bytes_written = safe_file_write(output_path, xml_str, is_bytes=False)

        if success:
            log(f"Successfully saved chapter XML to: {output_path} ({bytes_written} bytes)")
            return True
        log(f"Failed to write chapter XML to: {output_path}")
        return False
    except Exception as e:
        log(f"Failed to save chapter XML: {e}")
        import traceback
        log(f"Traceback: {traceback.format_exc()}")
        return False


def save_edl(video_path, segments):
    """Save segments to .edl file."""
    if '.' in video_path:
        base = video_path.rsplit('.', 1)[0]
    else:
        base = video_path

    try:
        from service_sidecar_paths import _find_existing_edl_path

        output_path = _find_existing_edl_path(video_path)
    except ImportError:
        output_path = None
    if not output_path:
        output_path = f"{base}.edl"

    if xbmcvfs.exists(output_path):
        log(f"Existing EDL file found, using its path format: {output_path}")
    else:
        log(f"EDL file does not exist, will create: {output_path}")

    log(f"Saving {len(segments)} segments to: {output_path}")

    try:
        lines = []
        for seg in segments:
            action = edl_write_action(
                getattr(seg, "segment_type_label", None),
                getattr(seg, "action_type", None),
            )
            lines.append(f"{seg.start_seconds:.3f}\t{seg.end_seconds:.3f}\t{action}")

        content = "\n".join(lines) + "\n"

        try:
            dir_path = '/'.join(output_path.split('/')[:-1])
            if dir_path and not xbmcvfs.exists(dir_path):
                log(f"Creating directory: {dir_path}")
                xbmcvfs.mkdirs(dir_path)
        except Exception as dir_err:
            log(f"Could not ensure directory exists: {dir_err}")

        log(f"Writing EDL content to: {output_path} ({len(content)} bytes)")
        success, bytes_written = safe_file_write(output_path, content, is_bytes=False)

        if success:
            log(f"Successfully saved EDL to: {output_path} ({bytes_written} bytes)")
            return True
        log(f"Failed to write EDL to: {output_path}")
        return False
    except Exception as e:
        log(f"Failed to save EDL: {e}")
        import traceback
        log(f"Traceback: {traceback.format_exc()}")
        return False


# ---------------------------------------------------------------------------
# Save-format dispatcher
# ---------------------------------------------------------------------------

SAVE_FORMAT_EDL = "edl"
SAVE_FORMAT_XML = "xml"
SAVE_FORMAT_BOTH = "both"

_SAVE_FORMAT_ALIASES = {
    "auto detect": SAVE_FORMAT_BOTH,
    "auto": SAVE_FORMAT_BOTH,
    "edl only": SAVE_FORMAT_EDL,
    "edl": SAVE_FORMAT_EDL,
    "chapter xml only": SAVE_FORMAT_XML,
    "xml": SAVE_FORMAT_XML,
    "both formats": SAVE_FORMAT_BOTH,
    "both": SAVE_FORMAT_BOTH,
}


def normalize_save_format(raw):
    """Map settings / legacy labels to an internal format key."""
    if not raw:
        return SAVE_FORMAT_BOTH
    key = str(raw).strip().lower()
    if key in _SAVE_FORMAT_ALIASES:
        return _SAVE_FORMAT_ALIASES[key]
    return SAVE_FORMAT_BOTH


def get_save_format():
    try:
        raw = get_addon().getSetting("segment_editor_save_format") or "Both"
    except Exception:
        raw = "Both"
    return normalize_save_format(raw)


def _backup_file(path, enabled):
    if not enabled or not path or not xbmcvfs.exists(path):
        return
    backup_path = f"{path}.bck"
    try:
        if xbmcvfs.exists(backup_path):
            xbmcvfs.delete(backup_path)
        if xbmcvfs.copy(path, backup_path):
            log(f"Backed up existing file: {backup_path}")
    except Exception as err:
        log(f"Could not back up {path}: {err}")


def _backup_editor_sidecars(video_path, save_format, enabled):
    if not enabled:
        return
    xml_paths = []
    edl_paths = []
    try:
        from service_sidecar_paths import _chapter_xml_paths_to_try, _edl_paths_to_try

        xml_paths = list(_chapter_xml_paths_to_try(video_path))
        edl_paths = list(_edl_paths_to_try(video_path))
    except ImportError:
        base = os.path.splitext(video_path)[0]
        xml_paths = [f"{base}{s}" for s in CHAPTER_XML_SIDECAR_SUFFIXES]
        edl_paths = [f"{base}.edl"]

    if save_format in (SAVE_FORMAT_BOTH, SAVE_FORMAT_EDL):
        for path in edl_paths:
            _backup_file(path, True)
    if save_format in (SAVE_FORMAT_BOTH, SAVE_FORMAT_XML):
        for path in xml_paths:
            _backup_file(path, True)


def save_segments(video_path, segments, save_format=None):
    """Persist ``segments`` for ``video_path`` according to ``save_format``.

    Returns a tuple ``(edl_success, xml_success)``. Either may be False even
    when the overall write succeeded (for example in "edl" mode ``xml_success``
    will always be False). The caller is expected to decide what to show the
    user based on the returned flags.
    """
    if save_format is None:
        save_format = get_save_format()
    else:
        save_format = normalize_save_format(save_format)

    try:
        backup_on = get_addon().getSetting("segment_editor_backup_before_write") == "true"
    except Exception:
        backup_on = True
    _backup_editor_sidecars(video_path, save_format, backup_on)

    segments = segments_chronological(segments)
    segments = dedupe_overlapping_same_label_segments(segments)

    edl_success = False
    xml_success = False

    if save_format == SAVE_FORMAT_BOTH:
        edl_success = save_edl(video_path, segments)
        xml_success = save_chapters(video_path, segments)
    elif save_format == SAVE_FORMAT_XML:
        xml_success = save_chapters(video_path, segments)
    elif save_format == SAVE_FORMAT_EDL:
        edl_success = save_edl(video_path, segments)

    if edl_success or xml_success:
        try:
            from service_sidecar_probe_cache import request_sidecar_probe_invalidation

            request_sidecar_probe_invalidation(video_path)
        except Exception:
            pass

    return edl_success, xml_success


def delete_segment_files(video_path, save_format=None):
    """Remove any segment files Kodi would otherwise re-use for this video."""
    if save_format is None:
        save_format = get_save_format()
    else:
        save_format = normalize_save_format(save_format)

    try:
        from service_sidecar_paths import (
            _chapter_xml_paths_to_try,
            _edl_paths_to_try,
        )

        all_xml = list(_chapter_xml_paths_to_try(video_path))
        all_edl = list(_edl_paths_to_try(video_path))
    except ImportError:
        base = os.path.splitext(video_path)[0]
        all_xml = [f"{base}{s}" for s in CHAPTER_XML_SIDECAR_SUFFIXES]
        all_edl = [f"{base}.edl"]

    if save_format == SAVE_FORMAT_BOTH:
        candidates = all_xml + all_edl
    elif save_format == SAVE_FORMAT_XML:
        candidates = all_xml
    elif save_format == SAVE_FORMAT_EDL:
        candidates = all_edl
    else:
        candidates = all_xml + all_edl

    deleted = []
    for path in candidates:
        if xbmcvfs.exists(path):
            try:
                xbmcvfs.delete(path)
                deleted.append(path)
                log(f"Deleted empty segment file: {path}")
            except Exception as err:
                log(f"Failed to delete {path}: {err}")
    if deleted:
        try:
            from service_sidecar_probe_cache import request_sidecar_probe_invalidation

            request_sidecar_probe_invalidation(video_path)
        except Exception:
            pass
    return deleted
