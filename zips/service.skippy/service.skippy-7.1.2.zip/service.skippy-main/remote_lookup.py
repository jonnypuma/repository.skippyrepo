# -*- coding: utf-8 -*-
"""TheIntroDB / IntroDB.app fetch, merge, and playback cache."""

import json
import os
import re
import time

import xbmcaddon
from contextlib import closing
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

import xbmc
import xbmcvfs

from settings_utils import (
    addon_get_bool,
    addon_get_setting_text,
    get_addon,
    log_remote,
    log_service_detail,
    parse_kodi_jsonrpc_raw,
)

from segment_item import SegmentItem
from skippy_stats import record_online_segments_downloaded
from remote_http import (
    ADDON_ID,
    INTRODB_SEGMENTS_URL,
    ONLINE_MERGE_INTRODB_FIRST,
    ONLINE_MERGE_THEINTRODB_FIRST,
    REMOTE_SEGMENT_PAYLOAD_KEYS,
    THEINTRODB_BASE_URL,
    _rlog,
    _safe_log_url,
    fetch_remote_json,
    local_label_for_remote_payload_key,
)
from remote_library import (
    build_movie_context,
    build_tv_episode_context,
    get_enriched_playing_item,
    playback_duration_seconds_for_upload,
    _get_playing_file_path,
)
def build_tv_cache_key(context):
    return (
        context.get("type"),
        context.get("tmdb_id"),
        context.get("imdb_id"),
        context.get("show_imdb_id"),
        context.get("season"),
        context.get("episode"),
    )


def normalize_skip_window(start_value, end_value, total_time, allow_zero_start=False):
    try:
        end_seconds = float(end_value)
    except (TypeError, ValueError):
        return None
    try:
        if start_value is None:
            start_seconds = 0.0 if allow_zero_start else 1.0
        else:
            start_seconds = float(start_value)
    except (TypeError, ValueError):
        start_seconds = 0.0 if allow_zero_start else 1.0
    if allow_zero_start:
        start_seconds = max(0.0, start_seconds)
    else:
        start_seconds = max(1.0, start_seconds)
    try:
        tt = float(total_time)
    except (TypeError, ValueError):
        tt = 0.0
    end_seconds = min(tt, end_seconds) if tt > 0 else end_seconds
    if end_seconds <= start_seconds:
        return None
    return start_seconds, end_seconds


def normalize_remote_segment_window(segment, total_time):
    if not isinstance(segment, dict):
        return None
    start_ms = segment.get("start_ms")
    end_ms = segment.get("end_ms")
    if end_ms is not None:
        try:
            return normalize_skip_window(
                None if start_ms is None else (float(start_ms) / 1000.0),
                float(end_ms) / 1000.0,
                total_time,
            )
        except (TypeError, ValueError):
            return None
    return normalize_skip_window(
        segment.get("start_sec"),
        segment.get("end_sec"),
        total_time,
    )


def _theintrodb_normalize_segment_field(raw):
    """
    TheIntroDB GET ``/v3/media`` returns each segment type as an **array** of
    objects (multiple windows per type possible). Legacy v1 used a single
    object per type; empty types were ``null`` in v1 and are **omitted** in v2/v3.
    """
    if raw is None:
        return []
    if isinstance(raw, list):
        return [x for x in raw if isinstance(x, dict)]
    if isinstance(raw, dict):
        return [raw]
    return []


def _theintrodb_segment_entries(payload, total_time):
    out = []
    if not isinstance(payload, dict):
        return out
    tt_hint = None
    if total_time is not None:
        try:
            tt_hint = float(total_time)
        except (TypeError, ValueError):
            tt_hint = None
    for segment_name in REMOTE_SEGMENT_PAYLOAD_KEYS:
        local_name = local_label_for_remote_payload_key(segment_name)
        entries = _theintrodb_normalize_segment_field(payload.get(segment_name))
        for entry in entries:
            if not isinstance(entry, dict):
                continue
            end_ms_raw = entry.get("end_ms")
            if end_ms_raw is None:
                # v3: credits/preview may omit end (= through end of media)
                if local_name not in ("credits", "preview"):
                    continue
                if tt_hint is None or tt_hint <= 0:
                    continue
                end_seconds = tt_hint
            else:
                try:
                    end_seconds = float(end_ms_raw) / 1000.0
                except (TypeError, ValueError):
                    continue
            start_ms_raw = entry.get("start_ms")
            if start_ms_raw is None:
                start_seconds = 0.0
            else:
                try:
                    start_seconds = float(start_ms_raw) / 1000.0
                except (TypeError, ValueError):
                    continue
            if start_seconds >= end_seconds:
                continue
            window = normalize_skip_window(
                start_seconds,
                end_seconds,
                total_time,
                allow_zero_start=True,
            )
            if window:
                out.append(
                    SegmentItem(
                        window[0],
                        window[1],
                        local_name,
                        source="theintrodb",
                    )
                )
    return out


def _theintrodb_lookup_api_key():
    addon = get_addon()
    if not addon:
        return None
    key = (addon_get_setting_text(addon, "online_upload_theintrodb_api_key", "") or "").strip()
    return key or None


def _theintrodb_id_query(context):
    """One media id for GET /v4/media.

    TVDB first (the API's identity; TV also pins the exact episode with
    ``tvdb_episode_id`` when known), then TMDB, then IMDb.
    """
    tvdb = context.get("tvdb_id")
    if tvdb not in (None, ""):
        out = {"tvdb_id": tvdb}
        ep = context.get("tvdb_episode_id")
        if (context.get("type") or "").lower() != "movie" and ep not in (None, ""):
            out["tvdb_episode_id"] = ep
        return out
    tmdb = context.get("tmdb_id")
    if tmdb not in (None, ""):
        return {"tmdb_id": tmdb}
    imdb_id = context.get("imdb_id")
    if imdb_id:
        return {"imdb_id": imdb_id}
    return {}


def fetch_theintrodb_segments(context, total_time):
    query = {}
    if (context.get("type") or "").lower() == "movie":
        ids = _theintrodb_id_query(context)
        if not ids:
            _rlog("TheIntroDB movie: need tmdb_id, tvdb_id or imdb_id in context")
            return []
        query.update(ids)
    else:
        season = context.get("season")
        episode = context.get("episode")
        if season is None or episode is None:
            _rlog("TheIntroDB TV: need season and episode in context")
            return []
        query["season"] = season
        query["episode"] = episode
        ids = _theintrodb_id_query(context)
        if not ids:
            _rlog(
                "TheIntroDB skipped: need tmdb_id, tvdb_id or episode imdb_id in context "
                "(show_imdb alone is not enough for this API)"
            )
            return []
        query.update(ids)

    if total_time is not None:
        try:
            tt = float(total_time)
            if tt > 0:
                query["duration_ms"] = int(round(tt * 1000.0))
        except (TypeError, ValueError):
            pass

    extra_headers = {}
    api_key = _theintrodb_lookup_api_key()
    if api_key:
        extra_headers["Authorization"] = "Bearer %s" % api_key

    payload = fetch_remote_json(
        "%s?%s" % (THEINTRODB_BASE_URL, urlencode(query)),
        "TheIntroDB",
        extra_headers=extra_headers or None,
    )
    if payload is None:
        _rlog(
            "TheIntroDB: no JSON payload (HTTP error, timeout, or cooldown — not cached)"
        )
        return None
    if not payload:
        return []
    segs = _theintrodb_segment_entries(payload, total_time)
    if segs:
        _rlog("TheIntroDB: using %d segment(s) %s" % (len(segs), [(s.segment_type_label, s.start_seconds, s.end_seconds) for s in segs]))
    else:
        keys = list(payload.keys()) if isinstance(payload, dict) else type(payload).__name__
        _rlog(
            "TheIntroDB: response OK but no usable segment windows after normalization (keys=%s)"
            % keys
        )
    return segs


def _introdb_segment_entries(payload, total_time):
    """Parse IntroDB.app payload keys into SegmentItems (outro stored as credits)."""
    out = []
    if not isinstance(payload, dict):
        return out
    for segment_name in REMOTE_SEGMENT_PAYLOAD_KEYS:
        val = payload.get(segment_name)
        if val is None:
            continue
        local_name = local_label_for_remote_payload_key(segment_name)
        entries = val if isinstance(val, list) else [val]
        for entry in entries:
            if not isinstance(entry, dict):
                continue
            window = normalize_remote_segment_window(entry, total_time)
            if window:
                out.append(
                    SegmentItem(
                        window[0],
                        window[1],
                        local_name,
                        source="introdb",
                    )
                )
    return out


def fetch_introdb_segments(context, total_time):
    is_movie = (context.get("type") or "").lower() == "movie"
    if is_movie:
        imdb_id = context.get("imdb_id")
        query = {"imdb_id": imdb_id, "is_movie": "true"}
    else:
        imdb_id = context.get("show_imdb_id")
        query = {
            "imdb_id": imdb_id,
            "season": context.get("season"),
            "episode": context.get("episode"),
        }
        try:
            if int(query["season"]) < 1 or int(query["episode"]) < 1:
                _rlog("IntroDB.app lookup skipped: season/episode must be >= 1")
                return []
        except (TypeError, ValueError):
            _rlog("IntroDB.app lookup skipped: bad season/episode")
            return []
    if not imdb_id:
        _rlog("IntroDB.app lookup skipped: no %sIMDb id" % ("" if is_movie else "show "))
        return []

    payload = fetch_remote_json(
        "%s?%s"
        % (INTRODB_SEGMENTS_URL, urlencode(query)),
        "IntroDB.app",
    )
    if payload is None:
        _rlog("IntroDB.app: lookup failed or cooldown active — not cached")
        return None
    if not isinstance(payload, dict):
        _rlog("IntroDB.app: response was not a JSON object (got %s)" % type(payload).__name__)
        return []

    out = _introdb_segment_entries(payload, total_time)
    if out:
        _rlog("IntroDB.app: using %d segment(s) %s" % (len(out), [(s.segment_type_label, s.start_seconds, s.end_seconds) for s in out]))
    else:
        _rlog(
            "IntroDB.app: no segment windows (payload keys=%s)"
            % (list(payload.keys()),)
        )
    return out


def _segments_overlap(a, b, tol=1.5):
    return not (
        a.end_seconds + tol <= b.start_seconds
        or b.end_seconds + tol <= a.start_seconds
    )


def merge_remote_segments(primary_segs, secondary_segs):
    """Primary wins when both sources cover the same time window; secondary adds non-overlapping only."""
    out = list(primary_segs)
    for b in secondary_segs:
        if not any(_segments_overlap(b, a) for a in out):
            out.append(b)
    return sorted(out, key=lambda s: s.start_seconds)


def _merge_remote_sources_for_cache(cache, key, the_segs, intro_segs, introdb_primary):
    """Merge TheIntroDB + IntroDB.app. Cache only when both fetches completed (not cooldown/error).

    ``None`` from a fetch means the request was skipped or failed. Empty list is a
    real no-match (including HTTP 404) and is cacheable.
    """
    incomplete = the_segs is None or intro_segs is None
    the_list = the_segs if the_segs is not None else []
    intro_list = intro_segs if intro_segs is not None else []
    if introdb_primary:
        merged = merge_remote_segments(intro_list, the_list)
    else:
        merged = merge_remote_segments(the_list, intro_list)
    if incomplete:
        _rlog(
            "not caching remote merge: a source fetch failed or is in cooldown "
            "(TheIntroDB=%s, IntroDB.app=%s)"
            % (
                "miss" if the_segs is None else len(the_list),
                "miss" if intro_segs is None else len(intro_list),
            )
        )
        return list(merged)
    cache[key] = merged
    if merged:
        record_online_segments_downloaded(len(merged))
    return list(merged)


def _online_merge_introdb_primary(playback_kind):
    """
    playback_kind: 'tv' or 'movie' — which setting key to read.
    Returns True if IntroDB.app should win overlapping windows vs TheIntroDB.
    """
    addon = get_addon()
    key = (
        "tv_online_merge_priority"
        if playback_kind == "tv"
        else "movie_online_merge_priority"
    )
    raw = (
        addon_get_setting_text(addon, key, ONLINE_MERGE_THEINTRODB_FIRST)
        if addon
        else ONLINE_MERGE_THEINTRODB_FIRST
    )
    return (raw or "").strip() == ONLINE_MERGE_INTRODB_FIRST


def fetch_remote_movie_segments(total_time, cache, snapshot=None):
    """
    Fetch intro/recap SegmentItems for the current movie (TheIntroDB only). Uses cache dict.
    """
    item = get_enriched_playing_item(snapshot=snapshot)
    if not item or (item.get("type") or "").lower() != "movie":
        _rlog("Remote movie segments: not a library movie item")
        return []

    context = build_movie_context(item)
    if not context:
        return []

    key = ("movie", context.get("tmdb_id"), context.get("imdb_id"))
    if key in cache:
        _rlog("cache hit movie key=%s -> %d segment(s)" % (key, len(cache[key])))
        return list(cache[key])

    try:
        tt = float(total_time)
    except (TypeError, ValueError):
        tt = 0.0
    if tt < 1.0:
        _rlog("Remote movie segments skipped: total time not available yet")
        return []

    the_segs = fetch_theintrodb_segments(context, tt)
    intro_segs = fetch_introdb_segments(context, tt)
    introdb_primary = _online_merge_introdb_primary("movie")
    the_n = "miss" if the_segs is None else len(the_segs)
    intro_n = "miss" if intro_segs is None else len(intro_segs)
    if introdb_primary:
        _rlog(
            "Remote movie segments: merge order IntroDB.app primary (TheIntroDB=%s, IntroDB=%s pre-merge)"
            % (the_n, intro_n)
        )
    else:
        _rlog(
            "Remote movie segments: merge order TheIntroDB primary (TheIntroDB=%s, IntroDB=%s pre-merge)"
            % (the_n, intro_n)
        )
    merged = _merge_remote_sources_for_cache(
        cache, key, the_segs, intro_segs, introdb_primary
    )
    if merged:
        _rlog("TheIntroDB/IntroDB merge (movie): using %d segment(s)" % len(merged))
    else:
        _rlog("TheIntroDB/IntroDB merge (movie): empty")
    return merged


def fetch_remote_tv_segments_core(item, total_time, cache):
    """
    Fetch intro/recap SegmentItems for TV ``item`` (library episode dict).
    Uses ``cache`` (typically ``remote_segment_cache`` or a fresh ``{}`` for prefetch-only fetches).
    """
    if not item or (item.get("type") or "").lower() != "episode":
        _rlog("Remote TV segments core: not an episode item")
        return []

    context = build_tv_episode_context(item)
    if not context:
        return []

    key = build_tv_cache_key(context)
    if key in cache:
        _rlog("cache hit for key=%s -> %d segment(s)" % (key, len(cache[key])))
        return list(cache[key])

    try:
        tt = float(total_time)
    except (TypeError, ValueError):
        tt = 0.0
    if tt < 1.0:
        _rlog("Remote TV segments skipped: total time not available yet")
        return []

    the_segs = fetch_theintrodb_segments(context, tt)
    intro_segs = fetch_introdb_segments(context, tt)
    introdb_primary = _online_merge_introdb_primary("tv")
    merged = _merge_remote_sources_for_cache(
        cache, key, the_segs, intro_segs, introdb_primary
    )
    the_n = "miss" if the_segs is None else len(the_segs)
    intro_n = "miss" if intro_segs is None else len(intro_segs)
    if introdb_primary:
        _rlog(
            "merged remote (TV): IntroDB.app wins overlaps — %d segment(s) total "
            "(TheIntroDB=%s, IntroDB.app=%s pre-merge)"
            % (len(merged), the_n, intro_n)
        )
    else:
        _rlog(
            "merged remote (TV): TheIntroDB wins overlaps — %d segment(s) total "
            "(TheIntroDB=%s, IntroDB.app=%s pre-merge)"
            % (len(merged), the_n, intro_n)
        )
    return merged


def _try_tv_prefetch_handoff(item, cache):
    """Apply successor prefetch when playing file and cache key match; discard prefetch otherwise."""
    from prefetch_segment_cache import (
        consume_tv_prefetch_entry,
        peek_tv_prefetch_for_playing_path,
    )

    playing_path = item.get("file") or _get_playing_file_path()
    if not playing_path:
        return None
    entry = peek_tv_prefetch_for_playing_path(playing_path)
    if not entry:
        return None

    context = build_tv_episode_context(item)
    key = build_tv_cache_key(context) if context else None
    segs = entry.get("segments") or []
    exp_key = entry.get("cache_key")
    tags = sorted({getattr(s, "source", "?") for s in segs})

    if key and exp_key == key and segs:
        consume_tv_prefetch_entry()
        cache[key] = list(segs)
        _rlog(
            "TV prefetch handoff: %d segment(s) for %s key=%s sources=%s"
            % (len(segs), os.path.basename(str(playing_path)), key, tags)
        )
        log_service_detail(
            "prefetch handoff OK: segments=%d key=%s sources=%s path=%r"
            % (len(segs), key, ",".join(tags), playing_path),
            tag="prefetch",
        )
        return list(segs)

    consume_tv_prefetch_entry()
    _rlog(
        "TV prefetch handoff rejected (mismatch or empty): expected_key=%s got_key=%s segs=%d"
        % (exp_key, key, len(segs))
    )
    log_service_detail(
        "prefetch handoff REJECTED: expected_key=%s got_key=%s segcount=%d path=%r"
        % (exp_key, key, len(segs), playing_path),
        tag="prefetch",
    )
    return None


def fetch_remote_tv_segments(total_time, cache, snapshot=None):
    """
    Fetch intro/recap SegmentItems for the current TV episode. Uses cache dict keyed by episode ids.
    Applies **prefetch** handoff when the playing file matches a stored successor fetch.
    """
    item = get_enriched_playing_item(snapshot=snapshot)
    if not item:
        _rlog("Remote TV segments: no enriched playing item")
        return []

    handoff = _try_tv_prefetch_handoff(item, cache)
    if handoff is not None:
        return handoff

    return fetch_remote_tv_segments_core(item, total_time, cache)
