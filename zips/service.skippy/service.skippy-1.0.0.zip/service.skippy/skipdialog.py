import xbmcgui
import xbmc
import xbmcaddon
import threading
import time
import json

# Define a global variable to cache the addon object
_addon = None

def get_addon():
    """Returns the xbmcaddon.Addon object for this addon,
    or None if it fails to load."""
    # Always create a fresh addon object to avoid caching issues
    try:
        return xbmcaddon.Addon("service.skippy")
    except RuntimeError:
        return None

def log(msg):
    addon = get_addon()
    if addon and addon.getSettingBool("enable_verbose_logging"):
        # The addon context might be lost, so check again before calling getAddonInfo
        try:
            xbmc.log(f"[{addon.getAddonInfo('id')} - SkipDialog] {msg}", xbmc.LOGINFO)
        except RuntimeError:
            # Fallback if the addon info can't be retrieved
            xbmc.log(f"[service.skippy - SkipDialog] {msg}", xbmc.LOGINFO)

def log_always(msg):
    # This function is now more robust against shutdown failures
    addon = get_addon()
    if addon:
        # Check if the addon is still in context
        try:
            xbmc.log(f"[{addon.getAddonInfo('id')} - SkipDialog] {msg}", xbmc.LOGINFO)
        except RuntimeError:
            # Fallback for when context is lost
            xbmc.log(f"[service.skippy - SkipDialog] {msg}", xbmc.LOGINFO)
    else:
        xbmc.log(f"[service.skippy - SkipDialog] {msg}", xbmc.LOGINFO)

class SkipDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        try:
            super().__init__(*args)
            self.segment = kwargs.get("segment", None)
            log(f"📦 Loaded dialog layout: {args[0]}")
        except Exception as e:
            log_always(f"❌ Failed to initialize SkipDialog (possible Kodi/device limitation): {e}")
            log_always(f"❌ Dialog initialization failed with args: {args}, kwargs: {kwargs}")
            raise

    def onInit(self):
        try:
            log_always(f"🔍 onInit called — segment={getattr(self, 'segment', None)}")

            if not hasattr(self, "segment") or not self.segment:
                log("❌ Segment not set — aborting dialog init")
                self.close()
                return
        except Exception as e:
            log_always(f"❌ Error in onInit before segment check (possible Kodi/device limitation): {e}")
            try:
                self.close()
            except:
                pass
            return

        duration = int(self.segment.end_seconds - self.segment.start_seconds)
        m, s = divmod(duration, 60)
        duration_str = f"{m}m{s}s" if m else f"{s}s"
        
        # Get skip button format setting
        addon = get_addon()
        format_setting = addon.getSetting("skip_button_format") if addon else "Skip + Type + Duration"
        
        # Format label based on setting
        if format_setting == "Skip":
            label = "Skip"
        elif format_setting == "Skip + Type":
            label = f"Skip {self.segment.segment_type_label.title()}"
        else:  # "Skip + Type + Duration" (default)
            label = f"Skip {self.segment.segment_type_label.title()} ({duration_str})"
        
        # Set label on all button variants (normal and full-width)
        try:
            self.getControl(3012).setLabel(label)
        except:
            pass
        try:
            self.getControl(3015).setLabel(label)  # Full-width with skip icon visible
        except:
            pass
        try:
            self.getControl(3016).setLabel(label)  # Full-width with skip icon hidden
        except:
            pass
        self.setProperty("countdown", "")
        
        # Set the ending text property with segment type, falling back to "Segment" if no specific type identified
        # segment_type_label is normalized to lowercase, so "segment" is the default/generic type
        if self.segment.segment_type_label and self.segment.segment_type_label.lower() != "segment":
            segment_type = self.segment.segment_type_label.title()
        else:
            segment_type = "Segment"
        self.setProperty("ending_text", f"{segment_type} ending in:")
        
        # Check if ending text should be hidden
        hide_ending_text = addon.getSettingBool("hide_ending_text") if addon else False
        self.setProperty("hide_ending_text", "true" if hide_ending_text else "false")
        
        # Check if close button should be hidden
        hide_close = addon.getSettingBool("hide_close_button") if addon else False
        self.setProperty("hide_close_button", "true" if hide_close else "false")
        
        # Check if skip icon should be hidden
        hide_skip_icon = addon.getSettingBool("hide_skip_icon") if addon else False
        self.setProperty("hide_skip_icon", "true" if hide_skip_icon else "false")
        
        if hide_close:
            try:
                close_button = self.getControl(3013)
                close_button.setVisible(False)
                log("🚫 Close button hidden per setting")
                # Set default control to full-width button when close is hidden
                try:
                    if hide_skip_icon:
                        self.setFocusId(3016)  # Full-width button when skip icon is hidden
                        log("📐 Default control set to full-width button (3016, skip icon hidden)")
                    else:
                        self.setFocusId(3015)  # Full-width button when skip icon is visible
                        log("📐 Default control set to full-width button (3015, skip icon visible)")
                except:
                    pass
            except Exception as e:
                log(f"⚠️ Error hiding close button: {e}")
        
        self._closing = False
        self.response = None
        self.player = xbmc.Player()
        self._total_duration = self.segment.end_seconds - self.segment.start_seconds
        self._start_time = time.time()

        # Enhanced: Set property for next segment jump time with better info
        if self.segment.next_segment_start is not None:
            jump_m, jump_s = divmod(int(self.segment.next_segment_start), 60)
            
            # Use the next_segment_info if available, otherwise use generic text
            if hasattr(self.segment, 'next_segment_info') and self.segment.next_segment_info:
                # Extract segment label from info if it contains one
                if "'" in self.segment.next_segment_info:
                    # Extract text between quotes
                    import re
                    match = re.search(r"'([^']+)'", self.segment.next_segment_info)
                    if match:
                        segment_label = match.group(1).title()
                        jump_str = f"Skip to {segment_label} at {jump_m:02d}:{jump_s:02d}"
                    else:
                        jump_str = f"Skip to next segment at {jump_m:02d}:{jump_s:02d}"
                else:
                    jump_str = f"Skip to next segment at {jump_m:02d}:{jump_s:02d}"
            else:
                jump_str = f"Skip to next segment at {jump_m:02d}:{jump_s:02d}"
            
            self.setProperty("next_jump_label", jump_str)
            self.setProperty("show_next_jump", "true")
            log(f"⏭️ Dialog configured for jump to next segment at {self.segment.next_segment_start}s: {jump_str}")
        else:
            self.setProperty("show_next_jump", "false")
            log("➡️ Dialog configured for normal skip to end of segment")

        # 📊 Setup progress bar (read setting dynamically)
        try:
            # Read setting dynamically instead of caching
            addon = get_addon()
            raw_setting = addon.getSetting("show_progress_bar")
            show_progress = addon.getSettingBool("show_progress_bar")
            log(f"🧩 show_progress_bar raw setting: '{raw_setting}' -> bool: {show_progress}")
            
            progress = self.getControl(3014)
            progress.setVisible(show_progress)
            if show_progress:
                progress.setPercent(0)
                log("📊 Progress bar initialized at 0%")
            else:
                log("📊 Progress bar hidden due to setting")
        except Exception as e:
            log(f"⚠️ Progress bar control error: {e}")

        try:
            log(f"🟦 Dialog initialized: segment='{self.segment.segment_type_label}', duration={duration_str}")
            threading.Thread(target=self._monitor_segment_end, daemon=True).start()
            log("✅ Dialog onInit completed successfully")
        except Exception as e:
            log_always(f"❌ Error during dialog onInit completion (possible Kodi/device limitation): {e}")
            log_always(f"❌ Dialog initialization failed for segment: {getattr(self.segment, 'segment_type_label', 'unknown')}")
            try:
                self.close()
            except:
                pass

    def _monitor_segment_end(self):
        delay = 0.25
        timeout = self._total_duration + 5  # ⏳ Dynamic timeout based on segment length

        while not self._closing:
            if not self.player.isPlaying():
                log("⏹️ Playback stopped during dialog")
                break

            current = self.player.getTime()
            remaining = int(self.segment.end_seconds - current)
            m, s = divmod(max(remaining, 0), 60)
            self.setProperty("countdown", f"{m:02d}:{s:02d}")

            # 📊 Update progress bar (check setting dynamically)
            try:
                # Re-read the setting each time to handle changes
                addon = get_addon()
                raw_setting = addon.getSetting("show_progress_bar")
                show_progress = addon.getSettingBool("show_progress_bar")
                
                progress = self.getControl(3014)
                progress.setVisible(show_progress)
                
                if show_progress:
                    elapsed = max(current - self.segment.start_seconds, 0)
                    percent = int((elapsed / self._total_duration) * 100)
                    percent = min(max(percent, 0), 100)
                    progress.setPercent(percent)
                    log(f"📊 Progress bar visible: {percent}% (raw: '{raw_setting}')")
                else:
                    # Ensure progress bar is hidden when disabled
                    progress.setVisible(False)
                    log(f"📊 Progress bar hidden due to setting (raw: '{raw_setting}')")
            except Exception as e:
                log(f"⚠️ Progress bar update error: {e}")

            # ⌛ Segment end reached
            if current >= self.segment.end_seconds - 0.5:
                log("⌛ Segment ended — auto-decline")
                self._closing = True
                self.response = False
                self.close()
                break

            # ⏳ Timeout fallback
            if time.time() - self._start_time > timeout:
                log("⏳ Timeout reached — auto-decline")
                self._closing = True
                self.response = False
                self.close()
                break

            time.sleep(delay)

    def onClick(self, controlId):
        if controlId == 3012 or controlId == 3015 or controlId == 3016:  # All skip button variants
            self.response = self.segment.next_segment_start or self.segment.end_seconds + 1.0
            log(f"🖱️ User clicked skip → skipping to {self.response}s")
        else:
            self.response = False
            log(f"🖱️ User clicked cancel/close → declining skip")

        self._closing = True
        self.close()

    def onAction(self, action):
        if action.getId() in [10, 92, 216]:
            log(f"🔙 User cancelled via action ID {action.getId()}")
            self.response = False
            self._closing = True
            self.close()


    def onClose(self):
        try:
            # Reset progress bar on close (read setting dynamically)
            show_progress = get_addon().getSettingBool("show_progress_bar")
            if show_progress:
                self.getControl(3014).setPercent(0)
                log("🔄 Progress bar reset on close")
        except Exception as e:
            log(f"⚠️ Error resetting progress bar on close: {e}")
