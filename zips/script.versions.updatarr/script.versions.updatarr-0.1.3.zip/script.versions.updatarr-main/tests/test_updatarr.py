# -*- coding: utf-8 -*-
import unittest
import os
import shutil
import tempfile
import sqlite3
from unittest.mock import patch

from lib.nfo_parser import parse_edition_from_xml, parse_edition_with_regex
from lib.filename_parser import parse_edition_from_filename
from lib.db_adapter import SQLiteAdapter
from lib.backup_manager import BackupManager, MIN_BACKUPS_RETAINED


class TestNfoParser(unittest.TestCase):
    def test_videoassettitle_tag(self):
        xml = "<movie><title>Lawrence of Arabia</title><videoassettitle>50th Anniversary Edition</videoassettitle></movie>"
        self.assertEqual(parse_edition_from_xml(xml), "50th Anniversary Edition")

    def test_edition_tag(self):
        xml = "<movie><title>Leon</title><edition>International Cut</edition></movie>"
        self.assertEqual(parse_edition_from_xml(xml), "International Cut")

    def test_nested_videoasset_title(self):
        xml = "<movie><videoasset><title>Director's Cut</title></videoasset></movie>"
        self.assertEqual(parse_edition_from_xml(xml), "Director's Cut")

    def test_regex_fallback(self):
        malformed = "<movie><unclosed><edition>Collector's Edition</edition>"
        self.assertEqual(parse_edition_with_regex(malformed), "Collector's Edition")


class TestFilenameParser(unittest.TestCase):
    def test_anniversary_edition(self):
        filename = "Lawrence.of.Arabia.1962.50th.Anniversary.Edition.2160p.UHD.HDR.DV.BD.Remux.mkv"
        self.assertEqual(parse_edition_from_filename(filename), "50th Anniversary Edition")
        # Test ordinals
        self.assertEqual(parse_edition_from_filename("Movie.21st.Anniversary.Edition.mkv"), "21st Anniversary Edition")
        self.assertEqual(parse_edition_from_filename("Movie.22nd.Anniversary.Edition.mkv"), "22nd Anniversary Edition")
        self.assertEqual(parse_edition_from_filename("Movie.23rd.Anniversary.Edition.mkv"), "23rd Anniversary Edition")

    def test_compound_and_custom_cuts(self):
        self.assertEqual(
            parse_edition_from_filename("Movie.1990.Unrated.Directors.Cut.1080p.mkv"),
            "Unrated Director's Cut"
        )
        self.assertEqual(
            parse_edition_from_filename("Star.Wars.1977.Despecialized.Edition.1080p.mkv"),
            "Despecialized Edition"
        )

    def test_international_cut(self):
        filename = "Leon.1994.International.Cut.UHD.BluRay.2160p.mkv"
        self.assertEqual(parse_edition_from_filename(filename), "International Cut")

    def test_directors_cut(self):
        filename = "Leon.aka.The.Professional.Directors.Cut.1994.BluRay.1080p.mkv"
        self.assertEqual(parse_edition_from_filename(filename), "Director's Cut")

    def test_explicit_edition_token(self):
        filename = "Blade.Runner.1982.{edition-The Final Cut}.2160p.mkv"
        self.assertEqual(parse_edition_from_filename(filename), "The Final Cut")

    def test_criterion_edition(self):
        filename = "Seven.Samurai.1954.Criterion.Collection.1080p.mkv"
        self.assertEqual(parse_edition_from_filename(filename), "Criterion Collection Edition")


class TestBackupAndRestoreSQLite(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.mkdtemp()
        self.db_path = os.path.join(self.temp_dir, "MyVideos146.db")

        # Create dummy SQLite database
        conn = sqlite3.connect(self.db_path)
        cur = conn.cursor()
        cur.execute("CREATE TABLE videoversion (idFile INT PRIMARY KEY, idType INT);")
        cur.execute("CREATE TABLE videoversiontype (id INT PRIMARY KEY, name TEXT);")
        cur.execute("INSERT INTO videoversiontype VALUES (40400, 'Standard Edition');")
        cur.execute("INSERT INTO videoversion VALUES (1, 40400);")
        conn.commit()
        conn.close()

        self.adapter = SQLiteAdapter(self.db_path)
        self.adapter.connect()
        self.backup_mgr = BackupManager(self.adapter, retention=3)
        self.backup_mgr.backup_dir = os.path.join(self.temp_dir, "backups")
        self.backup_mgr._ensure_backup_dir()

    def tearDown(self):
        self.adapter.close()
        shutil.rmtree(self.temp_dir)

    def test_backup_creation_and_listing(self):
        info = self.backup_mgr.create_backup()
        self.assertTrue(os.path.exists(info.identifier))
        backups = self.backup_mgr.list_backups()
        self.assertEqual(len(backups), 1)

    def test_minimum_retention_enforced(self):
        self.assertEqual(self.backup_mgr.retention, MIN_BACKUPS_RETAINED)
        self.assertGreaterEqual(self.backup_mgr.retention, 3)

        # Create 5 backups
        import time
        for i in range(5):
            # simulate different timestamps
            ts = "20261119_19000{}".format(i)
            bak_path = os.path.join(self.backup_mgr.backup_dir, "MyVideos146_bak_{}.db".format(ts))
            shutil.copy2(self.db_path, bak_path)

        # Prune
        self.backup_mgr._prune_sqlite_backups()
        remaining = self.backup_mgr.list_backups()
        self.assertEqual(len(remaining), 3)

    def test_restore_sqlite(self):
        # 1. Take initial backup with standard edition
        bak_info = self.backup_mgr.create_backup()

        # 2. Modify active DB
        self.adapter.execute("UPDATE videoversion SET idType = 999 WHERE idFile = 1;")
        self.adapter.commit()
        rows = self.adapter.query("SELECT idType FROM videoversion WHERE idFile = 1;")
        self.assertEqual(rows[0]["idType"], 999)

        # 3. Restore backup
        success = self.backup_mgr.restore_backup(bak_info)
        self.assertTrue(success)

        # 4. Verify restored value
        restored_rows = self.adapter.query("SELECT idType FROM videoversion WHERE idFile = 1;")
        self.assertEqual(restored_rows[0]["idType"], 40400)


class TestDefaultVersionManager(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.mkdtemp()
        self.db_path = os.path.join(self.temp_dir, "MyVideos146.db")

        # Create schema for movies, episodes, files, paths, videoversion, videoversiontype
        conn = sqlite3.connect(self.db_path)
        cur = conn.cursor()
        cur.execute("CREATE TABLE path (idPath INT PRIMARY KEY, strPath TEXT);")
        cur.execute("CREATE TABLE files (idFile INT PRIMARY KEY, idPath INT, strFilename TEXT, playCount INT, lastPlayed TEXT);")
        cur.execute("CREATE TABLE movie (idMovie INT PRIMARY KEY, idFile INT, c00 TEXT);")
        cur.execute("CREATE TABLE tvshow (idShow INT PRIMARY KEY, c00 TEXT);")
        cur.execute("CREATE TABLE episode (idEpisode INT PRIMARY KEY, idFile INT, idShow INT, c00 TEXT, c12 TEXT, c13 TEXT);")
        cur.execute("CREATE TABLE videoversion (idFile INT PRIMARY KEY, idMedia INT, media_type TEXT, itemType INT, idType INT);")
        cur.execute("CREATE TABLE videoversiontype (id INT PRIMARY KEY, name TEXT, owner INT, itemType INT);")

        # Insert reference data
        cur.execute("INSERT INTO videoversiontype VALUES (40400, 'Standard Edition', 1, 1);")
        cur.execute("INSERT INTO videoversiontype VALUES (40401, 'Director''s Cut', 2, 1);")
        cur.execute("INSERT INTO videoversiontype VALUES (40402, 'Extended Cut', 2, 1);")

        cur.execute("INSERT INTO path VALUES (1, 'smb://server/Movies/Blade Runner/');")
        cur.execute("INSERT INTO path VALUES (2, 'smb://server/TV/Twin Peaks/Season 2/');")

        # Movie with 2 versions
        cur.execute("INSERT INTO files VALUES (101, 1, 'Blade Runner Theatrical.mkv', 5, '2026-01-01 20:00:00');")
        cur.execute("INSERT INTO files VALUES (102, 1, 'Blade Runner Directors Cut.mkv', 0, NULL);")
        cur.execute("INSERT INTO movie VALUES (1, 101, 'Blade Runner');")
        cur.execute("INSERT INTO videoversion VALUES (101, 1, 'movie', 1, 40400);")
        cur.execute("INSERT INTO videoversion VALUES (102, 1, 'movie', 1, 40401);")

        # TV Episode with 2 versions
        cur.execute("INSERT INTO tvshow VALUES (10, 'Twin Peaks');")
        cur.execute("INSERT INTO files VALUES (201, 2, 'Twin Peaks S02E01 Broadcast.mkv', 2, '2026-02-01 21:00:00');")
        cur.execute("INSERT INTO files VALUES (202, 2, 'Twin Peaks S02E01 Extended.mkv', 0, NULL);")
        cur.execute("INSERT INTO episode VALUES (50, 201, 10, 'May the Giant Be with You', '2', '1');")
        cur.execute("INSERT INTO videoversion VALUES (201, 50, 'episode', 1, 40400);")
        cur.execute("INSERT INTO videoversion VALUES (202, 50, 'episode', 1, 40402);")

        conn.commit()
        conn.close()

        self.adapter = SQLiteAdapter(self.db_path)
        self.adapter.connect()
        self.bak_patcher = patch(
            "lib.backup_manager.translate_path", return_value=os.path.join(self.temp_dir, "backups")
        )
        self.bak_patcher.start()

    def tearDown(self):
        self.bak_patcher.stop()
        self.adapter.close()
        shutil.rmtree(self.temp_dir)

    def test_get_multiversion_items(self):
        from lib.default_version_manager import get_multiversion_items
        items = get_multiversion_items(self.adapter)
        self.assertEqual(len(items), 2)

        movie_item = next(it for it in items if it.media_type == "movie")
        self.assertEqual(movie_item.id_media, 1)
        self.assertEqual(movie_item.title, "Blade Runner")
        self.assertEqual(len(movie_item.versions), 2)
        self.assertEqual(movie_item.default_file_id, 101)
        self.assertEqual(movie_item.get_default_version().id_file, 101)

        ep_item = next(it for it in items if it.media_type == "episode")
        self.assertEqual(ep_item.id_media, 50)
        self.assertIn("Twin Peaks", ep_item.title)
        self.assertEqual(len(ep_item.versions), 2)
        self.assertEqual(ep_item.default_file_id, 201)

    def test_swap_default_version_movie(self):
        from lib.default_version_manager import swap_default_version
        success, bak_info = swap_default_version(
            self.adapter,
            id_media=1,
            media_type="movie",
            target_file_id=102,
            sync_watched=True,
            retention=3
        )
        self.assertTrue(success)

        # Verify movie table now points to 102
        rows = self.adapter.query("SELECT idFile FROM movie WHERE idMovie = 1")
        self.assertEqual(rows[0]["idFile"], 102)

        # Verify watched count transferred to new default file 102
        file_rows = self.adapter.query("SELECT playCount, lastPlayed FROM files WHERE idFile = 102")
        self.assertEqual(file_rows[0]["playCount"], 5)
        self.assertEqual(file_rows[0]["lastPlayed"], "2026-01-01 20:00:00")

    def test_swap_default_version_episode(self):
        from lib.default_version_manager import swap_default_version
        success, bak_info = swap_default_version(
            self.adapter,
            id_media=50,
            media_type="episode",
            target_file_id=202,
            sync_watched=True,
            retention=3
        )
        self.assertTrue(success)

        # Verify episode table now points to 202
        rows = self.adapter.query("SELECT idFile FROM episode WHERE idEpisode = 50")
        self.assertEqual(rows[0]["idFile"], 202)

        # Verify watched count transferred to new default file 202
        file_rows = self.adapter.query("SELECT playCount, lastPlayed FROM files WHERE idFile = 202")
        self.assertEqual(file_rows[0]["playCount"], 2)


class TestEpisodeVersionScan(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.mkdtemp()
        self.db_path = os.path.join(self.temp_dir, "MyVideos146.db")

        conn = sqlite3.connect(self.db_path)
        cur = conn.cursor()
        cur.execute("CREATE TABLE path (idPath INT PRIMARY KEY, strPath TEXT);")
        cur.execute("CREATE TABLE files (idFile INT PRIMARY KEY, idPath INT, strFilename TEXT, playCount INT, lastPlayed TEXT);")
        cur.execute("CREATE TABLE tvshow (idShow INT PRIMARY KEY, c00 TEXT);")
        cur.execute("CREATE TABLE episode (idEpisode INT PRIMARY KEY, idFile INT, idShow INT, c00 TEXT, c12 TEXT, c13 TEXT);")
        cur.execute("CREATE TABLE videoversion (idFile INT PRIMARY KEY, idMedia INT, media_type TEXT, itemType INT, idType INT);")
        cur.execute("CREATE TABLE videoversiontype (id INT PRIMARY KEY, name TEXT, owner INT, itemType INT);")

        cur.execute("INSERT INTO videoversiontype VALUES (40400, 'Standard Edition', 1, 1);")
        cur.execute("INSERT INTO path VALUES (1, 'smb://server/TV/Twin Peaks/Season 2/');")
        cur.execute("INSERT INTO tvshow VALUES (10, 'Twin Peaks');")

        # Episode file with an edition keyword in filename
        cur.execute("INSERT INTO files VALUES (301, 1, 'Twin.Peaks.S02E01.European.Cut.1080p.mkv', 0, NULL);")
        cur.execute("INSERT INTO episode VALUES (70, 301, 10, 'May the Giant Be with You', '2', '1');")

        # Pre-assign standard edition
        cur.execute("INSERT INTO videoversion VALUES (301, 70, 'episode', 1, 40400);")

        conn.commit()
        conn.close()

        self.adapter = SQLiteAdapter(self.db_path)
        self.adapter.connect()
        self.bak_patcher = patch(
            "lib.backup_manager.translate_path", return_value=os.path.join(self.temp_dir, "backups")
        )
        self.bak_patcher.start()

    def tearDown(self):
        self.bak_patcher.stop()
        self.adapter.close()
        shutil.rmtree(self.temp_dir)

    def test_scan_and_update_episode(self):
        from lib.config import AddonSettings
        from lib.version_updater import VersionUpdater

        settings = AddonSettings()
        settings.scan_movies = False
        settings.scan_episodes = True
        settings.scan_filenames = True
        settings.scan_nfo = False
        settings.backup_retention = 3

        updater = VersionUpdater(self.adapter, settings)
        scan_res = updater.scan_for_changes()

        self.assertEqual(len(scan_res.changes), 1)
        change = scan_res.changes[0]
        self.assertEqual(change.media_type, "episode")
        self.assertEqual(change.id_media, 70)
        self.assertEqual(change.target_type, "European Cut")

        # Apply changes
        update_res = updater.apply_changes(scan_res.changes)
        self.assertEqual(update_res.applied_count, 1)

        # Verify database record updated
        rows = self.adapter.query("""
            SELECT v.idFile, v.idType, vt.name 
            FROM videoversion v 
            JOIN videoversiontype vt ON v.idType = vt.id 
            WHERE v.idFile = 301 AND v.media_type = 'episode'
        """)
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["name"], "European Cut")
        self.assertGreaterEqual(rows[0]["idType"], 40801)

    def test_duplicate_idfile_updates_instead_of_insert_error(self):
        from lib.config import AddonSettings
        from lib.version_updater import VersionUpdater, PlannedChange
        from lib.run_logger import build_summary_lines, write_run_log

        # Insert an existing videoversion row with a different media_type or stale entry for idFile 302
        self.adapter.execute("INSERT INTO files VALUES (302, 1, 'Twin.Peaks.S02E02.Extended.Cut.1080p.mkv', 0, NULL);")
        self.adapter.execute("INSERT INTO episode VALUES (71, 302, 10, 'Coma', '2', '2');")
        self.adapter.execute("INSERT INTO videoversion VALUES (302, 71, 'video', 1, 40400);")
        self.adapter.commit()

        settings = AddonSettings()
        settings.scan_movies = False
        settings.scan_episodes = True
        settings.scan_filenames = True
        settings.scan_nfo = False
        settings.backup_retention = 3

        updater = VersionUpdater(self.adapter, settings)
        updater.load_version_types()
        change = PlannedChange(
            id_media=71,
            media_type="episode",
            title="Twin Peaks - S02E02 - Coma",
            id_file=302,
            filename="Twin.Peaks.S02E02.Extended.Cut.1080p.mkv",
            current_type="None",
            target_type="Extended Edition",
            in_videoversion=False  # Force code path where caller thought it was an INSERT
        )
        res = updater.apply_changes([change])
        self.assertEqual(res.applied_count, 1)

        rows = self.adapter.query("SELECT idType FROM videoversion WHERE idFile = 302")
        self.assertEqual(len(rows), 1)
        self.assertGreaterEqual(rows[0]["idType"], 40801)

        with patch("lib.run_logger.translate_path", return_value=os.path.join(self.temp_dir, "logs")):
            lines = build_summary_lines(
                config="SQLite Test",
                total_scanned=1,
                changes=[change],
                applied_count=res.applied_count,
                new_types=res.new_types_created,
                backup_info=res.backup_info
            )
            log_path = write_run_log(lines)
            self.assertTrue(os.path.exists(log_path))
            with open(log_path, "r", encoding="utf-8") as f:
                content = f.read()
            self.assertIn("Status: Success", content)
            self.assertIn("Extended Edition", content)


if __name__ == "__main__":
    unittest.main()
