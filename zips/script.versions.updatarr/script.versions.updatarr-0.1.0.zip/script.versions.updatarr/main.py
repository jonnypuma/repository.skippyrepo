# -*- coding: utf-8 -*-
"""
Main execution script and GUI controller for script.versions.updatarr.
"""
import sys
import os

# Add addon directory to sys.path
ADDON_DIR = os.path.dirname(os.path.abspath(__file__))
if ADDON_DIR not in sys.path:
    sys.path.insert(0, ADDON_DIR)

from lib.kodi_compat import (
    is_kodi, get_addon, log, show_notification, show_ok_dialog,
    show_yesno_dialog, show_select_dialog, show_text_dialog, ProgressDialog
)
from lib.config import AddonSettings, resolve_database_config
from lib.db_adapter import get_adapter_for_config
from lib.backup_manager import BackupManager
from lib.version_updater import VersionUpdater


def run_scan_and_update(dry_run=False):
    settings = AddonSettings()
    config = resolve_database_config(settings)
    log("Resolved DB configuration: {}".format(config))

    try:
        adapter = get_adapter_for_config(config)
        adapter.connect()
    except Exception as e:
        log("Failed to connect to database: {}".format(e), "error")
        show_ok_dialog(
            "Connection Error",
            "Could not connect to Kodi video database:\n{}\n\nPlease check addon settings.".format(e)
        )
        return

    progress = ProgressDialog("Video Versions Updatarr", "Scanning video library...")
    updater = VersionUpdater(adapter, settings)

    def on_progress(current, total, title):
        pct = (float(current) / float(total)) * 100 if total > 0 else 0
        progress.update(pct, "Scanning movies ({}/{})...".format(current, total), title)
        return not progress.is_canceled()

    try:
        scan_res = updater.scan_for_changes(progress_callback=on_progress)
    finally:
        progress.close()

    changes = scan_res.changes
    if not changes:
        show_ok_dialog("Scan Complete", "Your video versions are already up to date! No changes needed.")
        adapter.close()
        return

    # Build summary lines for display
    summary_lines = [
        "Found {} version update(s) to apply:".format(len(changes)),
        ""
    ]
    for ch in changes[:10]:
        summary_lines.append(u"• {}: '{}' ➜ '{}'".format(
            ch.movie_title, ch.current_type, ch.target_type
        ))
    if len(changes) > 10:
        summary_lines.append("... and {} more.".format(len(changes) - 10))

    if dry_run:
        # Full text report for dry run
        full_report = [
            "=== Video Versions Updatarr: Dry Run Report ===",
            "Total items scanned: {}".format(scan_res.total_scanned),
            "Changes detected: {}".format(len(changes)),
            "Database: {}".format(config),
            "--------------------------------------------------",
            ""
        ]
        for ch in changes:
            full_report.append(u"• {} [{}]\n  File: {}\n  Current: '{}' ➜ Target: '{}'\n".format(
                ch.movie_title, ch.id_movie, ch.filename, ch.current_type, ch.target_type
            ))
        adapter.close()
        show_text_dialog("Dry Run Preview", "\n".join(full_report))
        return

    # Real run: confirm with user first
    confirm_msg = "{}\n\nA backup will be created before any changes are written. Proceed with updating the database?".format(
        "\n".join(summary_lines)
    )
    if not show_yesno_dialog("Confirm Database Update", confirm_msg):
        adapter.close()
        return

    # Apply updates with progress dialog
    apply_progress = ProgressDialog("Video Versions Updatarr", "Creating backup & updating database...")

    def on_apply_progress(current, total, title):
        pct = (float(current) / float(total)) * 100 if total > 0 else 0
        apply_progress.update(pct, "Updating versions ({}/{})...".format(current, total), title)
        return not apply_progress.is_canceled()

    try:
        res = updater.apply_changes(changes, progress_callback=on_apply_progress)
        apply_progress.close()

        show_ok_dialog(
            "Update Complete",
            "Successfully updated {} video version(s)!\nNew custom types created: {}\nBackup saved: {}".format(
                res.applied_count, res.new_types_count, res.backup_info.label if res.backup_info else "Yes"
            )
        )
        show_notification("Video Versions Updatarr", "Updated {} versions".format(res.applied_count))
        if is_kodi():
            import xbmc
            xbmc.executebuiltin("Container.Refresh")
    except Exception as e:
        apply_progress.close()
        log("Error during update: {}".format(e), "error")
        show_ok_dialog("Update Failed", "An error occurred during database update:\n{}".format(e))
    finally:
        adapter.close()


def run_manual_backup():
    settings = AddonSettings()
    config = resolve_database_config(settings)
    log("Resolved DB configuration for manual backup: {}".format(config))

    try:
        adapter = get_adapter_for_config(config)
        adapter.connect()
    except Exception as e:
        log("Failed to connect to database: {}".format(e), "error")
        show_ok_dialog("Connection Error", "Could not connect to database for backup:\n{}".format(e))
        return

    progress = ProgressDialog("Video Versions Updatarr", "Creating database backup...")
    try:
        mgr = BackupManager(adapter, retention=settings.backup_retention)
        bak_info = mgr.create_backup()
        progress.close()
        show_ok_dialog(
            "Backup Successful",
            "Database backup created successfully!\n\nIdentifier: {}\nDetails: {}".format(
                bak_info.label, bak_info.extra_info
            )
        )
        show_notification("Video Versions Updatarr", "Backup created")
    except Exception as e:
        progress.close()
        log("Error during backup: {}".format(e), "error")
        show_ok_dialog("Backup Failed", "Failed to create database backup:\n{}".format(e))
    finally:
        adapter.close()


def run_restore():
    settings = AddonSettings()
    config = resolve_database_config(settings)
    log("Resolving DB for restore: {}".format(config))

    try:
        adapter = get_adapter_for_config(config)
        adapter.connect()
    except Exception as e:
        log("Failed to connect to database: {}".format(e), "error")
        show_ok_dialog("Connection Error", "Could not connect to database for restore:\n{}".format(e))
        return

    mgr = BackupManager(adapter, retention=settings.backup_retention)
    backups = mgr.list_backups()

    if not backups:
        adapter.close()
        show_ok_dialog("Restore Backup", "No database backups were found.")
        return

    menu_items = []
    for b in backups:
        menu_items.append("{} | {}".format(b.label, b.extra_info))

    idx = show_select_dialog("Select a Backup to Restore", menu_items)
    if idx < 0 or idx >= len(backups):
        adapter.close()
        return

    selected_backup = backups[idx]
    confirm_text = "Are you sure you want to restore the database to:\n\n{}\n\n(A safety pre-restore backup will be created automatically before restoring)".format(
        selected_backup.label
    )
    if not show_yesno_dialog("Confirm Restore", confirm_text):
        adapter.close()
        return

    progress = ProgressDialog("Restoring Backup", "Restoring video version database...")
    try:
        mgr.restore_backup(selected_backup)
        progress.close()
        show_ok_dialog(
            "Restore Complete",
            "Database has been successfully restored to:\n{}".format(selected_backup.label)
        )
        show_notification("Video Versions Updatarr", "Restore complete")
        if is_kodi():
            import xbmc
            xbmc.executebuiltin("Container.Refresh")
    except Exception as e:
        progress.close()
        log("Error during restore: {}".format(e), "error")
        show_ok_dialog("Restore Failed", "Failed to restore backup:\n{}".format(e))
    finally:
        adapter.close()


def open_settings():
    addon = get_addon()
    if addon:
        addon.openSettings()


def main():
    args = sys.argv[1:] if len(sys.argv) > 1 else []

    if "--scan" in args or "action=scan" in args:
        run_scan_and_update(dry_run=False)
        return
    elif "--dry-run" in args or "action=dryrun" in args:
        run_scan_and_update(dry_run=True)
        return
    elif "--backup" in args or "action=backup" in args:
        run_manual_backup()
        return
    elif "--restore" in args or "action=restore" in args:
        run_restore()
        return

    # Interactive GUI Menu
    menu_options = [
        "🚀 Scan & Update Video Versions",
        "🔍 Dry Run (Preview Changes)",
        "💾 Create Database Backup",
        "🔄 Restore Database Backup",
        "⚙️ Settings"
    ]

    choice = show_select_dialog("Video Versions Updatarr", menu_options)
    if choice == 0:
        run_scan_and_update(dry_run=False)
    elif choice == 1:
        run_scan_and_update(dry_run=True)
    elif choice == 2:
        run_manual_backup()
    elif choice == 3:
        run_restore()
    elif choice == 4:
        open_settings()


if __name__ == "__main__":
    main()
