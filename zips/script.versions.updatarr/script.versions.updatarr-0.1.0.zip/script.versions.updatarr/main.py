# -*- coding: utf-8 -*-
"""
Main execution script and GUI controller for script.versions.updatarr.
"""
import sys
import os

# Add addon directory to sys.path
ADDON_DIR = os.path.dirname(os.path.abspath(__file__))
if ADDON_DIR not in sys.path:
    sys.path.insert(0, ADDON_DIR)

from lib.kodi_compat import (
    is_kodi, get_addon, log, show_notification, show_ok_dialog,
    show_yesno_dialog, show_select_dialog, show_text_dialog, ProgressDialog
)
from lib.config import AddonSettings, resolve_database_config
from lib.db_adapter import get_adapter_for_config
from lib.backup_manager import BackupManager
from lib.version_updater import VersionUpdater
from lib.default_version_manager import get_multiversion_items, swap_default_version


def run_scan_and_update(dry_run=False):
    settings = AddonSettings()
    config = resolve_database_config(settings)
    log("Resolved DB configuration: {}".format(config))

    try:
        adapter = get_adapter_for_config(config)
        adapter.connect()
    except Exception as e:
        log("Failed to connect to database: {}".format(e), "error")
        show_ok_dialog(
            "Connection Error",
            "Could not connect to Kodi video database:\n{}\n\nPlease check addon settings.".format(e)
        )
        return

    progress = ProgressDialog("Video Versions Updatarr", "Scanning video library...")
    updater = VersionUpdater(adapter, settings)

    def on_progress(current, total, title):
        pct = (float(current) / float(total)) * 100 if total > 0 else 0
        progress.update(pct, "Scanning library ({}/{})...".format(current, total), title)
        return not progress.is_canceled()

    try:
        scan_res = updater.scan_for_changes(progress_callback=on_progress)
    finally:
        progress.close()

    changes = scan_res.changes
    if not changes:
        show_ok_dialog("Scan Complete", "Your video versions are already up to date! No changes needed.")
        adapter.close()
        return

    # Build summary lines for display
    summary_lines = [
        "Found {} version update(s) to apply:".format(len(changes)),
        ""
    ]
    for ch in changes[:10]:
        tag = "[Movie]" if ch.media_type == "movie" else "[Episode]"
        summary_lines.append(u"• {} {}: '{}' ➜ '{}'".format(
            tag, ch.title, ch.current_type, ch.target_type
        ))
    if len(changes) > 10:
        summary_lines.append("... and {} more.".format(len(changes) - 10))

    if dry_run:
        # Full text report for dry run
        full_report = [
            "=== Video Versions Updatarr: Dry Run Report ===",
            "Total items scanned: {}".format(scan_res.total_scanned),
            "Changes detected: {}".format(len(changes)),
            "Database: {}".format(config),
            "--------------------------------------------------",
            ""
        ]
        for ch in changes:
            tag = "[Movie]" if ch.media_type == "movie" else "[Episode]"
            full_report.append(u"• {} {} [{}]\n  File: {}\n  Current: '{}' ➜ Target: '{}'\n".format(
                tag, ch.title, ch.id_media, ch.filename, ch.current_type, ch.target_type
            ))
        adapter.close()
        show_text_dialog("Dry Run Preview", "\n".join(full_report))
        return

    # Real run: confirm with user first
    confirm_msg = "{}\n\nA backup will be created before any changes are written. Proceed with updating the database?".format(
        "\n".join(summary_lines)
    )
    if not show_yesno_dialog("Confirm Database Update", confirm_msg):
        adapter.close()
        return

    # Apply updates with progress dialog
    apply_progress = ProgressDialog("Video Versions Updatarr", "Creating backup & updating database...")

    def on_apply_progress(current, total, title):
        pct = (float(current) / float(total)) * 100 if total > 0 else 0
        apply_progress.update(pct, "Updating versions ({}/{})...".format(current, total), title)
        return not apply_progress.is_canceled()

    try:
        res = updater.apply_changes(changes, progress_callback=on_apply_progress)
        apply_progress.close()

        show_ok_dialog(
            "Update Complete",
            "Successfully updated {} video version(s)!\nNew custom types created: {}\nBackup saved: {}".format(
                res.applied_count, res.new_types_count, res.backup_info.label if res.backup_info else "Yes"
            )
        )
        show_notification("Video Versions Updatarr", "Updated {} versions".format(res.applied_count))
        if is_kodi():
            import xbmc
            xbmc.executebuiltin("Container.Refresh")
    except Exception as e:
        apply_progress.close()
        log("Error during update: {}".format(e), "error")
        show_ok_dialog("Update Failed", "An error occurred during database update:\n{}".format(e))
    finally:
        adapter.close()


def run_manual_backup():
    settings = AddonSettings()
    config = resolve_database_config(settings)
    log("Resolved DB configuration for manual backup: {}".format(config))

    try:
        adapter = get_adapter_for_config(config)
        adapter.connect()
    except Exception as e:
        log("Failed to connect to database: {}".format(e), "error")
        show_ok_dialog("Connection Error", "Could not connect to database for backup:\n{}".format(e))
        return

    progress = ProgressDialog("Video Versions Updatarr", "Creating database backup...")
    try:
        mgr = BackupManager(adapter, retention=settings.backup_retention)
        bak_info = mgr.create_backup()
        progress.close()
        show_ok_dialog(
            "Backup Successful",
            "Database backup created successfully!\n\nIdentifier: {}\nDetails: {}".format(
                bak_info.label, bak_info.extra_info
            )
        )
        show_notification("Video Versions Updatarr", "Backup created")
    except Exception as e:
        progress.close()
        log("Error during backup: {}".format(e), "error")
        show_ok_dialog("Backup Failed", "Failed to create database backup:\n{}".format(e))
    finally:
        adapter.close()


def run_restore():
    settings = AddonSettings()
    config = resolve_database_config(settings)
    log("Resolving DB for restore: {}".format(config))

    try:
        adapter = get_adapter_for_config(config)
        adapter.connect()
    except Exception as e:
        log("Failed to connect to database: {}".format(e), "error")
        show_ok_dialog("Connection Error", "Could not connect to database for restore:\n{}".format(e))
        return

    mgr = BackupManager(adapter, retention=settings.backup_retention)
    backups = mgr.list_backups()

    if not backups:
        adapter.close()
        show_ok_dialog("Restore Backup", "No database backups were found.")
        return

    menu_items = []
    for b in backups:
        menu_items.append("{} | {}".format(b.label, b.extra_info))

    idx = show_select_dialog("Select a Backup to Restore", menu_items)
    if idx < 0 or idx >= len(backups):
        adapter.close()
        return

    selected_backup = backups[idx]
    confirm_text = "Are you sure you want to restore the database to:\n\n{}\n\n(A safety pre-restore backup will be created automatically before restoring)".format(
        selected_backup.label
    )
    if not show_yesno_dialog("Confirm Restore", confirm_text):
        adapter.close()
        return

    progress = ProgressDialog("Restoring Backup", "Restoring video version database...")
    try:
        mgr.restore_backup(selected_backup)
        progress.close()
        show_ok_dialog(
            "Restore Complete",
            "Database has been successfully restored to:\n{}".format(selected_backup.label)
        )
        show_notification("Video Versions Updatarr", "Restore complete")
        if is_kodi():
            import xbmc
            xbmc.executebuiltin("Container.Refresh")
    except Exception as e:
        progress.close()
        log("Error during restore: {}".format(e), "error")
        show_ok_dialog("Restore Failed", "Failed to restore backup:\n{}".format(e))
    finally:
        adapter.close()


def run_manage_default_versions():
    settings = AddonSettings()
    config = resolve_database_config(settings)
    log("Resolving DB for manage default versions: {}".format(config))

    try:
        adapter = get_adapter_for_config(config)
        adapter.connect()
    except Exception as e:
        log("Failed to connect to database: {}".format(e), "error")
        show_ok_dialog("Connection Error", "Could not connect to database:\n{}".format(e))
        return

    try:
        while True:
            # Fetch all multi-version items
            items = get_multiversion_items(adapter)
            if not items:
                show_ok_dialog("Default Versions", "No multi-version movies or episodes found in the database.")
                break

            display_items = []
            for it in items:
                tag = "🎬 [Movie]" if it.media_type == "movie" else "📺 [TV]"
                def_ver = it.get_default_version()
                def_name = def_ver.type_name if def_ver else "Unknown"
                display_items.append(u"{} {}  (Default: {})".format(tag, it.title, def_name))

            selected_idx = show_select_dialog("Select Title to Manage Versions", display_items)
            if selected_idx < 0 or selected_idx >= len(items):
                break

            chosen_item = items[selected_idx]

            # Show versions for chosen item
            ver_labels = []
            for v in chosen_item.versions:
                star = "★ " if v.is_default else "  "
                status = " [ACTIVE DEFAULT]" if v.is_default else ""
                ver_labels.append(u"{}{}{} ({})".format(star, v.type_name, status, v.filename))

            v_idx = show_select_dialog(
                u"Select Default Version for: {}".format(chosen_item.title),
                ver_labels
            )
            if v_idx < 0 or v_idx >= len(chosen_item.versions):
                continue

            chosen_ver = chosen_item.versions[v_idx]
            if chosen_ver.is_default:
                show_notification("Video Versions Updatarr", "'{}' is already the default version.".format(chosen_ver.type_name))
                continue

            confirm_msg = u"Set '{}' as the new default version for:\n\n{}\n\nFile: {}\n\n(A database backup will be created before updating)".format(
                chosen_ver.type_name, chosen_item.title, chosen_ver.filename
            )
            if not show_yesno_dialog("Confirm Default Version Change", confirm_msg):
                continue

            try:
                swap_default_version(
                    adapter,
                    id_media=chosen_item.id_media,
                    media_type=chosen_item.media_type,
                    target_file_id=chosen_ver.id_file,
                    sync_watched=settings.sync_watched_on_swap,
                    retention=settings.backup_retention
                )
                show_ok_dialog(
                    "Default Version Updated",
                    u"Successfully set default version to:\n'{}'\n\nTitle: {}".format(
                        chosen_ver.type_name, chosen_item.title
                    )
                )
                show_notification("Video Versions Updatarr", u"Default set to '{}'".format(chosen_ver.type_name))
                if is_kodi():
                    import xbmc
                    xbmc.executebuiltin("Container.Refresh")
            except Exception as e:
                log("Error swapping default version: {}".format(e), "error")
                show_ok_dialog("Update Failed", "Could not swap default version:\n{}".format(e))

    finally:
        adapter.close()


def open_settings():
    addon = get_addon()
    if addon:
        addon.openSettings()


def main():
    args = sys.argv[1:] if len(sys.argv) > 1 else []

    if "--scan" in args or "action=scan" in args:
        run_scan_and_update(dry_run=False)
        return
    elif "--dry-run" in args or "action=dryrun" in args:
        run_scan_and_update(dry_run=True)
        return
    elif "--defaults" in args or "action=defaults" in args:
        run_manage_default_versions()
        return
    elif "--backup" in args or "action=backup" in args:
        run_manual_backup()
        return
    elif "--restore" in args or "action=restore" in args:
        run_restore()
        return

    # Interactive GUI Menu
    menu_options = [
        "🚀 Scan & Update Video Versions",
        "🔍 Dry Run (Preview Changes)",
        "🌟 Manage Default Versions",
        "💾 Create Database Backup",
        "🔄 Restore Database Backup",
        "⚙️ Settings"
    ]

    choice = show_select_dialog("Video Versions Updatarr", menu_options)
    if choice == 0:
        run_scan_and_update(dry_run=False)
    elif choice == 1:
        run_scan_and_update(dry_run=True)
    elif choice == 2:
        run_manage_default_versions()
    elif choice == 3:
        run_manual_backup()
    elif choice == 4:
        run_restore()
    elif choice == 5:
        open_settings()


if __name__ == "__main__":
    main()
