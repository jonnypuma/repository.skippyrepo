# -*- coding: utf-8 -*-
"""
Context menu handler for updating video versions of a single movie in Kodi.
"""
import sys
import os

ADDON_DIR = os.path.dirname(os.path.abspath(__file__))
if ADDON_DIR not in sys.path:
    sys.path.insert(0, ADDON_DIR)

from lib.kodi_compat import (
    is_kodi, log, show_notification, show_ok_dialog,
    show_yesno_dialog, show_select_dialog
)
from lib.config import AddonSettings, resolve_database_config
from lib.db_adapter import get_adapter_for_config
from lib.nfo_parser import find_edition_from_nfo
from lib.filename_parser import parse_edition_from_filename
from lib.backup_manager import BackupManager

try:
    import xbmc
    import xbmcgui
    HAS_XBMC = True
except ImportError:
    HAS_XBMC = False


def run_context_update():
    if not HAS_XBMC:
        log("Context menu can only be run inside Kodi.", "warning")
        return

    # Get selected movie information from Kodi ListItem
    db_id_str = xbmc.getInfoLabel("ListItem.DBID")
    movie_title = xbmc.getInfoLabel("ListItem.Title") or xbmc.getInfoLabel("ListItem.Label") or "Selected Movie"

    if not db_id_str or not db_id_str.isdigit():
        show_notification("Video Versions Updatarr", "Could not identify selected movie.")
        return

    id_movie = int(db_id_str)
    settings = AddonSettings()
    config = resolve_database_config(settings)

    try:
        adapter = get_adapter_for_config(config)
        adapter.connect()
    except Exception as e:
        log("Context menu DB error: {}".format(e), "error")
        show_ok_dialog("Connection Error", "Could not connect to database:\n{}".format(e))
        return

    try:
        # Fetch files for this movie
        sql = """
        SELECT 
            m.idMovie,
            m.c00 AS movie_title,
            f.idFile,
            f.strFilename,
            p.strPath,
            v.idType,
            vt.name AS type_name,
            1 AS in_videoversion
        FROM movie m
        JOIN videoversion v ON m.idMovie = v.idMedia AND v.media_type = 'movie'
        JOIN files f ON v.idFile = f.idFile
        JOIN path p ON f.idPath = p.idPath
        LEFT JOIN videoversiontype vt ON v.idType = vt.id
        WHERE m.idMovie = %s

        UNION ALL

        SELECT 
            m.idMovie,
            m.c00 AS movie_title,
            f.idFile,
            f.strFilename,
            p.strPath,
            NULL AS idType,
            NULL AS type_name,
            0 AS in_videoversion
        FROM movie m
        JOIN files f ON m.idFile = f.idFile
        JOIN path p ON f.idPath = p.idPath
        LEFT JOIN videoversion v ON m.idFile = v.idFile
        WHERE m.idMovie = %s AND v.idFile IS NULL
        """
        rows = adapter.query(sql, (id_movie, id_movie))
        if not rows:
            show_notification("Video Versions Updatarr", "No media files found for this movie.")
            return

        # Load all version types
        type_rows = adapter.query("SELECT id, name FROM videoversiontype WHERE itemType = 1 ORDER BY name ASC;")
        type_dict = {r["name"].lower(): r["id"] for r in type_rows if r["name"]}
        max_type_id = max([r["id"] for r in type_rows] + [40400])

        for item in rows:
            filename = item["strFilename"]
            path = item["strPath"]
            current_type = item["type_name"] or "None"
            in_videoversion = bool(item["in_videoversion"])
            id_file = item["idFile"]

            # Detect edition from NFO or filename
            detected = None
            if settings.scan_nfo:
                detected = find_edition_from_nfo(path, filename)
            if not detected and settings.scan_filenames:
                detected = parse_edition_from_filename(filename)
                if not detected and path:
                    detected = parse_edition_from_filename(os.path.basename(path.rstrip("/\\")))

            dialog_text = "{}\nFile: {}\nCurrent Version: {}\nDetected Edition: {}".format(
                item["movie_title"],
                filename,
                current_type,
                detected or "None detected"
            )

            # Build options
            options = []
            if detected:
                options.append(u"✅ Set to detected: '{}'".format(detected))
            options.append(u"📋 Choose from existing version types...")
            options.append(u"✏️ Enter custom version name...")

            choice = show_select_dialog("Update Video Version: {}".format(item["movie_title"]), options)
            if choice < 0:
                continue

            target_name = None
            if detected and choice == 0:
                target_name = detected
            elif (detected and choice == 1) or (not detected and choice == 0):
                # Choose from list
                type_names = [r["name"] for r in type_rows if r["name"]]
                t_choice = show_select_dialog("Select Version Type", type_names)
                if t_choice >= 0:
                    target_name = type_names[t_choice]
            else:
                # Custom input dialog
                dialog = xbmcgui.Dialog()
                custom_name = dialog.input("Enter version name", defaultt=detected or "")
                if custom_name and custom_name.strip():
                    target_name = custom_name.strip()

            if not target_name:
                continue

            # Resolve type ID (ensuring 40801+ range for new types)
            norm_target = target_name.strip()
            if norm_target.lower() in type_dict:
                target_id = type_dict[norm_target.lower()]
            else:
                next_id = 40801 if max_type_id < 40800 else (max_type_id + 1)
                adapter.execute(
                    "INSERT INTO videoversiontype (id, name, owner, itemType) VALUES (%s, %s, 2, 1)",
                    (next_id, norm_target)
                )
                target_id = next_id
                max_type_id = next_id
                type_dict[norm_target.lower()] = next_id

            # Create backup
            mgr = BackupManager(adapter, retention=settings.backup_retention)
            mgr.create_backup()

            # Apply update
            if in_videoversion:
                adapter.execute(
                    "UPDATE videoversion SET idType = %s WHERE idFile = %s AND media_type = 'movie'",
                    (target_id, id_file)
                )
            else:
                adapter.execute(
                    "INSERT INTO videoversion (idFile, idMedia, media_type, itemType, idType) VALUES (%s, %s, 'movie', 1, %s)",
                    (id_file, id_movie, target_id)
                )
            adapter.commit()

            show_notification("Video Versions Updatarr", u"Updated to '{}'".format(norm_target))
            xbmc.executebuiltin("Container.Refresh")

    except Exception as e:
        log("Context menu update error: {}".format(e), "error")
        show_ok_dialog("Error", "Failed to update version:\n{}".format(e))
    finally:
        adapter.close()


if __name__ == "__main__":
    run_context_update()
