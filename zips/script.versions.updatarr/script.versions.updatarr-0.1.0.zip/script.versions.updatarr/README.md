# script.versions.updatarr

**Video Versions Updatarr** is a Kodi add-on (compatible with Kodi 21 Omega and Kodi 22 Piers) that automatically assigns and updates Kodi Video Version types directly in Kodi's database.

- **Author:** Skippy-McSkipface
- **Website:** [jonnypuma/script.versions.updatarr](https://github.com/jonnypuma/script.versions.updatarr)

---

## The Problem

In Kodi v21+, when videos have multiple versions or editions (e.g. *Director's Cut*, *Extended Edition*, *50th Anniversary Edition*), Kodi groups them into video versions. However:
1. Video versions default to **"Standard Edition"** during auto-grouping scans.
2. Kodi exports `<videoassettitle>` to `.nfo` files, but importing version names during library scans is incomplete.
3. Edition tags in `.nfo` files (`<edition>`) and filenames (e.g., `Lawrence.of.Arabia.1962.50th.Anniversary.Edition...mkv`) are ignored by Kodi's built-in scanner.
4. Kodi's JSON-RPC API does not offer endpoints to create or assign video versions.

## The Solution

**Video Versions Updatarr** inspects your library, reads `<videoassettitle>` / `<edition>` tags from sidecar NFOs and filename edition patterns, automatically inserts custom version types into the `videoversiontype` table, and links them in `videoversion`.

---

## Features

- **Automatic Database Detection:** Reads `advancedsettings.xml` automatically. If MariaDB / MySQL is configured, it connects using existing network credentials and finds the active schema (e.g., `kodi22_videos154`). If SQLite is used, it detects `MyVideos*.db`.
- **Integrated Pure-Python MySQL:** Includes bundled PyMySQL so MariaDB/MySQL works out of the box on all Kodi platforms (Windows, Android, CoreELEC/LibreELEC, Linux).
- **Safety First - Guaranteed 3+ Backups:**
  - Before applying any updates, a full backup is created automatically.
  - **SQLite:** Copies `.db` to a timestamped backup file in `special://profile/addon_data/script.versions.updatarr/backups/`.
  - **MariaDB / MySQL:** Creates database snapshots (`videoversion_bak_<timestamp>` and `videoversiontype_bak_<timestamp>`).
  - **Retention Policy:** Keeps at least **3 backups** at all times (user-configurable up to 20). Older backups are only pruned when the retention count is exceeded.
- **Standalone Backup Button:** Create an on-demand database backup at any time from the main menu without running a scan.
- **Easy Restore from Backup:**
  - Dedicated "Restore Database Backup" menu option allows selecting and restoring any previous backup snapshot with a single click.
  - Automatically creates a safety pre-restore snapshot before applying any restore.
- **Dry Run Mode:** Preview all planned changes in a readable report before modifying anything.
- **Safe Selective Updates:** Only updates versions that are currently set to "Standard Edition" or unassigned by default, preserving any custom editions you already set by hand (configurable).

---

## Installation in Kodi

Copy or symlink the `script.versions.updatarr` folder into your Kodi `addons/` directory:
- **Windows:** `%APPDATA%\Kodi\addons\script.versions.updatarr`
- **Linux / CoreELEC:** `~/.kodi/addons/script.versions.updatarr`
- **Android:** `/Android/data/org.xbmc.kodi/files/.kodi/addons/script.versions.updatarr`

Restart Kodi or select **Add-ons › Install from zip file** / update add-ons.

---

## Usage

### In Kodi GUI
Launch **Video Versions Updatarr** from **Programs / Add-ons**:
1. **🚀 Scan & Update Video Versions:** Scans movies, shows a summary of updates found, confirms, takes a backup, and updates the database.
2. **🔍 Dry Run (Preview Only):** Scans and displays a full list of detected titles, filenames, and target versions without touching the database.
3. **💾 Create Database Backup:** On-demand standalone backup snapshot created directly without running a scan.
4. **🔄 Restore Database Backup:** Lists all available backup snapshots (with timestamps and row counts) and lets you restore any of them.
5. **⚙️ Settings:** Configure NFO vs. filename detection, backup retention count (minimum 3), or override database credentials.

### Command Line / JSON-RPC
You can also run the script directly:
```bash
python main.py --dry-run
python main.py --scan
python main.py --backup
python main.py --restore
```
Or via Kodi JSON-RPC / built-in function:
```python
xbmc.executebuiltin('RunScript(script.versions.updatarr, action=scan)')
```

---

## License

MIT License. See [addon.xml](addon.xml) for metadata.
