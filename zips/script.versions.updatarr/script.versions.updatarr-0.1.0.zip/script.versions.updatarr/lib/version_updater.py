# -*- coding: utf-8 -*-
"""
Core video version detection and database update engine.
"""
import os
from lib.kodi_compat import log
from lib.nfo_parser import find_edition_from_nfo, clear_nfo_cache
from lib.filename_parser import parse_edition_from_filename
from lib.backup_manager import BackupManager


class PlannedChange:
    def __init__(self, id_movie, movie_title, id_file, filename, current_type, target_type, in_videoversion):
        self.id_movie = id_movie
        self.movie_title = movie_title
        self.id_file = id_file
        self.filename = filename
        self.current_type = current_type or "None"
        self.target_type = target_type
        self.in_videoversion = bool(in_videoversion)

    def __repr__(self):
        return "<Change [{}]: '{}' -> '{}' ({})>".format(
            self.movie_title, self.current_type, self.target_type, self.filename
        )


class UpdateResult:
    def __init__(self, total_scanned=0, changes_planned=None, applied_count=0, new_types_count=0, backup_info=None):
        self.total_scanned = total_scanned
        self.changes = changes_planned or []
        self.applied_count = applied_count
        self.new_types_count = new_types_count
        self.backup_info = backup_info


class VersionUpdater:
    def __init__(self, adapter, settings):
        self.adapter = adapter
        self.settings = settings
        self.backup_mgr = BackupManager(self.adapter, retention=self.settings.backup_retention)
        self.version_type_cache = {}  # lower_name -> id
        self.max_type_id = 40400

    def load_version_types(self):
        """Load all version types from videoversiontype table (itemType = 1)."""
        rows = self.adapter.query("SELECT id, name, owner, itemType FROM videoversiontype WHERE itemType = 1")
        self.version_type_cache.clear()
        max_id = 40400
        for r in rows:
            tid = r["id"]
            name = (r["name"] or "").strip()
            if name:
                self.version_type_cache[name.lower()] = tid
            if tid > max_id:
                max_id = tid
        self.max_type_id = max_id
        log("Loaded {} version types from database (max id: {})".format(
            len(self.version_type_cache), self.max_type_id
        ))

    def get_or_create_type_id(self, target_name):
        """Lookup type id by name, or insert a new custom user type (owner=2, itemType=1, range 40801+)."""
        norm_name = target_name.strip()
        key = norm_name.lower()
        if key in self.version_type_cache:
            return self.version_type_cache[key], False

        # Ensure user custom IDs start in Kodi's 40801+ range
        if self.max_type_id < 40800:
            next_id = 40801
        else:
            next_id = self.max_type_id + 1

        log("Inserting new custom version type '{}' (id: {}) into videoversiontype".format(norm_name, next_id))
        self.adapter.execute(
            "INSERT INTO videoversiontype (id, name, owner, itemType) VALUES (%s, %s, 2, 1)",
            (next_id, norm_name)
        )
        self.max_type_id = next_id
        self.version_type_cache[key] = next_id
        return next_id, True

    def fetch_all_movie_assets(self):
        """
        Query all movie files:
        1. Files already registered in videoversion table (including grouped versions).
        2. Movies in movie table that are not yet in videoversion table.
        """
        sql = """
        SELECT 
            m.idMovie,
            m.c00 AS movie_title,
            f.idFile,
            f.strFilename,
            p.strPath,
            v.idType,
            vt.name AS type_name,
            v.itemType,
            1 AS in_videoversion
        FROM movie m
        JOIN videoversion v ON m.idMovie = v.idMedia AND v.media_type = 'movie'
        JOIN files f ON v.idFile = f.idFile
        JOIN path p ON f.idPath = p.idPath
        LEFT JOIN videoversiontype vt ON v.idType = vt.id

        UNION ALL

        SELECT 
            m.idMovie,
            m.c00 AS movie_title,
            f.idFile,
            f.strFilename,
            p.strPath,
            NULL AS idType,
            NULL AS type_name,
            1 AS itemType,
            0 AS in_videoversion
        FROM movie m
        JOIN files f ON m.idFile = f.idFile
        JOIN path p ON f.idPath = p.idPath
        LEFT JOIN videoversion v ON m.idFile = v.idFile
        WHERE v.idFile IS NULL
        ORDER BY idMovie, idFile
        """
        return self.adapter.query(sql)

    def scan_for_changes(self, progress_callback=None):
        """
        Scans all movies, checks NFOs and filenames, and identifies planned changes.
        """
        clear_nfo_cache()
        self.load_version_types()
        assets = self.fetch_all_movie_assets()
        total = len(assets)
        log("Scanning {} movie asset entries in library...".format(total))

        planned_changes = []

        for idx, item in enumerate(assets):
            if progress_callback and idx % 20 == 0:
                keep_going = progress_callback(idx, total, item["movie_title"])
                if keep_going is False:
                    log("Scan cancelled by user.")
                    break

            id_movie = item["idMovie"]
            movie_title = item["movie_title"] or "Unknown"
            id_file = item["idFile"]
            filename = item["strFilename"] or ""
            path = item["strPath"] or ""
            current_type = (item["type_name"] or "").strip()
            in_videoversion = bool(item["in_videoversion"])

            # Determine if this item is eligible for update based on settings
            if self.settings.only_standard_edition:
                # Only update if current is 'Standard Edition' or has no type assigned
                if in_videoversion and current_type and current_type.lower() != "standard edition":
                    continue

            # 1. Search in NFO tags
            detected_edition = None
            if self.settings.scan_nfo:
                detected_edition = find_edition_from_nfo(path, filename)

            # 2. Fallback to filename parsing
            if not detected_edition and self.settings.scan_filenames:
                detected_edition = parse_edition_from_filename(filename)

                # 3. Also check parent folder name if filename had no edition tag
                if not detected_edition and path:
                    folder_name = os.path.basename(path.rstrip("/\\"))
                    detected_edition = parse_edition_from_filename(folder_name)

            if not detected_edition:
                continue

            # Compare detected edition with current type
            if current_type and current_type.lower() == detected_edition.lower():
                # Already up to date
                continue

            planned_changes.append(PlannedChange(
                id_movie=id_movie,
                movie_title=movie_title,
                id_file=id_file,
                filename=filename,
                current_type=current_type,
                target_type=detected_edition,
                in_videoversion=in_videoversion
            ))

        if progress_callback:
            progress_callback(total, total, "Scan complete")

        log("Scan found {} version updates to apply.".format(len(planned_changes)))
        return UpdateResult(total_scanned=total, changes_planned=planned_changes)

    def apply_changes(self, planned_changes, progress_callback=None):
        """
        Takes a backup and applies planned changes inside a database transaction.
        """
        if not planned_changes:
            return UpdateResult(total_scanned=0, applied_count=0)

        # Step 1: Create backup first!
        log("Taking backup before applying {} changes...".format(len(planned_changes)))
        backup_info = self.backup_mgr.create_backup()
        log("Backup completed: {}".format(backup_info.label))

        applied_count = 0
        new_types_count = 0
        total = len(planned_changes)

        try:
            for idx, change in enumerate(planned_changes):
                if progress_callback and idx % 10 == 0:
                    keep_going = progress_callback(idx, total, change.movie_title)
                    if keep_going is False:
                        log("Update cancelled by user, rolling back transaction...")
                        self.adapter.rollback()
                        raise RuntimeError("Update cancelled by user.")

                # Get or create videoversiontype
                type_id, was_created = self.get_or_create_type_id(change.target_type)
                if was_created:
                    new_types_count += 1

                if change.in_videoversion:
                    # Update existing record
                    self.adapter.execute(
                        "UPDATE videoversion SET idType = %s WHERE idFile = %s AND media_type = 'movie'",
                        (type_id, change.id_file)
                    )
                else:
                    # Insert new record into videoversion
                    self.adapter.execute(
                        "INSERT INTO videoversion (idFile, idMedia, media_type, itemType, idType) VALUES (%s, %s, 'movie', 1, %s)",
                        (change.id_file, change.id_movie, type_id)
                    )

                applied_count += 1

            self.adapter.commit()
            log("Successfully applied {} version changes ({} new types created).".format(
                applied_count, new_types_count
            ))

            return UpdateResult(
                total_scanned=total,
                changes_planned=planned_changes,
                applied_count=applied_count,
                new_types_count=new_types_count,
                backup_info=backup_info
            )
        except Exception as e:
            log("Error applying updates, rolling back transaction: {}".format(e), "error")
            self.adapter.rollback()
            raise
