# -*- coding: utf-8 -*-
"""
Filename parser for detecting video editions and cuts from file/folder names.
"""
import os
import re

# Explicit edition tag patterns (e.g. Radarr {edition-Director's Cut})
EXPLICIT_TAG_PATTERNS = [
    re.compile(r"[\{\[\(]edition[-_: ]+([^\}\]\)]+)[\}\]\)]", re.IGNORECASE),
]

# Standard edition keywords mapping (pattern -> normalized display name)
KNOWN_EDITIONS = [
    # Anniversary editions (e.g. 50th Anniversary Edition, 25th Anniversary)
    (re.compile(r"\b(\d+)(?:st|nd|rd|th)?[\s._-]anniversary[\s._-]*(?:edition|cut|version)?\b", re.IGNORECASE),
     lambda m: "{}th Anniversary Edition".format(m.group(1))),

    # Specific common cuts / editions
    (re.compile(r"\bdirector['’s]*[\s._-]*(?:cut|edition)\b", re.IGNORECASE), "Director's Cut"),
    (re.compile(r"\bextended[\s._-]*(?:cut|edition|version)\b", re.IGNORECASE), "Extended Edition"),
    (re.compile(r"\btheatrical[\s._-]*(?:cut|edition|version)\b", re.IGNORECASE), "Theatrical Cut"),
    (re.compile(r"\binternational[\s._-]*(?:cut|edition)\b", re.IGNORECASE), "International Cut"),
    (re.compile(r"\bunrated[\s._-]*(?:cut|edition|version)?\b", re.IGNORECASE), "Unrated Version"),
    (re.compile(r"\buncut[\s._-]*(?:version|edition)?\b", re.IGNORECASE), "Uncut Version"),
    (re.compile(r"\bremastered[\s._-]*(?:version|edition)?\b", re.IGNORECASE), "Remastered Version"),
    (re.compile(r"\bultimate[\s._-]collector['’s]*[\s._-]*(?:edition|cut)?\b", re.IGNORECASE), "Ultimate Collector's Edition"),
    (re.compile(r"\bcollector['’s]*[\s._-]*(?:edition|cut)\b", re.IGNORECASE), "Collector's Edition"),
    (re.compile(r"\bspecial[\s._-]*(?:edition|cut)\b", re.IGNORECASE), "Special Edition"),
    (re.compile(r"\blimited[\s._-]*(?:edition|cut)\b", re.IGNORECASE), "Limited Edition"),
    (re.compile(r"\bcomplete[\s._-]*(?:edition|cut)\b", re.IGNORECASE), "Complete Edition"),
    (re.compile(r"\bcriterion[\s._-]*(?:collection)?[\s._-]*(?:edition)?\b", re.IGNORECASE), "Criterion Collection Edition"),
    (re.compile(r"\b(?:the[\s._-]*)?final[\s._-]*cut\b", re.IGNORECASE), "The Final Cut"),
    (re.compile(r"\bsuper[\s._-]*duper[\s._-]*cut\b", re.IGNORECASE), "Super Duper Cut"),
    (re.compile(r"\bopen[\s._-]*matte\b", re.IGNORECASE), "Open Matte"),
    (re.compile(r"\bimax[\s._-]*(?:edition|version)?\b", re.IGNORECASE), "IMAX Edition"),
    (re.compile(r"\bblack[\s._-]*(?:and|&)?[\s._-]*white[\s._-]*(?:edition|version)?\b", re.IGNORECASE), "Black and White Edition"),
    (re.compile(r"\bfan[\s._-]*edit\b", re.IGNORECASE), "Fan Edit"),
    (re.compile(r"\brecut[\s._-]*(?:edition)?\b", re.IGNORECASE), "Recut Edition"),
    (re.compile(r"\brestored[\s._-]*(?:edition|version)?\b", re.IGNORECASE), "Restored Edition"),
]


def parse_edition_from_filename(filename):
    """
    Extract edition/version title from filename.
    Returns cleaned title string or None.
    """
    if not filename:
        return None

    # Strip extension
    base = os.path.splitext(filename)[0]

    # 1. Check for explicit {edition-XYZ} or [edition-XYZ]
    for pat in EXPLICIT_TAG_PATTERNS:
        m = pat.search(base)
        if m:
            raw = m.group(1).replace(".", " ").replace("_", " ").strip()
            # Clean up casing
            return clean_edition_text(raw)

    # 2. Check for bracketed edition phrases: e.g. [Director's Cut]
    bracket_m = re.findall(r"[\[\(]([^\(\)\[\]]+)[\]\)]", base)
    for chunk in bracket_m:
        matched = match_known_edition(chunk)
        if matched:
            return matched

    # 3. Check full filename for known editions
    matched = match_known_edition(base)
    if matched:
        return matched

    return None


def match_known_edition(text):
    """Matches text against known edition regex list."""
    # Replace dots and underscores with spaces for word boundary matching
    normalized = re.sub(r"[\._]+", " ", text)
    for pat, target in KNOWN_EDITIONS:
        m = pat.search(normalized)
        if m:
            if callable(target):
                return target(m)
            return target
    return None


def clean_edition_text(text):
    """Format an edition name with proper title casing."""
    words = text.split()
    capitalized = []
    for w in words:
        if w.lower() in ("and", "of", "the", "in", "on", "at", "to", "for"):
            capitalized.append(w.lower())
        else:
            capitalized.append(w.capitalize())
    if capitalized:
        capitalized[0] = capitalized[0].capitalize()
    return " ".join(capitalized)
