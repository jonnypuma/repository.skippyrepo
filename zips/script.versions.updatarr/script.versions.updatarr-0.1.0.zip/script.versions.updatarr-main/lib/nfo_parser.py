# -*- coding: utf-8 -*-
"""
NFO parser for extracting video version and edition metadata.
"""
import os
import re
import xml.etree.ElementTree as ET
from lib.kodi_compat import file_exists, read_text_file, log


def get_candidate_nfo_paths(video_path, video_filename):
    """
    Given a video folder path and filename, return candidate NFO file paths.
    Works with both local file paths and network VFS paths (nfs://, smb://).
    """
    base_folder = video_path.rstrip("/\\") + "/"
    name_without_ext = os.path.splitext(video_filename)[0]

    # Priority 1: Sidecar matching the exact video filename
    sidecar_nfo = base_folder + name_without_ext + ".nfo"
    # Priority 2: movie.nfo in the same directory
    movie_nfo = base_folder + "movie.nfo"

    return [sidecar_nfo, movie_nfo]


def parse_edition_from_xml(xml_content):
    """
    Parse XML string and search for version/edition tags.
    Returns cleaned edition string or None.
    """
    if not xml_content or not xml_content.strip():
        return None

    try:
        # Basic cleanup: remove invalid XML characters or XML declaration encoding mismatches
        root = ET.fromstring(xml_content)
    except Exception as e:
        # If XML parse failed, fallback to regex search
        log("XML parse error in NFO: {}, falling back to regex".format(e), "debug")
        return parse_edition_with_regex(xml_content)

    # 1. <videoassettitle> (Kodi native version tag)
    tag = root.find("videoassettitle")
    if tag is not None and tag.text and tag.text.strip():
        val = clean_version_string(tag.text)
        if val:
            return val

    # 2. <videoasset><title>
    asset = root.find("videoasset")
    if asset is not None:
        title_tag = asset.find("title")
        if title_tag is not None and title_tag.text and title_tag.text.strip():
            val = clean_version_string(title_tag.text)
            if val:
                return val

    # 3. <edition> (Radarr, Jellyfin, Emby, Plex)
    edition_tag = root.find("edition")
    if edition_tag is not None and edition_tag.text and edition_tag.text.strip():
        val = clean_version_string(edition_tag.text)
        if val:
            return val

    # 4. <version>
    version_tag = root.find("version")
    if version_tag is not None and version_tag.text and version_tag.text.strip():
        val = clean_version_string(version_tag.text)
        if val:
            return val

    return None


def parse_edition_with_regex(text):
    """Regex fallback to extract edition tags when XML parsing fails."""
    patterns = [
        r"<videoassettitle>\s*([^<]+?)\s*</videoassettitle>",
        r"<edition>\s*([^<]+?)\s*</edition>",
        r"<version>\s*([^<]+?)\s*</version>",
    ]
    for pat in patterns:
        m = re.search(pat, text, re.IGNORECASE)
        if m:
            val = clean_version_string(m.group(1))
            if val:
                return val
    return None


def clean_version_string(s):
    """Standardize and clean version text."""
    if not s:
        return None
    val = s.strip()
    # Normalize internal spaces
    val = re.sub(r"\s+", " ", val)
    # Ignore blank or placeholder names
    if not val or val.lower() in ("default", "none", "unknown"):
        return None
    return val


def find_edition_from_nfo(video_path, video_filename):
    """
    Search candidate NFO files for the movie and return detected edition.
    """
    candidates = get_candidate_nfo_paths(video_path, video_filename)
    for nfo_path in candidates:
        try:
            if file_exists(nfo_path):
                content = read_text_file(nfo_path)
                edition = parse_edition_from_xml(content)
                if edition:
                    log("Found edition '{}' in NFO: {}".format(edition, nfo_path), "debug")
                    return edition
        except Exception as e:
            log("Error reading candidate NFO {}: {}".format(nfo_path, e), "warning")
    return None
