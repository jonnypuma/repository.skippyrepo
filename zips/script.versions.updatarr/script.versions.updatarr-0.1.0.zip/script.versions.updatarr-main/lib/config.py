# -*- coding: utf-8 -*-
"""
Configuration reader and Kodi database detector.
"""
import os
import re
import xml.etree.ElementTree as ET
from lib.kodi_compat import (
    get_addon, translate_path, file_exists, read_text_file, list_dir, log
)


class DatabaseConfig:
    def __init__(self, db_type="sqlite", host=None, port=3306, name="MyVideos", user=None, password=None, sqlite_path=None):
        self.db_type = db_type.lower()  # 'sqlite' or 'mysql'
        self.host = host
        self.port = int(port) if port else 3306
        self.name = name
        self.user = user
        self.password = password
        self.sqlite_path = sqlite_path

    def __repr__(self):
        if self.db_type == "sqlite":
            return "<DatabaseConfig SQLite path='{}'>".format(self.sqlite_path)
        return "<DatabaseConfig MySQL host='{}:{}' db='{}' user='{}'>".format(
            self.host, self.port, self.name, self.user
        )


class AddonSettings:
    def __init__(self):
        addon = get_addon()
        if addon:
            self.scan_nfo = addon.getSettingBool("scan_nfo")
            self.scan_filenames = addon.getSettingBool("scan_filenames")
            self.only_standard_edition = addon.getSettingBool("only_standard_edition")
            self.backup_retention = max(3, addon.getSettingInt("backup_retention"))
            self.db_auto_detect = addon.getSettingBool("db_auto_detect")
            self.db_type = addon.getSetting("db_type") or "mysql"
            self.db_host = addon.getSetting("db_host") or "localhost"
            self.db_port = addon.getSettingInt("db_port") or 3306
            self.db_name = addon.getSetting("db_name") or "kodi22_videos"
            self.db_user = addon.getSetting("db_user") or "kodi"
            self.db_pass = addon.getSetting("db_pass") or "kodi"
        else:
            # Defaults for testing / CLI
            self.scan_nfo = True
            self.scan_filenames = True
            self.only_standard_edition = True
            self.backup_retention = 5
            self.db_auto_detect = True
            self.db_type = "mysql"
            self.db_host = "192.168.0.26"
            self.db_port = 3306
            self.db_name = "kodi22_videos"
            self.db_user = "Kodi"
            self.db_pass = "Kodi"


def parse_advanced_settings():
    """Parse advancedsettings.xml if present to detect MySQL/MariaDB config."""
    adv_path = translate_path("special://profile/advancedsettings.xml")
    if not file_exists(adv_path):
        log("No advancedsettings.xml found at {}".format(adv_path), "debug")
        return None

    try:
        content = read_text_file(adv_path)
        root = ET.fromstring(content)
        videodb = root.find("videodatabase")
        if videodb is None:
            return None

        db_type = (videodb.findtext("type") or "").strip().lower()
        if db_type in ("mysql", "mariadb"):
            host = (videodb.findtext("host") or "localhost").strip()
            port = int((videodb.findtext("port") or "3306").strip())
            name = (videodb.findtext("name") or "MyVideos").strip()
            user = (videodb.findtext("user") or "kodi").strip()
            password = (videodb.findtext("pass") or "kodi").strip()
            return DatabaseConfig(
                db_type="mysql",
                host=host,
                port=port,
                name=name,
                user=user,
                password=password
            )
    except Exception as e:
        log("Error parsing advancedsettings.xml: {}".format(e), "warning")
    return None


def find_latest_sqlite_db():
    """Find the latest MyVideos*.db in special://database/."""
    db_dir = translate_path("special://database/")
    if not file_exists(db_dir):
        return None

    _, files = list_dir(db_dir)
    pattern = re.compile(r"^MyVideos(\d+)\.db$", re.IGNORECASE)
    candidates = []
    for f in files:
        m = pattern.match(f)
        if m:
            version = int(m.group(1))
            candidates.append((version, os.path.join(db_dir, f)))

    if candidates:
        candidates.sort(key=lambda x: x[0], reverse=True)
        latest_version, latest_path = candidates[0]
        log("Found latest SQLite video database: MyVideos{}.db at {}".format(latest_version, latest_path))
        return DatabaseConfig(db_type="sqlite", sqlite_path=latest_path, name="MyVideos{}".format(latest_version))
    return None


def resolve_database_config(settings=None):
    """
    Resolve active database configuration using settings and auto-detection.
    """
    if settings is None:
        settings = AddonSettings()

    if settings.db_auto_detect:
        # Check advancedsettings.xml first for MySQL
        cfg = parse_advanced_settings()
        if cfg and cfg.db_type == "mysql":
            log("Auto-detected MySQL configuration from advancedsettings.xml")
            return cfg

        # Otherwise look for SQLite database file
        cfg = find_latest_sqlite_db()
        if cfg:
            log("Auto-detected SQLite configuration")
            return cfg

    # Manual fallback from addon settings
    if settings.db_type == "sqlite":
        cfg = find_latest_sqlite_db()
        if not cfg:
            db_dir = translate_path("special://database/")
            path = os.path.join(db_dir, "MyVideos.db")
            cfg = DatabaseConfig(db_type="sqlite", sqlite_path=path, name="MyVideos")
        return cfg
    else:
        return DatabaseConfig(
            db_type="mysql",
            host=settings.db_host,
            port=settings.db_port,
            name=settings.db_name,
            user=settings.db_user,
            password=settings.db_pass
        )
