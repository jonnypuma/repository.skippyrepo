# Changelog

All notable changes to **Video Versions Updatarr** (`script.versions.updatarr`) will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

---

## [0.1.0] - 2026-11-19

### Added
- **Core Video Version Updater:**
  - Automated scanning of movies to identify multi-version titles and editions.
  - Updates Kodi's `videoversion` table and registers new custom version types in `videoversiontype`.
  - Option to selectively update only entries currently designated as "Standard Edition" (preserving hand-configured versions).
- **Metadata Sources & Parsing:**
  - NFO parser prioritizing sidecar `<filename>.nfo` and folder `movie.nfo`.
  - Full support for `<videoassettitle>`, `<videoasset><title>`, `<edition>`, and `<version>` XML tags.
  - Robust regex fallback for filenames containing explicit edition tags (`{edition-...}`, `[edition-...]`) and recognized edition keywords (e.g. *50th Anniversary Edition*, *Director's Cut*, *International Cut*, *Criterion Collection Edition*, *Theatrical Cut*, *Unrated Version*, *Remastered Version*).
- **Database Engine Support:**
  - Full support for both **SQLite** (`MyVideos*.db`) and **MariaDB / MySQL**.
  - Auto-detection of database credentials from `advancedsettings.xml` (`<videodatabase>`), including dynamic version suffix resolution (e.g. `kodi22_videos154`).
  - Bundled pure-Python `pymysql` module for zero-dependency MariaDB / MySQL connectivity across Windows, Linux, CoreELEC/LibreELEC, and Android.
- **Backup & Restore System:**
  - Automatic backup creation before applying any database modification.
  - Dedicated **Create Database Backup** button on the main menu for standalone snapshots.
  - Enforced minimum backup retention policy: keeps at least **3 backups** at all times.
  - Interactive **Restore Database Backup** GUI tool with safety pre-restore snapshots.
- **User Interface & Artwork:**
  - Main menu modal with one-click actions: Scan & Update, Dry Run Preview, Create Backup, Restore Backup, and Settings.
  - Progress dialogs for scanning, updating, and restoring.
  - Custom 512x512 add-on icon (`icon.png`) and 1920x1080 cinematic widescreen fanart (`fanart.jpg`).
