# -*- coding: utf-8 -*-
import unittest
import os
import shutil
import tempfile
import sqlite3

from lib.nfo_parser import parse_edition_from_xml, parse_edition_with_regex
from lib.filename_parser import parse_edition_from_filename
from lib.db_adapter import SQLiteAdapter
from lib.backup_manager import BackupManager, MIN_BACKUPS_RETAINED


class TestNfoParser(unittest.TestCase):
    def test_videoassettitle_tag(self):
        xml = "<movie><title>Lawrence of Arabia</title><videoassettitle>50th Anniversary Edition</videoassettitle></movie>"
        self.assertEqual(parse_edition_from_xml(xml), "50th Anniversary Edition")

    def test_edition_tag(self):
        xml = "<movie><title>Leon</title><edition>International Cut</edition></movie>"
        self.assertEqual(parse_edition_from_xml(xml), "International Cut")

    def test_nested_videoasset_title(self):
        xml = "<movie><videoasset><title>Director's Cut</title></videoasset></movie>"
        self.assertEqual(parse_edition_from_xml(xml), "Director's Cut")

    def test_regex_fallback(self):
        malformed = "<movie><unclosed><edition>Collector's Edition</edition>"
        self.assertEqual(parse_edition_with_regex(malformed), "Collector's Edition")


class TestFilenameParser(unittest.TestCase):
    def test_anniversary_edition(self):
        filename = "Lawrence.of.Arabia.1962.50th.Anniversary.Edition.2160p.UHD.HDR.DV.BD.Remux.mkv"
        self.assertEqual(parse_edition_from_filename(filename), "50th Anniversary Edition")

    def test_international_cut(self):
        filename = "Leon.1994.International.Cut.UHD.BluRay.2160p.mkv"
        self.assertEqual(parse_edition_from_filename(filename), "International Cut")

    def test_directors_cut(self):
        filename = "Leon.aka.The.Professional.Directors.Cut.1994.BluRay.1080p.mkv"
        self.assertEqual(parse_edition_from_filename(filename), "Director's Cut")

    def test_explicit_edition_token(self):
        filename = "Blade.Runner.1982.{edition-The Final Cut}.2160p.mkv"
        self.assertEqual(parse_edition_from_filename(filename), "The Final Cut")

    def test_criterion_edition(self):
        filename = "Seven.Samurai.1954.Criterion.Collection.1080p.mkv"
        self.assertEqual(parse_edition_from_filename(filename), "Criterion Collection Edition")


class TestBackupAndRestoreSQLite(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.mkdtemp()
        self.db_path = os.path.join(self.temp_dir, "MyVideos146.db")

        # Create dummy SQLite database
        conn = sqlite3.connect(self.db_path)
        cur = conn.cursor()
        cur.execute("CREATE TABLE videoversion (idFile INT PRIMARY KEY, idType INT);")
        cur.execute("CREATE TABLE videoversiontype (id INT PRIMARY KEY, name TEXT);")
        cur.execute("INSERT INTO videoversiontype VALUES (40400, 'Standard Edition');")
        cur.execute("INSERT INTO videoversion VALUES (1, 40400);")
        conn.commit()
        conn.close()

        self.adapter = SQLiteAdapter(self.db_path)
        self.adapter.connect()
        self.backup_mgr = BackupManager(self.adapter, retention=3)
        self.backup_mgr.backup_dir = os.path.join(self.temp_dir, "backups")
        self.backup_mgr._ensure_backup_dir()

    def tearDown(self):
        self.adapter.close()
        shutil.rmtree(self.temp_dir)

    def test_backup_creation_and_listing(self):
        info = self.backup_mgr.create_backup()
        self.assertTrue(os.path.exists(info.identifier))
        backups = self.backup_mgr.list_backups()
        self.assertEqual(len(backups), 1)

    def test_minimum_retention_enforced(self):
        self.assertEqual(self.backup_mgr.retention, MIN_BACKUPS_RETAINED)
        self.assertGreaterEqual(self.backup_mgr.retention, 3)

        # Create 5 backups
        import time
        for i in range(5):
            # simulate different timestamps
            ts = "20261119_19000{}".format(i)
            bak_path = os.path.join(self.backup_mgr.backup_dir, "MyVideos146_bak_{}.db".format(ts))
            shutil.copy2(self.db_path, bak_path)

        # Prune
        self.backup_mgr._prune_sqlite_backups()
        remaining = self.backup_mgr.list_backups()
        self.assertEqual(len(remaining), 3)

    def test_restore_sqlite(self):
        # 1. Take initial backup with standard edition
        bak_info = self.backup_mgr.create_backup()

        # 2. Modify active DB
        self.adapter.execute("UPDATE videoversion SET idType = 999 WHERE idFile = 1;")
        self.adapter.commit()
        rows = self.adapter.query("SELECT idType FROM videoversion WHERE idFile = 1;")
        self.assertEqual(rows[0]["idType"], 999)

        # 3. Restore backup
        success = self.backup_mgr.restore_backup(bak_info)
        self.assertTrue(success)

        # 4. Verify restored value
        restored_rows = self.adapter.query("SELECT idType FROM videoversion WHERE idFile = 1;")
        self.assertEqual(restored_rows[0]["idType"], 40400)


if __name__ == "__main__":
    unittest.main()
