# Changelog

All notable changes to **Video Versions Updatarr** (`script.versions.updatarr`) will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

---

## [0.1.2] - 2026-11-19

### Added
- **Apply / Close Prompt on Dry Run:** After closing the Dry Run Preview report, users are prompted with **Apply** (creates backup and writes the previewed changes without re-scanning) or **Close** (exits without modifying the database).

### Fixed
- Replaced unsupported `➜` Unicode arrow (`U+279C`) with ASCII `->` in summary and Dry Run dialogs so Kodi's skin font no longer renders a missing-glyph rectangle (`□`).

---

## [0.1.1] - 2026-11-19

### Fixed
- Bumped version to `0.1.1` to bypass Kodi's cached `0.1.0` package zip containing old `settings.xml` without `<control>` tags.
- Isolated unit test backup paths from Kodi's live `userdata/addon_data/` folder.

---

## [0.1.0] - 2026-11-19

### Added
- **Default Version Swapping:**
  - Added "🌟 Manage Default Versions" interactive modal allowing users to switch which version file is the active default in Kodi.
  - Automatically queries and displays all multi-version movies and TV episodes with their current active default.
  - Seamlessly updates `movie.idFile` and `episode.idFile` directly in the database.
  - Optional automatic watch status synchronization (`playCount`, `lastPlayed`) from the old default file to the new default file.
  - Dedicated CLI and RPC shortcut: `--defaults` / `action=defaults`.
- **TV Episode Versions Support:**
  - Extended automated version detection, assignment, and management to TV episodes (`media_type = 'episode'`).
  - Scans both existing multi-version episodes and candidate episode files with release/edition tokens.
  - Configurable scan targets (`scan_movies` and `scan_episodes` settings).
- **Core Video Version Updater:**
  - Automated scanning of movies and episodes to identify multi-version titles and editions.
  - Updates Kodi's `videoversion` table and registers new custom version types in `videoversiontype`.
  - Automatically adheres to Kodi's custom version type ID convention (`40801+`).
  - Option to selectively update only entries currently designated as "Standard Edition" (preserving hand-configured versions).
- **Metadata Sources & Parsing:**
  - NFO parser prioritizing sidecar `<filename>.nfo` and folder `movie.nfo` with directory caching and XML entity unescaping.
  - Full support for `<videoassettitle>`, `<videoasset><title>`, `<edition>`, and `<version>` XML tags.
  - Robust regex fallback for filenames containing explicit edition tags (`{edition-...}`, `[edition-...]`) and recognized edition keywords (e.g. *50th Anniversary Edition*, *Director's Cut*, *International Cut*, *European Cut*, *Broadcast Cut*, *Alternate Cut*, *Criterion Collection Edition*, *Theatrical Cut*, *Unrated Version*, *Remastered Version*).
  - Proper English ordinal generation for anniversary editions (*21st*, *22nd*, *23rd*, *50th*).
- **Database Engine Support:**
  - Full support for both **SQLite** (`MyVideos*.db`) and **MariaDB / MySQL**.
  - Auto-detection of database credentials from `advancedsettings.xml` (`<videodatabase>`), including dynamic version suffix resolution (e.g. `kodi22_videos154`).
  - Bundled pure-Python `pymysql` module for zero-dependency MariaDB / MySQL connectivity across Windows, Linux, CoreELEC/LibreELEC, and Android.
- **Backup & Restore System:**
  - Automatic backup creation before applying any database modification or default swap.
  - Dedicated **Create Database Backup** button on the main menu for standalone snapshots.
  - Enforced minimum backup retention policy: keeps at least **3 backups** at all times (default: 3, configurable up to 20).
  - Interactive **Restore Database Backup** GUI tool with safety pre-restore snapshots.
- **Background Scheduling & Automation:**
  - Integrated `xbmc.service` background monitor.
  - Automatic version updating upon completion of Kodi video library scans (`onScanFinished`).
  - Periodic background scheduler with configurable interval (every 2h, 6h, 12h, 24h, 3 days, or weekly).
  - Optional run-on-startup trigger.
  - Optional completion notifications.
- **User Interface & Artwork:**
  - Main menu modal with one-click actions: Scan & Update, Dry Run Preview, Manage Default Versions, Create Backup, Restore Backup, and Settings.
  - Kodi Context Menu integration under **Manage › Update Video Version (Updatarr)** supporting both movies and TV episodes for instant default swapping or custom version editing.
  - Automatic `Container.Refresh` triggering so updated version badges display instantly without Kodi restarts.
  - Progress dialogs for scanning, updating, and restoring.
  - Custom 512x512 add-on icon (`icon.png`) and 1920x1080 cinematic widescreen fanart (`fanart.jpg`).
