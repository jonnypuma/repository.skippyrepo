# script.versions.updatarr

**Video Versions Updatarr** is a Kodi add-on (compatible with Kodi 21 Omega and Kodi 22 Piers) that automatically assigns and updates Kodi Video Version types directly in Kodi's database.

- **Author:** Skippy-McSkipface
- **Website:** [jonnypuma/script.versions.updatarr](https://github.com/jonnypuma/script.versions.updatarr) / [jonnypuma.github.io](https://jonnypuma.github.io)

---

## The Problem

In Kodi v21+, when videos have multiple versions or editions (e.g. *Director's Cut*, *Extended Edition*, *50th Anniversary Edition*), Kodi groups them into video versions. However:
1. Video versions default to **"Standard Edition"** during auto-grouping scans.
2. Kodi exports `<videoassettitle>` to `.nfo` files, but importing version names during library scans is incomplete.
3. Edition tags in `.nfo` files (`<edition>`) and filenames (e.g., `Lawrence.of.Arabia.1962.50th.Anniversary.Edition...mkv`) are ignored by Kodi's built-in scanner.
4. Kodi's JSON-RPC API does not offer endpoints to create or assign video versions.
5. TV Episodes with alternate cuts (e.g. Extended, Unrated, European Cut, Broadcast) are difficult to manage.
6. Changing which version is the default playback file requires manual intervention.

## The Solution

**Video Versions Updatarr** inspects your library, reads `<videoassettitle>` / `<edition>` tags from sidecar NFOs and filename edition patterns, automatically inserts custom version types into the `videoversiontype` table, and links them in `videoversion`. It also allows swapping which version is the default with one click and synchronizes watched status.

---

## Features

- **Full Movie & TV Episode Support:** Detects, creates, and assigns video versions for both movies and multi-version TV episodes.
- **Default Version Swapping:** Easily choose which file is the primary/default version in Kodi for any multi-version movie or episode. Optionally copies watched status (`playCount`, `lastPlayed`) to the new default file.
- **Context Menu Integration:** Right-click or press `C` / long-press on any movie or TV episode in Kodi to quickly assign custom versions or swap the default version on the spot.
- **Automatic Database Detection:** Reads `advancedsettings.xml` automatically. If MariaDB / MySQL is configured, it connects using existing network credentials and finds the active schema (e.g., `kodi22_videos154`). If SQLite is used, it detects `MyVideos*.db`.
- **Integrated Pure-Python MySQL:** Includes bundled PyMySQL so MariaDB/MySQL works out of the box on all Kodi platforms (Windows, Android, CoreELEC/LibreELEC, Linux).
- **Safety First - Guaranteed 3+ Backups:**
  - Before applying any updates or swapping defaults, a full backup is created automatically.
  - **SQLite:** Copies `.db` to a timestamped backup file in `special://profile/addon_data/script.versions.updatarr/backups/`.
  - **MariaDB / MySQL:** Creates database snapshots (`videoversion_bak_<timestamp>` and `videoversiontype_bak_<timestamp>`).
  - **Retention Policy:** Keeps at least **3 backups** at all times (user-configurable up to 20). Older backups are only pruned when the retention count is exceeded.
- **Standalone Backup Button:** Create an on-demand database backup at any time from the main menu without running a scan.
- **Easy Restore from Backup:**
  - Dedicated "Restore Database Backup" menu option allows selecting and restoring any previous backup snapshot with a single click.
  - Automatically creates a safety pre-restore snapshot before applying any restore.
- **Background Scheduler & Library Scan Hook:** Optionally runs automatically on startup, every X hours/days, or right after a Kodi library scan completes.
- **Dry Run Mode:** Preview all planned changes in a readable report before modifying anything.
- **Safe Selective Updates:** Only updates versions that are currently set to "Standard Edition" or unassigned by default, preserving any custom editions you already set by hand (configurable).

---

## Installation in Kodi

Copy or symlink the `script.versions.updatarr` folder into your Kodi `addons/` directory:
- **Windows:** `%APPDATA%\Kodi\addons\script.versions.updatarr`
- **Linux / CoreELEC:** `~/.kodi/addons/script.versions.updatarr`
- **Android:** `/Android/data/org.xbmc.kodi/files/.kodi/addons/script.versions.updatarr`

Restart Kodi or select **Add-ons › Install from zip file** / update add-ons.

---

## Usage

### In Kodi GUI
Launch **Video Versions Updatarr** from **Programs / Add-ons**:
1. **🚀 Scan & Update Video Versions:** Scans movies and TV episodes, shows a summary of updates found, confirms, takes a backup, and updates the database.
2. **🔍 Dry Run (Preview Changes):** Scans and displays a full list of detected titles, filenames, and target versions, then lets you choose **Apply** (back up & write changes immediately) or **Close** without modifying the database.
3. **🌟 Manage Default Versions:** Lists all multi-version movies and TV episodes, showing their current default version, and allows swapping to any other version with automatic watch count transfer.
4. **💾 Create Database Backup:** On-demand standalone backup snapshot created directly without running a scan.
5. **🔄 Restore Database Backup:** Lists all available backup snapshots (with timestamps and row counts) and lets you restore any of them.
6. **⚙️ Settings:** Configure NFO vs. filename detection, movie/episode toggles, schedule frequency, backup retention count (minimum 3), or override database credentials.

### Context Menu
In your Movie or TV Show library:
1. Open the context menu (`C` or right-click) on any movie or episode.
2. Select **Manage... › Update Video Version (Updatarr)**.
3. Choose to swap the active default version or assign/edit version names directly.

### Command Line / JSON-RPC
You can also run the script directly:
```bash
python main.py --dry-run
python main.py --scan
python main.py --defaults
python main.py --backup
python main.py --restore
```
Or via Kodi JSON-RPC / built-in function:
```python
xbmc.executebuiltin('RunScript(script.versions.updatarr, action=scan)')
xbmc.executebuiltin('RunScript(script.versions.updatarr, action=defaults)')
```

---

## License

MIT License. See [addon.xml](addon.xml) for metadata.
