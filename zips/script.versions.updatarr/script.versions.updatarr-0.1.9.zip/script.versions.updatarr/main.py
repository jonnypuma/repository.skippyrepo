# -*- coding: utf-8 -*-
"""
Main execution script and GUI controller for script.versions.updatarr.
"""
import sys
import os

# Add addon directory to sys.path
ADDON_DIR = os.path.dirname(os.path.abspath(__file__))
if ADDON_DIR not in sys.path:
    sys.path.insert(0, ADDON_DIR)

from lib.kodi_compat import (
    is_kodi, get_addon, log, show_notification, show_ok_dialog,
    show_yesno_dialog, show_select_dialog, show_text_dialog, ProgressDialog
)
from lib.config import AddonSettings, resolve_database_config
from lib.db_adapter import get_adapter_for_config
from lib.backup_manager import BackupManager
from lib.version_updater import VersionUpdater, find_normalizable_labels, apply_label_normalization
from lib.default_version_manager import get_multiversion_items, swap_default_version
from lib.run_logger import build_summary_lines, write_run_log


def run_scan_and_update(dry_run=False):
    settings = AddonSettings()
    config = resolve_database_config(settings)
    log("Resolved DB configuration: {}".format(config))

    try:
        adapter = get_adapter_for_config(config)
        adapter.connect()
    except Exception as e:
        log("Failed to connect to database: {}".format(e), "error")
        show_ok_dialog(
            "Connection Error",
            "Could not connect to Kodi video database:\n{}\n\nPlease check addon settings.".format(e)
        )
        return

    targets = []
    if settings.scan_movies:
        targets.append("Movies")
    if settings.scan_episodes:
        targets.append("TV")
    targets_label = " + ".join(targets) if targets else "None"

    db_label = adapter.get_display_name()
    mode_label = "Dry Run: " if dry_run else ""
    progress = ProgressDialog(
        "Video Versions Updatarr",
        "{}Scanning {} [{}]...".format(mode_label, db_label, targets_label)
    )
    updater = VersionUpdater(adapter, settings)

    def on_progress(current, total, title, found_count=0):
        pct = (float(current) / float(total)) * 100 if total > 0 else 0
        progress.update(
            pct,
            "{}Scanning {} [{}] ({}/{}) | Found: {}".format(
                mode_label, db_label, targets_label, current, total, found_count
            ),
            title
        )
        return not progress.is_canceled()

    try:
        scan_res = updater.scan_for_changes(progress_callback=on_progress)
    finally:
        progress.close()

    changes = scan_res.changes
    if not changes:
        show_ok_dialog("Scan Complete", "Your video versions are already up to date! No changes needed.")
        adapter.close()
        return

    # Build summary lines for display
    summary_lines = [
        "Found {} version update(s) to apply:".format(len(changes)),
        ""
    ]
    for ch in changes[:10]:
        tag = "[Movie]" if ch.media_type == "movie" else "[Episode]"
        summary_lines.append(u"• {} {}: '{}' -> '{}'".format(
            tag, ch.title, ch.current_type, ch.target_type
        ))
    if len(changes) > 10:
        summary_lines.append("... and {} more.".format(len(changes) - 10))

    if dry_run:
        full_report = build_summary_lines(
            config=config,
            total_scanned=scan_res.total_scanned,
            changes=changes,
            is_dry_run=True
        )
        show_text_dialog("Dry Run Preview", "\n".join(full_report))
        if is_kodi():
            import xbmc
            xbmc.sleep(200)

        dry_choice = show_select_dialog(
            "Dry Run Complete ({} updates found)".format(len(changes)),
            [
                "Apply {} Changes to {}".format(len(changes), db_label),
                "Close without Applying"
            ]
        )
        if dry_choice != 0:
            adapter.close()
            return
    else:
        # Real run: confirm with user first
        confirm_msg = "{}\n\nA backup will be created before any changes are written. Proceed with updating the database?".format(
            "\n".join(summary_lines)
        )
        if not show_yesno_dialog("Confirm Database Update", confirm_msg):
            adapter.close()
            return

    # Apply updates with progress dialog
    apply_progress = ProgressDialog(
        "Video Versions Updatarr",
        "Creating backup & updating {}...".format(db_label)
    )

    def on_apply_progress(current, total, title):
        pct = (float(current) / float(total)) * 100 if total > 0 else 0
        apply_progress.update(
            pct,
            "Updating {} ({}/{})...".format(db_label, current, total),
            title
        )
        return not apply_progress.is_canceled()

    try:
        res = updater.apply_changes(changes, progress_callback=on_apply_progress)
        apply_progress.close()

        summary_report = build_summary_lines(
            config=config,
            total_scanned=scan_res.total_scanned,
            changes=changes,
            applied_count=res.applied_count,
            new_types=res.new_types_created,
            backup_info=res.backup_info
        )
        log_path = write_run_log(summary_report)
        if log_path:
            summary_report = build_summary_lines(
                config=config,
                total_scanned=scan_res.total_scanned,
                changes=changes,
                applied_count=res.applied_count,
                new_types=res.new_types_created,
                backup_info=res.backup_info,
                log_path=log_path
            )

        show_text_dialog("Update Summary", "\n".join(summary_report))
        show_notification("Video Versions Updatarr", "Updated {} versions".format(res.applied_count))
        if is_kodi():
            import xbmc
            xbmc.executebuiltin("Container.Refresh")
    except Exception as e:
        apply_progress.close()
        log("Error during update: {}".format(e), "error")
        err_report = build_summary_lines(
            config=config,
            total_scanned=scan_res.total_scanned,
            changes=changes,
            applied_count=0,
            error_msg=str(e)
        )
        log_path = write_run_log(err_report)
        err_msg = "An error occurred during database update:\n{}".format(e)
        if log_path:
            err_msg += "\n\nLog saved to:\n{}".format(log_path)
        show_ok_dialog("Update Failed", err_msg)
    finally:
        adapter.close()


def run_manual_backup():
    settings = AddonSettings()
    config = resolve_database_config(settings)
    log("Resolved DB configuration for manual backup: {}".format(config))

    try:
        adapter = get_adapter_for_config(config)
        adapter.connect()
    except Exception as e:
        log("Failed to connect to database: {}".format(e), "error")
        show_ok_dialog("Connection Error", "Could not connect to database for backup:\n{}".format(e))
        return

    progress = ProgressDialog("Video Versions Updatarr", "Creating database backup...")
    try:
        mgr = BackupManager(adapter, retention=settings.backup_retention)
        bak_info = mgr.create_backup()
        progress.close()
        show_ok_dialog(
            "Backup Successful",
            "Database backup created successfully!\n\nIdentifier: {}\nDetails: {}".format(
                bak_info.label, bak_info.extra_info
            )
        )
        show_notification("Video Versions Updatarr", "Backup created")
    except Exception as e:
        progress.close()
        log("Error during backup: {}".format(e), "error")
        show_ok_dialog("Backup Failed", "Failed to create database backup:\n{}".format(e))
    finally:
        adapter.close()


def run_restore():
    settings = AddonSettings()
    config = resolve_database_config(settings)
    log("Resolving DB for restore: {}".format(config))

    try:
        adapter = get_adapter_for_config(config)
        adapter.connect()
    except Exception as e:
        log("Failed to connect to database: {}".format(e), "error")
        show_ok_dialog("Connection Error", "Could not connect to database for restore:\n{}".format(e))
        return

    mgr = BackupManager(adapter, retention=settings.backup_retention)
    backups = mgr.list_backups()

    if not backups:
        adapter.close()
        show_ok_dialog("Restore Backup", "No database backups were found.")
        return

    menu_items = []
    for b in backups:
        menu_items.append("{} | {}".format(b.label, b.extra_info))

    idx = show_select_dialog("Select a Backup to Restore", menu_items)
    if idx < 0 or idx >= len(backups):
        adapter.close()
        return

    selected_backup = backups[idx]
    confirm_text = "Are you sure you want to restore the database to:\n\n{}\n\n(A safety pre-restore backup will be created automatically before restoring)".format(
        selected_backup.label
    )
    if not show_yesno_dialog("Confirm Restore", confirm_text):
        adapter.close()
        return

    progress = ProgressDialog("Restoring Backup", "Restoring video version database...")
    try:
        mgr.restore_backup(selected_backup)
        progress.close()
        show_ok_dialog(
            "Restore Complete",
            "Database has been successfully restored to:\n{}".format(selected_backup.label)
        )
        show_notification("Video Versions Updatarr", "Restore complete")
        if is_kodi():
            import xbmc
            xbmc.executebuiltin("Container.Refresh")
    except Exception as e:
        progress.close()
        log("Error during restore: {}".format(e), "error")
        show_ok_dialog("Restore Failed", "Failed to restore backup:\n{}".format(e))
    finally:
        adapter.close()


def run_manage_default_versions():
    settings = AddonSettings()
    config = resolve_database_config(settings)
    log("Resolving DB for manage default versions: {}".format(config))

    try:
        adapter = get_adapter_for_config(config)
        adapter.connect()
    except Exception as e:
        log("Failed to connect to database: {}".format(e), "error")
        show_ok_dialog("Connection Error", "Could not connect to database:\n{}".format(e))
        return

    try:
        while True:
            # Fetch all multi-version items
            items = get_multiversion_items(adapter)
            if not items:
                show_ok_dialog("Default Versions", "No multi-version movies or episodes found in the database.")
                break

            display_items = []
            for it in items:
                tag = "🎬 [Movie]" if it.media_type == "movie" else "📺 [TV]"
                def_ver = it.get_default_version()
                def_name = def_ver.type_name if def_ver else "Unknown"
                display_items.append(u"{} {}  (Default: {})".format(tag, it.title, def_name))

            selected_idx = show_select_dialog("Select Title to Manage Versions", display_items)
            if selected_idx < 0 or selected_idx >= len(items):
                break

            chosen_item = items[selected_idx]

            # Show versions for chosen item
            ver_labels = []
            for v in chosen_item.versions:
                star = "★ " if v.is_default else "  "
                status = " [ACTIVE DEFAULT]" if v.is_default else ""
                ver_labels.append(u"{}{}{} ({})".format(star, v.type_name, status, v.filename))

            v_idx = show_select_dialog(
                u"Select Default Version for: {}".format(chosen_item.title),
                ver_labels
            )
            if v_idx < 0 or v_idx >= len(chosen_item.versions):
                continue

            chosen_ver = chosen_item.versions[v_idx]
            if chosen_ver.is_default:
                show_notification("Video Versions Updatarr", "'{}' is already the default version.".format(chosen_ver.type_name))
                continue

            confirm_msg = u"Set '{}' as the new default version for:\n\n{}\n\nFile: {}\n\n(A database backup will be created before updating)".format(
                chosen_ver.type_name, chosen_item.title, chosen_ver.filename
            )
            if not show_yesno_dialog("Confirm Default Version Change", confirm_msg):
                continue

            try:
                swap_default_version(
                    adapter,
                    id_media=chosen_item.id_media,
                    media_type=chosen_item.media_type,
                    target_file_id=chosen_ver.id_file,
                    sync_watched=settings.sync_watched_on_swap,
                    retention=settings.backup_retention
                )
                show_ok_dialog(
                    "Default Version Updated",
                    u"Successfully set default version to:\n'{}'\n\nTitle: {}".format(
                        chosen_ver.type_name, chosen_item.title
                    )
                )
                show_notification("Video Versions Updatarr", u"Default set to '{}'".format(chosen_ver.type_name))
                if is_kodi():
                    import xbmc
                    xbmc.executebuiltin("Container.Refresh")
            except Exception as e:
                log("Error swapping default version: {}".format(e), "error")
                show_ok_dialog("Update Failed", "Could not swap default version:\n{}".format(e))

    finally:
        adapter.close()


def run_normalize_db_labels():
    settings = AddonSettings()
    config = resolve_database_config(settings)
    log("Resolving DB for normalizing version labels: {}".format(config))

    try:
        adapter = get_adapter_for_config(config)
        adapter.connect()
    except Exception as e:
        log("Failed to connect to database: {}".format(e), "error")
        show_ok_dialog("Connection Error", "Could not connect to database:\n{}".format(e))
        return

    db_label = adapter.get_display_name()
    try:
        mappings = find_normalizable_labels(adapter)
        if not mappings:
            show_ok_dialog(
                "Normalize Version Labels",
                "All version labels in {} are already normalized!".format(db_label)
            )
            return

        total_rows = sum(m[3] for m in mappings)
        preview_lines = [
            "=== Normalize Version Labels: {} ===".format(db_label),
            "Label groups to normalize: {}".format(len(mappings)),
            "Total video version rows affected: {}".format(total_rows),
            "--------------------------------------------------",
            ""
        ]
        for old_id, old_name, target_name, cnt in mappings:
            preview_lines.append(u"• '{}' (ID: {}, {} item(s)) -> '{}'".format(
                old_name, old_id, cnt, target_name
            ))

        show_text_dialog("Normalize Version Labels Preview", "\n".join(preview_lines))
        if is_kodi():
            import xbmc
            xbmc.sleep(200)

        choice = show_select_dialog(
            "Apply Label Normalization ({} rows)?".format(total_rows),
            [
                "Apply Normalization to {}".format(db_label),
                "Cancel"
            ]
        )
        if choice != 0:
            return

        updated_rows, removed_types, backup_info = apply_label_normalization(
            adapter, mappings, retention=settings.backup_retention
        )

        report_lines = [
            "=== Normalize Version Labels: Complete ===",
            "Database: {}".format(db_label),
            "Rows updated: {}".format(updated_rows),
            "Orphaned custom types removed: {}".format(removed_types),
            "Backup: {}".format(backup_info.label if backup_info else "None"),
            "--------------------------------------------------",
            ""
        ] + [
            u"• '{}' -> '{}' ({} item(s))".format(old_name, target_name, cnt)
            for _oid, old_name, target_name, cnt in mappings
        ]
        log_path = write_run_log(report_lines)
        if log_path:
            report_lines.insert(5, "Log file: {}".format(log_path))

        show_text_dialog("Normalization Complete", "\n".join(report_lines))
        show_notification("Video Versions Updatarr", "Normalized {} version row(s)".format(updated_rows))
        if is_kodi():
            import xbmc
            xbmc.executebuiltin("Container.Refresh")
    except Exception as e:
        log("Error normalizing DB labels: {}".format(e), "error")
        show_ok_dialog("Normalization Failed", "An error occurred while normalizing labels:\n{}".format(e))
    finally:
        adapter.close()


def open_settings():
    addon = get_addon()
    if addon:
        addon.openSettings()


def main():
    args = sys.argv[1:] if len(sys.argv) > 1 else []

    if "--scan" in args or "action=scan" in args:
        run_scan_and_update(dry_run=False)
        return
    elif "--dry-run" in args or "action=dryrun" in args:
        run_scan_and_update(dry_run=True)
        return
    elif "--defaults" in args or "action=defaults" in args:
        run_manage_default_versions()
        return
    elif "--normalize" in args or "action=normalize" in args:
        run_normalize_db_labels()
        return
    elif "--backup" in args or "action=backup" in args:
        run_manual_backup()
        return
    elif "--restore" in args or "action=restore" in args:
        run_restore()
        return

    # Interactive GUI Menu
    menu_options = [
        "🚀 Scan & Update Video Versions",
        "🔍 Dry Run (Preview Changes)",
        "🌟 Manage Default Versions",
        "🧹 Normalize Version Labels in DB",
        "💾 Create Database Backup",
        "🔄 Restore Database Backup",
        "⚙️ Settings"
    ]

    choice = show_select_dialog("Video Versions Updatarr", menu_options)
    if choice == 0:
        run_scan_and_update(dry_run=False)
    elif choice == 1:
        run_scan_and_update(dry_run=True)
    elif choice == 2:
        run_manage_default_versions()
    elif choice == 3:
        run_normalize_db_labels()
    elif choice == 4:
        run_manual_backup()
    elif choice == 5:
        run_restore()
    elif choice == 6:
        open_settings()


if __name__ == "__main__":
    main()
