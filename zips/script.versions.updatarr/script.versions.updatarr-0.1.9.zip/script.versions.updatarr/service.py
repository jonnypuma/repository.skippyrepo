# -*- coding: utf-8 -*-
"""
Background service for script.versions.updatarr.
Handles scheduled runs, scan-completion triggers, and startup runs.
"""
import sys
import os
import time

ADDON_DIR = os.path.dirname(os.path.abspath(__file__))
if ADDON_DIR not in sys.path:
    sys.path.insert(0, ADDON_DIR)

from lib.kodi_compat import is_kodi, log, show_notification
from lib.config import AddonSettings, resolve_database_config
from lib.db_adapter import get_adapter_for_config
from lib.version_updater import VersionUpdater

try:
    import xbmc
    HAS_XBMC = True
except ImportError:
    HAS_XBMC = False


def run_silent_update():
    """Performs an automated background scan and update."""
    log("Running automated background version update...")
    settings = AddonSettings()
    config = resolve_database_config(settings)

    try:
        adapter = get_adapter_for_config(config)
        adapter.connect()
    except Exception as e:
        log("Background update: database connection failed: {}".format(e), "error")
        return 0

    try:
        updater = VersionUpdater(adapter, settings)
        scan_res = updater.scan_for_changes()
        changes = scan_res.changes

        if not changes:
            log("Background update: no version changes needed.")
            return 0

        res = updater.apply_changes(changes)
        log("Background update applied: {} version(s) updated.".format(res.applied_count))

        if settings.notify_on_update and res.applied_count > 0:
            show_notification(
                "Video Versions Updatarr",
                "Updated {} video version(s)".format(res.applied_count)
            )
        if HAS_XBMC and res.applied_count > 0:
            xbmc.executebuiltin("Container.Refresh")
        return res.applied_count
    except Exception as e:
        log("Background update failed with exception: {}".format(e), "error")
        return 0
    finally:
        adapter.close()


if HAS_XBMC:
    class UpdatarrMonitor(xbmc.Monitor):
        def __init__(self):
            super().__init__()
            self.scan_triggered = False

        def onScanFinished(self, library):
            if library == "video":
                log("Video library scan finished detected by service.")
                self.scan_triggered = True


def service_main():
    log("Video Versions Updatarr service started.")
    if not HAS_XBMC:
        log("Not running inside Kodi, service exiting.", "debug")
        return

    monitor = UpdatarrMonitor()
    settings = AddonSettings()

    # Startup run if enabled
    if settings.schedule_enabled and settings.run_on_startup:
        # Give Kodi a moment to initialize
        if not monitor.waitForAbort(15):
            run_silent_update()

    last_schedule_run = time.time()

    # Main loop (checks every 10 seconds)
    while not monitor.abortRequested():
        if monitor.waitForAbort(10):
            break

        settings = AddonSettings()
        if not settings.schedule_enabled:
            monitor.scan_triggered = False
            continue

        # Check library scan trigger
        if monitor.scan_triggered:
            monitor.scan_triggered = False
            if settings.run_on_scan:
                # Wait 5 seconds after scan ends before updating
                if not monitor.waitForAbort(5):
                    run_silent_update()
                    last_schedule_run = time.time()
                continue

        # Check periodic schedule interval
        interval_seconds = max(1, settings.schedule_interval) * 3600
        if (time.time() - last_schedule_run) >= interval_seconds:
            run_silent_update()
            last_schedule_run = time.time()

    log("Video Versions Updatarr service stopped.")


if __name__ == "__main__":
    service_main()
