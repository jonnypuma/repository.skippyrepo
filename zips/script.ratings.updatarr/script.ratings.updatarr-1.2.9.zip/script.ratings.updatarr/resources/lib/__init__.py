"""Ratings Updatarr library."""
