"""Ratings Updatarr library."""
