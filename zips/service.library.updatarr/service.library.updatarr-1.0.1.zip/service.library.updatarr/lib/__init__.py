"""Library Updatarr core package."""
