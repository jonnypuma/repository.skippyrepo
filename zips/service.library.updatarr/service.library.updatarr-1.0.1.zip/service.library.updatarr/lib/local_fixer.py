"""Apply local artwork and NFO metadata."""

from __future__ import annotations

import os
import xml.etree.ElementTree as ET

import xbmcvfs

from lib.jsonrpc import jsonrpc, log
from lib.missing import missing_art_types, missing_metadata_fields
from lib.models import LibraryItem
from lib.scanner import fetch_item_details
from lib.settings import UpdatarrSettings


def _show_folder_for_item(item: LibraryItem, settings: UpdatarrSettings) -> str:
    if item.file_path and not item.file_path.startswith("videodb://"):
        if item.item_type in ("tvshow", "movie", "episode"):
            return os.path.dirname(item.file_path)
        return item.file_path

    if item.item_type == "season" and item.tvshowid:
        show = fetch_item_details(LibraryItem("tvshow", item.tvshowid), settings)
        if show and show.file_path and not show.file_path.startswith("videodb://"):
            return os.path.dirname(show.file_path)
    return ""


def _kodi_path(path: str) -> str:
    return path.replace("\\", "/")


def _nfo_path_for_item(item: LibraryItem) -> str | None:
    if not item.file_path:
        return None

    if item.item_type == "movie":
        base, _ = os.path.splitext(item.file_path)
        return f"{base}.nfo"
    if item.item_type == "tvshow":
        media_dir = _show_folder_for_item(item, settings)
        if media_dir:
            return os.path.join(media_dir, "tvshow.nfo")
    if item.item_type == "episode":
        base, _ = os.path.splitext(item.file_path)
        return f"{base}.nfo"
    return None


def _artwork_candidates(item: LibraryItem) -> list[tuple[str, str]]:
    if not item.file_path and item.item_type != "season":
        return []

    candidates: list[tuple[str, str]] = []

    if item.item_type == "movie":
        media_dir = os.path.dirname(item.file_path)
        candidates += [
            ("poster", os.path.join(media_dir, "poster.jpg")),
            ("fanart", os.path.join(media_dir, "fanart.jpg")),
            ("thumb", os.path.join(media_dir, "thumb.jpg")),
        ]
    elif item.item_type == "tvshow":
        media_dir = _show_folder_for_item(item, settings)
        if media_dir:
            candidates += [
                ("poster", os.path.join(media_dir, "poster.jpg")),
                ("fanart", os.path.join(media_dir, "fanart.jpg")),
                ("thumb", os.path.join(media_dir, "thumb.jpg")),
            ]
    elif item.item_type == "season":
        season_num = f"{item.season:02d}"
        show_dir = _show_folder_for_item(item, settings)
        if show_dir:
            for art_type, part in (
                ("banner", "banner"),
                ("poster", "poster"),
                ("fanart", "fanart"),
                ("landscape", "landscape"),
                ("thumb", "thumb"),
            ):
                name = f"season{season_num}-{part}.jpg"
                candidates.append((art_type, os.path.join(show_dir, name)))
    return candidates


def _parse_nfo(path: str) -> dict:
    if not xbmcvfs.exists(path):
        return {}

    try:
        handle = xbmcvfs.File(path)
        raw = handle.read()
        handle.close()
        if isinstance(raw, bytes):
            raw = raw.decode("utf-8", errors="replace")
        root = ET.fromstring(raw)
    except (ET.ParseError, OSError, ValueError) as exc:
        log(f"Failed to parse NFO {path}: {exc}", xbmc.LOGWARNING)
        return {}

    data: dict = {}

    def text(tag: str) -> str | None:
        node = root.find(f"./{tag}")
        if node is not None and node.text and node.text.strip():
            return node.text.strip()
        return None

    for tag in ("title", "plot", "mpaa", "studio", "premiered", "status"):
        value = text(tag)
        if value:
            data[tag] = value

    year = text("year")
    if year and year.isdigit():
        data["year"] = int(year)

    rating_node = root.find("./rating")
    if rating_node is not None:
        value_node = rating_node.find("./value") or rating_node.find("./rating")
        if value_node is not None and value_node.text:
            try:
                data["rating"] = float(value_node.text.strip())
            except ValueError:
                pass

    genres = [g.text.strip() for g in root.findall("./genre") if g.text and g.text.strip()]
    if genres:
        data["genre"] = genres

    uniqueids: dict[str, str] = {}
    for node in root.findall("./uniqueid"):
        type_attr = node.attrib.get("type", "unknown")
        if node.text and node.text.strip():
            uniqueids[type_attr] = node.text.strip()
    imdb = text("imdb")
    if imdb:
        uniqueids.setdefault("imdb", imdb)
    if uniqueids:
        data["uniqueid"] = uniqueids

    return data


def _build_details_payload(item: LibraryItem, nfo_data: dict, settings: UpdatarrSettings) -> dict:
    missing_fields = set(missing_metadata_fields(item, settings))
    payload: dict = {}

    if "plot" in missing_fields and nfo_data.get("plot"):
        payload["plot"] = nfo_data["plot"]
    if "title" in missing_fields and nfo_data.get("title"):
        payload["title"] = nfo_data["title"]
    if "rating" in missing_fields and nfo_data.get("rating") is not None:
        payload["rating"] = nfo_data["rating"]
    if nfo_data.get("year") is not None:
        payload["year"] = nfo_data["year"]
    if nfo_data.get("mpaa"):
        payload["mpaa"] = nfo_data["mpaa"]
    if nfo_data.get("genre"):
        payload["genre"] = nfo_data["genre"]
    if nfo_data.get("uniqueid"):
        payload["uniqueid"] = nfo_data["uniqueid"]

    return payload


def apply_local_artwork(item: LibraryItem, settings: UpdatarrSettings) -> bool:
    if not settings.enable_local_artwork or item.item_type == "episode":
        return False

    needed = set(missing_art_types(item, settings))
    if not needed:
        return False

    item_dict = item.item_dict()
    if not item_dict:
        return False

    applied = False
    for art_type, art_path in _artwork_candidates(item):
        if art_type not in needed:
            continue
        if not xbmcvfs.exists(art_path):
            continue

        result = jsonrpc(
            "VideoLibrary.SetArt",
            {"item": item_dict, "art": {art_type: _kodi_path(art_path)}},
            debug=settings.debug_log,
        )
        if not result.get("_error"):
            applied = True
            log(f"Set local {art_type} for {item.display_title}")

    return applied


def apply_local_nfo(item: LibraryItem, settings: UpdatarrSettings) -> bool:
    if not settings.enable_local_nfo:
        return False

    nfo_path = _nfo_path_for_item(item)
    if not nfo_path:
        return False

    nfo_data = _parse_nfo(nfo_path)
    if not nfo_data:
        return False

    details = _build_details_payload(item, nfo_data, settings)
    if not details:
        return False

    method_map = {
        "movie": "VideoLibrary.SetMovieDetails",
        "tvshow": "VideoLibrary.SetTVShowDetails",
        "episode": "VideoLibrary.SetEpisodeDetails",
    }
    method = method_map.get(item.item_type)
    if not method:
        return False

    id_key = list(item.item_dict().keys())[0]
    params = {id_key: item.item_id, **details}
    result = jsonrpc(method, params, debug=settings.debug_log)
    if result.get("_error"):
        return False
    log(f"Applied local NFO fields to {item.display_title}: {list(details.keys())}")
    return True


def apply_local_fixes(item: LibraryItem, settings: UpdatarrSettings) -> tuple[bool, bool]:
    art_applied = apply_local_artwork(item, settings)
    nfo_applied = apply_local_nfo(item, settings)
    return art_applied, nfo_applied
