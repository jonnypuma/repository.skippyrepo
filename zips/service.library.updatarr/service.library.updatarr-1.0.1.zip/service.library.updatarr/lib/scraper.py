"""Online scraper refresh via Kodi JSON-RPC."""

from __future__ import annotations

import xbmc

from lib.jsonrpc import jsonrpc, log
from lib.models import LibraryItem
from lib.settings import UpdatarrSettings


def refresh_item(item: LibraryItem, settings: UpdatarrSettings) -> bool:
    if not settings.enable_scraper_pass:
        return False

    item_dict = item.item_dict()
    if not item_dict:
        log(f"No refresh method for item type {item.item_type}", xbmc.LOGWARNING)
        return False

    if item.item_type == "movie":
        jsonrpc(
            "VideoLibrary.RefreshMovie",
            {
                "movieid": item.item_id,
                "ignorenfo": settings.ignore_nfo,
            },
            debug=settings.debug_log,
        )
    elif item.item_type == "tvshow":
        jsonrpc(
            "VideoLibrary.RefreshTVShow",
            {
                "tvshowid": item.item_id,
                "ignorenfo": settings.ignore_nfo,
                "refreshepisodes": settings.refresh_show_episodes,
            },
            debug=settings.debug_log,
        )
    elif item.item_type == "episode":
        jsonrpc(
            "VideoLibrary.RefreshEpisode",
            {
                "episodeid": item.item_id,
                "ignorenfo": settings.ignore_nfo,
            },
            debug=settings.debug_log,
        )
    elif item.item_type == "season" and item.tvshowid:
        jsonrpc(
            "VideoLibrary.RefreshTVShow",
            {
                "tvshowid": item.tvshowid,
                "ignorenfo": settings.ignore_nfo,
                "refreshepisodes": False,
            },
            debug=settings.debug_log,
        )
    else:
        return False

    log(f"Triggered scraper refresh for {item.display_title}")
    return True
