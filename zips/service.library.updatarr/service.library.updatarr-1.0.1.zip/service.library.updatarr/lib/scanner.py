"""Paginated VideoLibrary queries."""

from __future__ import annotations

import xbmcgui

from lib.jsonrpc import jsonrpc, log
from lib.models import LibraryItem
from lib.settings import UpdatarrSettings


class ScanCanceled(Exception):
    """Raised when the user cancels a library scan via DialogProgress."""


def _check_cancel(progress: xbmcgui.DialogProgress | None) -> None:
    if progress and progress.iscanceled():
        raise ScanCanceled()


def _update_scan_progress(
    progress: xbmcgui.DialogProgress | None,
    message: str,
    *,
    percent: int = 0,
) -> None:
    if progress:
        progress.update(percent, message)

MOVIE_PROPERTIES = ["art", "plot", "title", "file", "rating", "cast", "uniqueid", "imdbnumber"]
TVSHOW_PROPERTIES = ["art", "plot", "title", "file", "rating", "cast", "uniqueid"]
EPISODE_PROPERTIES = [
    "art",
    "plot",
    "title",
    "file",
    "season",
    "episode",
    "showtitle",
    "rating",
    "cast",
]


def _movie_from_payload(payload: dict) -> LibraryItem:
    return LibraryItem(
        item_type="movie",
        item_id=int(payload.get("movieid", 0)),
        title=str(payload.get("title") or ""),
        file_path=str(payload.get("file") or ""),
        plot=str(payload.get("plot") or ""),
        art=dict(payload.get("art") or {}),
        extra={
            "rating": payload.get("rating"),
            "cast": payload.get("cast"),
            "uniqueid": payload.get("uniqueid"),
            "imdbnumber": payload.get("imdbnumber"),
        },
    )


def _tvshow_from_payload(payload: dict) -> LibraryItem:
    return LibraryItem(
        item_type="tvshow",
        item_id=int(payload.get("tvshowid", 0)),
        title=str(payload.get("title") or ""),
        file_path=str(payload.get("file") or ""),
        plot=str(payload.get("plot") or ""),
        art=dict(payload.get("art") or {}),
        extra={
            "rating": payload.get("rating"),
            "cast": payload.get("cast"),
            "uniqueid": payload.get("uniqueid"),
        },
    )


def _episode_from_payload(payload: dict, tvshowid: int = 0) -> LibraryItem:
    return LibraryItem(
        item_type="episode",
        item_id=int(payload.get("episodeid", 0)),
        title=str(payload.get("title") or ""),
        file_path=str(payload.get("file") or ""),
        plot=str(payload.get("plot") or ""),
        art=dict(payload.get("art") or {}),
        season=int(payload.get("season") or 0),
        episode=int(payload.get("episode") or 0),
        showtitle=str(payload.get("showtitle") or ""),
        tvshowid=tvshowid or int(payload.get("tvshowid") or 0),
        extra={
            "rating": payload.get("rating"),
            "cast": payload.get("cast"),
        },
    )


def _paginated_get(
    method: str,
    result_key: str,
    properties: list[str],
    settings: UpdatarrSettings,
    extra_params: dict | None = None,
    *,
    progress: xbmcgui.DialogProgress | None = None,
    progress_label: str = "",
) -> list[dict]:
    items: list[dict] = []
    start = 0
    batch = settings.batch_size

    while True:
        _check_cancel(progress)

        params = {
            "properties": properties,
            "limits": {"start": start, "end": start + batch},
            "sort": {"order": "ascending", "method": "title", "ignorearticle": True},
        }
        if extra_params:
            params.update(extra_params)

        result = jsonrpc(method, params, debug=settings.debug_log)
        batch_items = result.get(result_key, [])
        if not batch_items:
            break

        items.extend(batch_items)
        if progress_label:
            _update_scan_progress(
                progress,
                f"{progress_label} ({len(items)})",
                percent=0,
            )

        if len(batch_items) < batch:
            break
        start += batch

    return items


def fetch_movies(
    settings: UpdatarrSettings,
    *,
    progress: xbmcgui.DialogProgress | None = None,
) -> list[LibraryItem]:
    _update_scan_progress(progress, "Scanning movies…")
    payloads = _paginated_get(
        "VideoLibrary.GetMovies",
        "movies",
        MOVIE_PROPERTIES,
        settings,
        progress=progress,
        progress_label="Scanning movies",
    )
    return [_movie_from_payload(p) for p in payloads if p.get("movieid")]


def fetch_tvshows(
    settings: UpdatarrSettings,
    *,
    progress: xbmcgui.DialogProgress | None = None,
) -> list[LibraryItem]:
    _update_scan_progress(progress, "Scanning TV shows…")
    payloads = _paginated_get(
        "VideoLibrary.GetTVShows",
        "tvshows",
        TVSHOW_PROPERTIES,
        settings,
        progress=progress,
        progress_label="Scanning TV shows",
    )
    return [_tvshow_from_payload(p) for p in payloads if p.get("tvshowid")]


def fetch_episodes_for_show(
    tvshowid: int,
    settings: UpdatarrSettings,
    *,
    progress: xbmcgui.DialogProgress | None = None,
) -> list[LibraryItem]:
    payloads = _paginated_get(
        "VideoLibrary.GetEpisodes",
        "episodes",
        EPISODE_PROPERTIES,
        settings,
        extra_params={"tvshowid": tvshowid},
        progress=progress,
    )
    return [_episode_from_payload(p, tvshowid) for p in payloads if p.get("episodeid")]


def fetch_all_episodes(
    settings: UpdatarrSettings,
    *,
    progress: xbmcgui.DialogProgress | None = None,
    shows: list[LibraryItem] | None = None,
) -> list[LibraryItem]:
    episodes: list[LibraryItem] = []
    show_list = shows if shows is not None else fetch_tvshows(settings, progress=progress)
    total = len(show_list)

    for index, show in enumerate(show_list):
        _check_cancel(progress)
        if total:
            percent = int((index / total) * 100)
            label = show.title or f"Show {show.item_id}"
            _update_scan_progress(
                progress,
                f"Scanning episodes ({index + 1}/{total}): {label}",
                percent=percent,
            )
        episodes.extend(fetch_episodes_for_show(show.item_id, settings, progress=progress))

    return episodes


def fetch_item_details(item: LibraryItem, settings: UpdatarrSettings) -> LibraryItem | None:
    method_map = {
        "movie": ("VideoLibrary.GetMovieDetails", "moviedetails", MOVIE_PROPERTIES),
        "tvshow": ("VideoLibrary.GetTVShowDetails", "tvshowdetails", TVSHOW_PROPERTIES),
        "episode": ("VideoLibrary.GetEpisodeDetails", "episodedetails", EPISODE_PROPERTIES),
    }
    mapping = method_map.get(item.item_type)
    if not mapping:
        return None

    method, result_key, properties = mapping
    id_key = item.item_dict()
    if not id_key:
        return None

    result = jsonrpc(
        method,
        {list(id_key.keys())[0]: list(id_key.values())[0], "properties": properties},
        debug=settings.debug_log,
    )
    payload = result.get(result_key)
    if not payload:
        return None

    if item.item_type == "movie":
        return _movie_from_payload(payload)
    if item.item_type == "tvshow":
        return _tvshow_from_payload(payload)
    if item.item_type == "episode":
        return _episode_from_payload(payload, item.tvshowid)
    return None


def fetch_season(tvshowid: int, season: int, settings: UpdatarrSettings) -> LibraryItem | None:
    result = jsonrpc(
        "VideoLibrary.GetSeasonDetails",
        {
            "tvshowid": tvshowid,
            "season": season,
            "properties": ["art", "title", "season", "tvshowid"],
        },
        debug=settings.debug_log,
    )
    payload = result.get("seasondetails")
    if not payload:
        return None

    return LibraryItem(
        item_type="season",
        item_id=int(payload.get("seasonid") or 0),
        title=str(payload.get("title") or f"Season {season}"),
        file_path="",
        art=dict(payload.get("art") or {}),
        season=int(payload.get("season") or season),
        tvshowid=int(payload.get("tvshowid") or tvshowid),
    )


def fetch_items_for_scope(
    settings: UpdatarrSettings,
    *,
    scope: str = "full",
    item_type: str | None = None,
    item_id: int | None = None,
    progress: xbmcgui.DialogProgress | None = None,
) -> list[LibraryItem]:
    items: list[LibraryItem] = []

    if scope == "context" and item_type and item_id:
        _check_cancel(progress)
        if item_type == "movie":
            details = fetch_item_details(LibraryItem("movie", item_id), settings)
            return [details] if details else []
        if item_type == "tvshow":
            details = fetch_item_details(LibraryItem("tvshow", item_id), settings)
            if not details:
                return []
            items = [details]
            if settings.context_refresh_episodes:
                items.extend(fetch_episodes_for_show(item_id, settings))
            return items
        if item_type == "episode":
            details = fetch_item_details(LibraryItem("episode", item_id), settings)
            return [details] if details else []
        if item_type == "season":
            result = jsonrpc(
                "VideoLibrary.GetSeasonDetails",
                {"seasonid": item_id, "properties": ["art", "title", "season", "tvshowid"]},
                debug=settings.debug_log,
            )
            season_payload = result.get("seasondetails")
            if not season_payload:
                return []
            show_id = int(season_payload.get("tvshowid") or 0)
            season_num = int(season_payload.get("season") or 0)
            items.append(
                LibraryItem(
                    item_type="season",
                    item_id=int(season_payload.get("seasonid") or item_id),
                    title=str(season_payload.get("title") or ""),
                    art=dict(season_payload.get("art") or {}),
                    season=season_num,
                    tvshowid=show_id,
                )
            )
            if show_id and season_num and settings.context_refresh_episodes:
                items.extend(
                    ep
                    for ep in fetch_episodes_for_show(show_id, settings)
                    if ep.season == season_num
                )
            return items

    if settings.process_movies:
        items.extend(fetch_movies(settings, progress=progress))
    if settings.process_tvshows:
        items.extend(fetch_tvshows(settings, progress=progress))
    if settings.process_episodes:
        shows = (
            [item for item in items if item.item_type == "tvshow"]
            if settings.process_tvshows
            else fetch_tvshows(settings, progress=progress)
        )
        items.extend(fetch_all_episodes(settings, progress=progress, shows=shows))

    log(f"Fetched {len(items)} library item(s) for scope={scope}")
    return items
