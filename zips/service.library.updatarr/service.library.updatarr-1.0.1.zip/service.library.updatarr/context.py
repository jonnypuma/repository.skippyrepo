# -*- coding: utf-8 -*-
"""Context menu entry for scoped library updates."""

from __future__ import annotations

import xbmc
import xbmcgui

from lib.addon_guard import ADDON_ID, is_addon_available
from lib.runner import run
from lib.settings import addon_name


def _get_context_item() -> tuple[str | None, int | None]:
    media_type = xbmc.getInfoLabel("ListItem.DBTYPE")
    dbid = xbmc.getInfoLabel("ListItem.DBID")
    if not media_type or not dbid:
        return None, None
    try:
        return media_type, int(dbid)
    except (TypeError, ValueError):
        return None, None


def main() -> None:
    if not is_addon_available():
        xbmc.log(f"[{ADDON_ID}] context ignored: add-on not installed", xbmc.LOGINFO)
        return

    item_type, item_id = _get_context_item()
    if not item_type or not item_id:
        xbmcgui.Dialog().notification(
            addon_name(),
            "Could not determine library item.",
            xbmcgui.NOTIFICATION_ERROR,
            4000,
        )
        return

    label = xbmc.getInfoLabel("ListItem.Label") or item_type
    if not xbmcgui.Dialog().yesno(
        addon_name(),
        f"Fix missing metadata/artwork for:\n{label}?",
    ):
        return

    progress = xbmcgui.DialogProgress()
    progress.create(addon_name(), f"Processing {label}…")

    try:
        result = run(
            scope="context",
            item_type=item_type,
            item_id=item_id,
            progress=progress,
        )
    finally:
        progress.close()

    if result.scan_canceled or result.canceled:
        return

    xbmcgui.Dialog().ok(addon_name(), result.summary_text())


if __name__ == "__main__":
    xbmc.log(f"[{ADDON_ID}] context menu triggered", xbmc.LOGINFO)
    try:
        if is_addon_available():
            main()
    except RuntimeError:
        xbmc.log(f"[{ADDON_ID}] context ignored: add-on unavailable", xbmc.LOGINFO)
    except Exception as exc:
        xbmc.log(f"[{ADDON_ID}] context error: {exc}", xbmc.LOGERROR)
        try:
            xbmcgui.Dialog().ok(addon_name(), f"Error:\n{exc}")
        except RuntimeError:
            pass
