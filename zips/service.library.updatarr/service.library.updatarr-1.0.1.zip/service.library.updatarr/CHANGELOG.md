# Changelog

All notable changes to Library Updatarr are documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.1] - 2026-06-14

### Fixed

- **Context menu** showed a blank row — `strings.po` had empty `msgstr` values so `$ADDON[32000]` resolved to no text; all English strings now populated.
- **Scan cancel** hung the progress dialog — library scan now checks cancel between JSON-RPC batches and exits cleanly without a follow-up modal.
- **Language packs** — added `en_us` and `English` string catalogs for Windows Kodi locales.

## [1.0.0] - 2026-06-14

### Added

- **Initial release** — populate missing metadata and artwork for items already in the Kodi video library (no new-file library scan).
- **Pipeline:** scan → detect missing fields → apply local artwork/NFO → re-check → scraper refresh (`RefreshMovie` / `RefreshTVShow` / `RefreshEpisode`).
- **Scope settings** for movies, TV shows, and episodes; configurable missing-field checks (poster, fanart, thumb, plot, title, rating, cast).
- **Local sources** — sidecar artwork via `SetArt`; NFO XML parse into `Set*Details` for missing fields only.
- **Online scrapers** — refresh pass using installed Kodi scrapers; optional ignore-NFO; TV show episode refresh options.
- **Dry Run** — scan-only preview with missing-field breakdown; optional **Run the update now?** follow-up without re-scanning.
- **Resumable jobs** — `update_job.json` checkpointing; Resume / Start Fresh / Cancel when a partial run exists.
- **Scheduled service** — background runs on interval, idle guard, defer during library scan or playback.
- **Context menu** — fix missing data for the selected movie, show, season, or episode.
- **Programs launcher** — Run Now and Dry Run from add-on settings.
- **Kodi v22 (Piers) settings schema** and `xbmc.Monitor` service API.
