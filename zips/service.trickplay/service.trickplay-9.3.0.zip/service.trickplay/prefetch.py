"""Background prefetch of trickplay thumb crops around the active preview."""

from __future__ import annotations

import os
import threading
import time
from collections import deque
from dataclasses import dataclass

import xbmc

from prefetch_settings import PrefetchSettings, read_prefetch_settings
from thumb_cropper import (
    ThumbCacheKey,
    crop_tile_cells_batch,
    decoded_tile_capacity,
    foreground_crop_pending,
    get_cached_thumb_path,
    get_cropped_thumb_path,
    get_ready_thumb_path,
    has_prepared_temp_copy,
    temp_tile_copy,
    thumb_cache_key,
    warm_decoded_tile,
)
from trickplay_resolver import (
    TrickplayLookup,
    TrickplayResolution,
    lookup_by_index,
    lookup_thumbnail,
)
from vfs_paths import is_remote_vfs_url, local_path as _vfs_local_path

MAX_TILE_ENQUEUE = 20
# Cap idle whole-tile floods so NFS sprite copies do not starve scrub crops.
IDLE_TILE_MAX_ENQUEUE = 24
# During scrub, keep cells ahead of the cursor (the direction of travel) and
# fewer behind it. Anything outside this window is dropped so a long drag does
# not replay every intermediate thumb after you stop.
SCRUB_AHEAD = 20
SCRUB_BEHIND = 10
# Same-sprite batch crops are faster idle, but a full-tile drain blocks the
# exact cell the overlay needs. Small batches let a newly queued cursor jump.
PREFETCH_CROP_BATCH_MAX = 4
# Copy+decode the next sprite once playhead prefetch is this far through the
# current tile, so the first cell of 1.jpg is already in RAM.
UPCOMING_TILE_WARM_FRACTION = 0.80
NEAREST_READY_MAX_DISTANCE = 12


def copy_order_for_tiles(
    tile_paths: tuple[str, ...] | list[str],
    prioritize: tuple[str, ...] | list[str] = (),
) -> list[str]:
    """Return sprite copy order: ``0.jpg`` first, then priority tiles, then the rest."""
    ordered: list[str] = []
    seen: set[str] = set()
    first = tile_paths[0] if tile_paths else ""
    for path in [first, *prioritize, *tile_paths]:
        if not path or path in seen:
            continue
        seen.add(path)
        ordered.append(path)
    return ordered


def _cache_key(lookup: TrickplayLookup) -> ThumbCacheKey:
    return thumb_cache_key(
        lookup.tile_path,
        lookup.col,
        lookup.row,
        lookup.thumb_width,
        lookup.thumb_height,
    )


def _log(message: str, level=xbmc.LOGINFO) -> None:
    xbmc.log(f"[service.trickplay] {message}", level)


def _max_thumb_index(resolution: TrickplayResolution) -> int:
    if resolution.thumbnail_count > 0:
        return resolution.thumbnail_count - 1
    return 0


def _tile_index_bounds(
    resolution: TrickplayResolution, thumb_index: int
) -> tuple[int, int]:
    thumbs_per_tile = resolution.thumbs_per_tile
    tile_start = (thumb_index // thumbs_per_tile) * thumbs_per_tile
    tile_end = tile_start + thumbs_per_tile
    if resolution.thumbnail_count > 0:
        tile_end = min(tile_end, resolution.thumbnail_count)
    return tile_start, tile_end


def _neighbor_indices(
    center_index: int,
    max_index: int,
    scrub_direction: int,
    settings: PrefetchSettings,
    interval_ms: int,
    *,
    seeking: bool = False,
) -> list[int]:
    """Return thumb indices in prefetch priority order."""
    ordered: list[int] = []
    seen: set[int] = set()

    def add(index: int) -> None:
        if index < 0 or index > max_index or index in seen:
            return
        seen.add(index)
        ordered.append(index)

    if seeking:
        radius_ahead = SCRUB_AHEAD
        radius_behind = SCRUB_BEHIND
        radius_symmetric = SCRUB_AHEAD
    else:
        radius_ahead = settings.radius_ahead(interval_ms)
        radius_behind = settings.radius_behind(interval_ms)
        radius_symmetric = settings.radius_symmetric(interval_ms)

    if scrub_direction > 0:
        for distance in range(1, radius_ahead + 1):
            add(center_index + distance)
        for distance in range(1, radius_behind + 1):
            add(center_index - distance)
    elif scrub_direction < 0:
        for distance in range(1, radius_ahead + 1):
            add(center_index - distance)
        for distance in range(1, radius_behind + 1):
            add(center_index + distance)
    else:
        for distance in range(1, radius_symmetric + 1):
            add(center_index + distance)
            add(center_index - distance)

    return ordered


def _scrub_index_in_window(index: int, center: int, scrub_direction: int) -> bool:
    """True when ``index`` is inside the scrub keep window around ``center``."""
    delta = index - center
    if scrub_direction < 0:
        return -SCRUB_AHEAD <= delta <= SCRUB_BEHIND
    return -SCRUB_BEHIND <= delta <= SCRUB_AHEAD


def _symmetric_window_indices(
    center_index: int,
    max_index: int,
    radius: int,
) -> list[int]:
    """Thumb indices within ±radius of center, center first."""
    ordered: list[int] = []
    seen: set[int] = set()

    def add(index: int) -> None:
        if index < 0 or index > max_index or index in seen:
            return
        seen.add(index)
        ordered.append(index)

    add(center_index)
    for distance in range(1, max(radius, 1) + 1):
        add(center_index + distance)
        add(center_index - distance)
    return ordered


def _follow_warm_indices(
    center_index: int,
    last_index: int,
    max_index: int,
    radius: int,
) -> list[int]:
    """Indices newly entering the ±radius window when the playhead moves."""
    if last_index < 0:
        return _symmetric_window_indices(center_index, max_index, radius)
    if center_index == last_index:
        return []

    indices = [center_index]
    old_lo = max(0, last_index - radius)
    old_hi = min(max_index, last_index + radius)
    new_lo = max(0, center_index - radius)
    new_hi = min(max_index, center_index + radius)
    for index in range(new_lo, new_hi + 1):
        if index < old_lo or index > old_hi:
            indices.append(index)
    return indices


def tile_progress_fraction(
    resolution: TrickplayResolution, thumb_index: int
) -> float:
    """How far through the current sprite tile (0.0–1.0) by cell index."""
    tile_start, tile_end = _tile_index_bounds(resolution, thumb_index)
    length = tile_end - tile_start
    if length <= 0:
        return 0.0
    return (thumb_index - tile_start) / length


def adjacent_tile_path(
    resolution: TrickplayResolution,
    thumb_index: int,
    direction: int,
) -> str | None:
    """Sprite path one tile ahead (direction>=0) or behind (direction<0)."""
    if not resolution.tile_paths:
        return None
    thumbs_per_tile = resolution.thumbs_per_tile
    if thumbs_per_tile <= 0:
        return None
    tile_index = thumb_index // thumbs_per_tile
    next_index = tile_index + 1 if direction >= 0 else tile_index - 1
    if 0 <= next_index < len(resolution.tile_paths):
        return resolution.tile_paths[next_index]
    return None


def should_warm_upcoming_tile(
    resolution: TrickplayResolution,
    thumb_index: int,
    direction: int = 1,
    fraction: float = UPCOMING_TILE_WARM_FRACTION,
) -> bool:
    """True when the playhead is in the last (or first, reverse) 20% of a tile."""
    progress = tile_progress_fraction(resolution, thumb_index)
    if direction < 0:
        return progress <= (1.0 - fraction)
    return progress >= fraction


def upcoming_tile_to_warm(
    resolution: TrickplayResolution,
    thumb_index: int,
    direction: int = 1,
    fraction: float = UPCOMING_TILE_WARM_FRACTION,
) -> str | None:
    if not should_warm_upcoming_tile(
        resolution, thumb_index, direction=direction, fraction=fraction
    ):
        return None
    warm_direction = -1 if direction < 0 else 1
    return adjacent_tile_path(resolution, thumb_index, warm_direction)


def nearest_ready_thumb_path(
    resolution: TrickplayResolution,
    lookup: TrickplayLookup,
    interval_ms: int,
    *,
    max_distance: int = NEAREST_READY_MAX_DISTANCE,
) -> str | None:
    """Return the closest already-cropped thumb path around ``lookup``."""
    if not resolution.is_usable:
        return None
    exact = get_ready_thumb_path(
        lookup.tile_path,
        lookup.col,
        lookup.row,
        lookup.thumb_width,
        lookup.thumb_height,
    )
    if exact:
        return exact

    max_index = _max_thumb_index(resolution)
    for distance in range(1, max(1, int(max_distance)) + 1):
        for index in (lookup.thumb_index + distance, lookup.thumb_index - distance):
            if index < 0 or index > max_index:
                continue
            neighbor = lookup_by_index(resolution, index, interval_ms)
            if neighbor is None:
                continue
            path = get_ready_thumb_path(
                neighbor.tile_path,
                neighbor.col,
                neighbor.row,
                neighbor.thumb_width,
                neighbor.thumb_height,
            )
            if path:
                return path
    return None


def _tile_cell_specs(
    resolution: TrickplayResolution,
    tile_path: str,
    interval_ms: int,
) -> list[tuple[int, int, int, int]]:
    """Return (col, row, thumb_w, thumb_h) for every cell in one sprite."""
    if not resolution.tile_paths:
        return []
    try:
        tile_index = resolution.tile_paths.index(tile_path)
    except ValueError:
        return []
    per_tile = resolution.thumbs_per_tile
    if per_tile <= 0:
        return []
    start = tile_index * per_tile
    end = start + per_tile
    if resolution.thumbnail_count > 0:
        end = min(end, resolution.thumbnail_count)
    cells: list[tuple[int, int, int, int]] = []
    for index in range(start, end):
        lookup = lookup_by_index(resolution, index, interval_ms)
        if lookup is None:
            continue
        cells.append(
            (lookup.col, lookup.row, lookup.thumb_width, lookup.thumb_height)
        )
    return cells


@dataclass(frozen=True)
class _PrefetchItem:
    lookup: TrickplayLookup
    high_priority: bool = False


class ThumbPrefetch:
    """Background crop queue; scrub/foreground work preempts idle tile floods."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._queue: deque[_PrefetchItem] = deque()
        self._queued_keys: set[tuple[str, int, int, int, int]] = set()
        self._worker: threading.Thread | None = None
        self._generation = 0
        self._debug = False
        self._prepared_tile: str | None = None
        self._idle_tiles_done: set[str] = set()
        self._max_queue = 48
        self._last_playback_follow_index = -1
        self._last_playback_follow_at = 0.0
        # Separate low-contention queue: copy sprite JPGs to local temp ASAP.
        self._copy_lock = threading.Lock()
        self._copy_queue: deque[str] = deque()
        self._copy_queued: set[str] = set()
        self._copy_done: set[str] = set()
        self._copy_worker: threading.Thread | None = None
        self._copy_generation = 0
        self._warmed_tiles: set[str] = set()
        self._decode_lock = threading.Lock()
        self._decode_queue: deque[str] = deque()
        self._decode_queued: set[str] = set()
        self._decode_worker: threading.Thread | None = None
        self._decode_generation = 0
        self._decoded_done: set[str] = set()
        self._precropped_done: set[str] = set()
        self._episode_resolution: TrickplayResolution | None = None
        self._episode_interval = 0
        self._episode_want_precrop = False
        self._episode_precrop = False
        self._episode_precrop_queued = False
        # (tile_path, col, row) cropped first when a sprite pre-crop starts.
        self._priority_cell: tuple[str, int, int] | None = None

    def cancel(self, *, clear_copies: bool = True) -> None:
        with self._lock:
            self._generation += 1
            self._queue.clear()
            self._queued_keys.clear()
            self._prepared_tile = None
            self._idle_tiles_done.clear()
            self._last_playback_follow_index = -1
            self._last_playback_follow_at = 0.0
            if clear_copies:
                self._warmed_tiles.clear()
                self._decoded_done.clear()
                self._precropped_done.clear()
        if clear_copies:
            with self._copy_lock:
                self._copy_generation += 1
                self._copy_queue.clear()
                self._copy_queued.clear()
                self._copy_done.clear()
            with self._decode_lock:
                self._decode_generation += 1
                self._decode_queue.clear()
                self._decode_queued.clear()
                self._episode_resolution = None
                self._episode_interval = 0
                self._episode_want_precrop = False
                self._episode_precrop = False
                self._episode_precrop_queued = False
                self._priority_cell = None

    def tile_is_locally_ready(self, tile_path: str) -> bool:
        """True when the sprite is already copied locally or is a local file."""
        if not tile_path:
            return False
        with self._copy_lock:
            if tile_path in self._copy_done:
                return True
        if has_prepared_temp_copy(tile_path):
            return True
        if is_remote_vfs_url(tile_path):
            return False
        local = _vfs_local_path(tile_path)
        try:
            return bool(local and os.path.isfile(local))
        except OSError:
            return False

    def yield_for_scrub(
        self,
        preferred_tile: str | None = None,
        *,
        keep_index: int | None = None,
        scrub_direction: int = 0,
    ) -> None:
        """Drop queued prefetch crops that would delay the current scrub cell.

        Keeps high-priority items for ``preferred_tile``. When ``keep_index``
        is set, only cells in the scrub window stay queued (+20 in the
        direction of travel, -10 behind). Cells outside that window are
        dropped so a long drag does not replay the path.
        """
        with self._lock:
            if not self._queue:
                dropped = 0
            else:
                kept: deque[_PrefetchItem] = deque()
                keys: set[tuple[str, int, int, int, int]] = set()
                for item in self._queue:
                    tile = item.lookup.tile_path
                    if keep_index is not None:
                        keep = _scrub_index_in_window(
                            item.lookup.thumb_index,
                            keep_index,
                            scrub_direction,
                        )
                    else:
                        keep = (
                            bool(preferred_tile)
                            and item.high_priority
                            and tile == preferred_tile
                        )
                    if keep:
                        kept.append(item)
                        keys.add(_cache_key(item.lookup))
                dropped = len(self._queue) - len(kept)
                self._queue = kept
                self._queued_keys = keys
            if dropped and self._debug:
                _log(
                    f"Prefetch yield for scrub"
                    f"{f' tile={preferred_tile}' if preferred_tile else ''}"
                    f" dropped {dropped} cell(s)"
                )
        if preferred_tile:
            self.prioritize_tile_copy(preferred_tile)
            if not self._tile_decode_is_done(preferred_tile):
                self._enqueue_tile_decode(preferred_tile, high_priority=True)

    def schedule_all_tile_copies(
        self,
        tile_paths: tuple[str, ...] | list[str],
        *,
        prioritize: tuple[str, ...] | list[str] = (),
        debug: bool = False,
    ) -> None:
        """Copy every sprite JPG to local temp in the background (0.jpg first)."""
        self._debug = debug
        ordered = copy_order_for_tiles(tile_paths, prioritize)
        if not ordered:
            return

        with self._copy_lock:
            new_queue: deque[str] = deque()
            queued: set[str] = set()
            for path in ordered:
                if path in self._copy_done:
                    continue
                new_queue.append(path)
                queued.add(path)
            self._copy_queue = new_queue
            self._copy_queued = queued

        pending = len(new_queue)
        if pending and debug:
            _log(
                f"Scheduled local copies for {pending} sprite tile(s) "
                f"(priority {len([p for p in prioritize if p])})"
            )
        if pending:
            self._ensure_copy_worker()

    def schedule_episode_preload(
        self,
        resolution: TrickplayResolution,
        interval_ms: int,
        *,
        prioritize: tuple[str, ...] | list[str] = (),
        settings: PrefetchSettings | None = None,
        debug: bool = False,
    ) -> None:
        """Copy every sprite locally and decode into RAM. Cell pre-crop waits
        until ``enable_episode_precrop`` so the first thumb can publish first.
        """
        settings = settings or read_prefetch_settings()
        if not settings.enabled or not resolution.is_usable:
            return
        self._debug = debug
        with self._decode_lock:
            self._episode_resolution = resolution
            self._episode_interval = interval_ms
            self._episode_want_precrop = settings.preload_tiles
            self._episode_precrop = False
        self.schedule_all_tile_copies(
            resolution.tile_paths,
            prioritize=prioritize,
            debug=debug,
        )
        first = resolution.tile_paths[0] if resolution.tile_paths else ""
        if first:
            self._enqueue_tile_decode(first, high_priority=True)

    def start_playback_tile_cache(
        self,
        resolution: TrickplayResolution,
        lookup: TrickplayLookup,
        interval_ms: int,
        settings: PrefetchSettings | None = None,
    ) -> None:
        """Pre-crop the playhead sprite as soon as playback starts.

        Does not wait for the seek bar. The current cell is encoded first,
        then the rest of that sprite. Other sprites still follow
        ``enable_episode_precrop`` when preload is on.
        """
        settings = settings or read_prefetch_settings()
        if not settings.enabled or not resolution.is_usable or lookup is None:
            return
        with self._decode_lock:
            self._episode_resolution = resolution
            self._episode_interval = interval_ms
            self._episode_precrop = True
            self._priority_cell = (lookup.tile_path, lookup.col, lookup.row)
        self.prioritize_tile_copy(lookup.tile_path)
        self._enqueue_tile_decode(lookup.tile_path, high_priority=True)

    def note_tile_ready(self, tile_path: str) -> None:
        """Mark a sprite already copied and decoded (e.g. first playhead crop)."""
        if not tile_path:
            return
        with self._copy_lock:
            self._copy_done.add(tile_path)
        with self._lock:
            self._warmed_tiles.add(tile_path)
            self._decoded_done.add(tile_path)

    def tile_copy_is_done(self, tile_path: str) -> bool:
        if not tile_path:
            return False
        with self._copy_lock:
            return tile_path in self._copy_done

    def enable_episode_precrop(self) -> None:
        """Start background cell encodes for every sprite."""
        with self._decode_lock:
            if not self._episode_want_precrop:
                return
            self._episode_precrop = True
            if self._episode_precrop_queued:
                return
            resolution = self._episode_resolution
        if resolution is None or not resolution.tile_paths:
            return
        with self._decode_lock:
            self._episode_precrop_queued = True
        first = resolution.tile_paths[0]
        self._enqueue_tile_decode(first, high_priority=True)
        for tile_path in resolution.tile_paths[1:]:
            self._enqueue_tile_decode(tile_path)

    def _tile_decode_is_done(self, tile_path: str) -> bool:
        with self._lock:
            decoded = tile_path in self._decoded_done
            precropped = tile_path in self._precropped_done
        with self._decode_lock:
            want_precrop = self._episode_precrop
        if not decoded:
            return False
        if want_precrop and not precropped:
            return False
        return True

    def _enqueue_tile_decode(
        self, tile_path: str, *, high_priority: bool = False
    ) -> None:
        if not tile_path:
            return
        if self._tile_decode_is_done(tile_path):
            return
        with self._decode_lock:
            if tile_path in self._decode_queued:
                if high_priority:
                    try:
                        self._decode_queue.remove(tile_path)
                    except ValueError:
                        pass
                    self._decode_queue.appendleft(tile_path)
            else:
                self._decode_queued.add(tile_path)
                if high_priority:
                    self._decode_queue.appendleft(tile_path)
                else:
                    self._decode_queue.append(tile_path)
        self._ensure_decode_worker()

    def _ensure_decode_worker(self) -> None:
        with self._decode_lock:
            if self._decode_worker is not None and self._decode_worker.is_alive():
                return
            generation = self._decode_generation
            self._decode_worker = threading.Thread(
                target=self._run_tile_decodes,
                args=(generation,),
                daemon=True,
                name="trickplay-tile-decode",
            )
            self._decode_worker.start()

    def _run_tile_decodes(self, generation: int) -> None:
        while True:
            with self._decode_lock:
                if generation != self._decode_generation:
                    return
            if foreground_crop_pending():
                # Keep episode-wide JPEG work out of the visible exact-thumb
                # request's critical path.
                time.sleep(0.025)
                continue
            with self._decode_lock:
                if not self._decode_queue:
                    self._decode_worker = None
                    return
                tile_path = self._decode_queue.popleft()
                self._decode_queued.discard(tile_path)
                resolution = self._episode_resolution
                interval_ms = self._episode_interval
                precrop = self._episode_precrop
            self._decode_one_tile(
                tile_path,
                resolution=resolution,
                interval_ms=interval_ms,
                precrop=precrop,
            )

    def _decode_one_tile(
        self,
        tile_path: str,
        *,
        resolution: TrickplayResolution | None,
        interval_ms: int,
        precrop: bool,
    ) -> None:
        if not self.tile_is_locally_ready(tile_path):
            if self._debug:
                _log(
                    f"Defer sprite decode until local copy "
                    f"{os.path.basename(tile_path)}"
                )
            return
        with self._lock:
            already_decoded = tile_path in self._decoded_done
            already_precropped = tile_path in self._precropped_done
            self._warmed_tiles.add(tile_path)
        if not already_decoded and decoded_tile_capacity() > 0:
            try:
                ok = warm_decoded_tile(tile_path)
                if self._debug:
                    _log(
                        f"Decoded sprite warm {os.path.basename(tile_path)} ok={ok}"
                    )
                if ok:
                    with self._lock:
                        self._decoded_done.add(tile_path)
            except (OSError, RuntimeError, ValueError) as exc:
                _log(
                    f"Sprite decode failed for {tile_path}: {exc}",
                    xbmc.LOGWARNING,
                )
        elif not already_decoded:
            with self._lock:
                self._decoded_done.add(tile_path)
        if not precrop or resolution is None:
            return
        if already_precropped:
            return
        cells = _tile_cell_specs(resolution, tile_path, interval_ms)
        if not cells:
            with self._lock:
                self._precropped_done.add(tile_path)
            return
        pending = [
            cell
            for cell in cells
            if not get_cached_thumb_path(tile_path, cell[0], cell[1], cell[2], cell[3])
        ]
        with self._decode_lock:
            priority = self._priority_cell
        if priority is not None and priority[0] == tile_path:
            _tile, col, row = priority
            pending.sort(key=lambda cell: 0 if cell[0] == col and cell[1] == row else 1)
        if not pending:
            with self._lock:
                self._precropped_done.add(tile_path)
            return
        if self._debug:
            _log(
                f"Episode pre-crop {len(pending)} uncached cell(s) from "
                f"{os.path.basename(tile_path)}"
            )
        yielded = False

        def _yield_to_foreground() -> bool:
            nonlocal yielded
            yielded = foreground_crop_pending()
            return yielded

        try:
            crop_tile_cells_batch(
                tile_path,
                pending,
                debug=False,
                chunk_size=8,
                should_yield=_yield_to_foreground,
            )
        except (OSError, RuntimeError, ValueError) as exc:
            _log(
                f"Episode pre-crop failed for {tile_path}: {exc}",
                xbmc.LOGWARNING,
            )
            return
        if yielded:
            # Resume this tile after the foreground request settles.
            self._enqueue_tile_decode(tile_path)
            return
        with self._lock:
            self._precropped_done.add(tile_path)

    def prioritize_tile_copy(self, tile_path: str) -> None:
        """Move a sprite tile to the front of the local-copy queue."""
        if not tile_path:
            return
        with self._copy_lock:
            if tile_path in self._copy_done:
                return
            if tile_path in self._copy_queued:
                try:
                    self._copy_queue.remove(tile_path)
                except ValueError:
                    pass
            else:
                self._copy_queued.add(tile_path)
            self._copy_queue.appendleft(tile_path)
        self._ensure_copy_worker()

    def _ensure_copy_worker(self) -> None:
        with self._copy_lock:
            if self._copy_worker is not None and self._copy_worker.is_alive():
                return
            generation = self._copy_generation
            self._copy_worker = threading.Thread(
                target=self._run_tile_copies,
                args=(generation,),
                daemon=True,
                name="trickplay-tile-copy",
            )
            self._copy_worker.start()

    def _run_tile_copies(self, generation: int) -> None:
        while True:
            with self._copy_lock:
                if generation != self._copy_generation:
                    return
                if not self._copy_queue:
                    self._copy_worker = None
                    return
                tile_path = self._copy_queue.popleft()
                self._copy_queued.discard(tile_path)

            if self._debug:
                _log(f"Prefetch local tile copy {os.path.basename(tile_path)}")
            local = temp_tile_copy(tile_path)
            with self._copy_lock:
                if generation != self._copy_generation:
                    return
                if local:
                    self._copy_done.add(tile_path)
            if local:
                self._enqueue_tile_decode(tile_path)

    def schedule_playhead_follow(
        self,
        resolution: TrickplayResolution,
        play_seconds: int,
        interval_ms: int,
        settings: PrefetchSettings | None = None,
        debug: bool = False,
        *,
        high_priority: bool = False,
        force: bool = False,
    ) -> None:
        """Keep ±playback_warm_indices crops warm around the playhead during playback."""
        settings = settings or read_prefetch_settings()
        if not settings.enabled or not settings.during_playback or not resolution.is_usable:
            return
        lookup = lookup_thumbnail(resolution, play_seconds, interval_ms)
        if lookup is None:
            return

        center_index = lookup.thumb_index
        previous_index = self._last_playback_follow_index
        now = time.monotonic()
        retry_same_index = (
            not force
            and center_index == previous_index
            and now - self._last_playback_follow_at >= 5.0
        )
        if (
            not force
            and center_index == previous_index
            and not retry_same_index
        ):
            return

        warm_previous = -1 if force or previous_index < 0 or retry_same_index else previous_index
        self._last_playback_follow_index = center_index
        self._last_playback_follow_at = now
        # Cap during-playback follow so a large scrub window does not flood the queue.
        self._warm_around_lookup(
            resolution,
            lookup,
            interval_ms,
            settings,
            debug=debug,
            high_priority=high_priority,
            whole_tile=False,
            previous_index=warm_previous,
            radius=settings.playback_warm_indices(interval_ms),
        )
        direction = 1
        if previous_index >= 0 and center_index < previous_index:
            direction = -1
        self.maybe_warm_upcoming_tile(
            resolution, lookup, direction=direction, debug=debug
        )

    def _warm_around_lookup(
        self,
        resolution: TrickplayResolution,
        center: TrickplayLookup,
        interval_ms: int,
        settings: PrefetchSettings,
        *,
        debug: bool,
        high_priority: bool,
        whole_tile: bool,
        previous_index: int,
        radius: int | None = None,
    ) -> None:
        self._debug = debug
        self._max_queue = settings.max_queue
        max_index = _max_thumb_index(resolution)
        if radius is None:
            radius = settings.radius_indices(interval_ms)

        if previous_index < 0:
            indices = _symmetric_window_indices(
                center.thumb_index, max_index, radius
            )
        else:
            indices = _follow_warm_indices(
                center.thumb_index,
                previous_index,
                max_index,
                radius,
            )

        if debug and indices:
            _log(
                f"Prefetch playhead follow index {center.thumb_index} "
                f"±{radius} ({len(indices)} cell(s))"
            )

        self._schedule_indices(
            resolution,
            interval_ms,
            indices,
            high_priority=high_priority,
        )
        if whole_tile:
            self._schedule_tile_cells(
                resolution,
                center,
                interval_ms,
                skip_indices=set(indices),
                max_enqueue=MAX_TILE_ENQUEUE,
            )

    def schedule_playhead_warm(
        self,
        resolution: TrickplayResolution,
        center: TrickplayLookup,
        interval_ms: int,
        settings: PrefetchSettings | None = None,
        debug: bool = False,
    ) -> None:
        """Warm cache around the current playhead when trickplay loads."""
        settings = settings or read_prefetch_settings()
        if not settings.enabled or not settings.on_start or not resolution.is_usable:
            return

        self._last_playback_follow_index = center.thumb_index
        self._last_playback_follow_at = time.monotonic()
        self._warm_around_lookup(
            resolution,
            center,
            interval_ms,
            settings,
            debug=debug,
            high_priority=True,
            whole_tile=settings.whole_tile,
            previous_index=-1,
        )
        self.maybe_warm_upcoming_tile(
            resolution, center, direction=1, debug=debug
        )

    def maybe_warm_upcoming_tile(
        self,
        resolution: TrickplayResolution,
        lookup: TrickplayLookup,
        *,
        direction: int = 1,
        debug: bool = False,
    ) -> str | None:
        """Copy and decode the next sprite when the playhead is in the last 20%."""
        tile_path = upcoming_tile_to_warm(
            resolution, lookup.thumb_index, direction=direction
        )
        if not tile_path:
            return None
        return self.schedule_tile_warm(tile_path, debug=debug)

    def schedule_tile_warm(self, tile_path: str, debug: bool = False) -> str | None:
        """Copy a sprite locally and decode it into RAM once per playback."""
        if not tile_path:
            return None
        with self._lock:
            if tile_path in self._warmed_tiles:
                return None
            self._warmed_tiles.add(tile_path)
        self._debug = debug or self._debug
        if self._debug:
            _log(f"Warm upcoming sprite {os.path.basename(tile_path)}")
        self.prioritize_tile_copy(tile_path)
        self._enqueue_tile_decode(tile_path, high_priority=True)
        return tile_path

    def schedule_neighbors(
        self,
        resolution: TrickplayResolution,
        center: TrickplayLookup,
        interval_ms: int,
        scrub_direction: int = 0,
        settings: PrefetchSettings | None = None,
        debug: bool = False,
        *,
        seeking: bool = False,
    ) -> None:
        settings = settings or read_prefetch_settings()
        if not settings.enabled or not resolution.is_usable:
            return

        self._debug = debug
        if seeking:
            self._max_queue = max(
                settings.max_queue, SCRUB_AHEAD + SCRUB_BEHIND + 1
            )
        else:
            self._max_queue = settings.max_queue
        indices = _neighbor_indices(
            center.thumb_index,
            _max_thumb_index(resolution),
            scrub_direction,
            settings,
            interval_ms,
            seeking=seeking,
        )
        self._schedule_indices(
            resolution,
            interval_ms,
            indices,
            high_priority=True,
        )
        if seeking:
            # Whole-tile / next-sprite work waits until the cursor settles so
            # a long drag does not enqueue every cell along the path.
            return
        self.maybe_warm_upcoming_tile(
            resolution, center, direction=scrub_direction, debug=debug
        )
        if settings.whole_tile:
            self._schedule_tile_cells(
                resolution,
                center,
                interval_ms,
                skip_indices={center.thumb_index, *indices},
                max_enqueue=MAX_TILE_ENQUEUE,
            )

    def schedule_idle_tile(
        self,
        resolution: TrickplayResolution,
        center: TrickplayLookup,
        interval_ms: int,
        settings: PrefetchSettings | None = None,
        debug: bool = False,
    ) -> None:
        """Prefetch remaining cells in the current sprite tile while OSD is idle."""
        settings = settings or read_prefetch_settings()
        if not settings.enabled or not settings.idle_tile or not resolution.is_usable:
            return

        tile_path = center.tile_path
        if tile_path in self._idle_tiles_done:
            return

        self._debug = debug
        self._max_queue = settings.max_queue
        if debug:
            _log(f"Prefetch idle tile {tile_path}")

        enqueued = self._schedule_tile_cells(
            resolution,
            center,
            interval_ms,
            skip_indices=set(),
            max_enqueue=IDLE_TILE_MAX_ENQUEUE,
        )
        if enqueued > 0:
            self._idle_tiles_done.add(tile_path)

    def _schedule_indices(
        self,
        resolution: TrickplayResolution,
        interval_ms: int,
        indices: list[int],
        high_priority: bool,
    ) -> None:
        # High-priority uses appendleft; enqueue in reverse so the first
        # index stays at the front of the queue.
        ordered = reversed(indices) if high_priority else indices
        for index in ordered:
            lookup = lookup_by_index(resolution, index, interval_ms)
            if lookup is None:
                continue
            self._enqueue(lookup, high_priority=high_priority)

    def _schedule_tile_cells(
        self,
        resolution: TrickplayResolution,
        center: TrickplayLookup,
        interval_ms: int,
        skip_indices: set[int],
        max_enqueue: int,
    ) -> int:
        tile_start, tile_end = _tile_index_bounds(resolution, center.thumb_index)
        enqueued = 0
        for index in range(tile_start, tile_end):
            if index in skip_indices:
                continue
            lookup = lookup_by_index(resolution, index, interval_ms)
            if lookup is None:
                continue
            if self._enqueue(lookup, high_priority=False):
                enqueued += 1
            if enqueued >= max_enqueue:
                break
        return enqueued

    def _enqueue(
        self, lookup: TrickplayLookup, *, high_priority: bool
    ) -> bool:
        if get_cached_thumb_path(
            lookup.tile_path,
            lookup.col,
            lookup.row,
            lookup.thumb_width,
            lookup.thumb_height,
        ):
            return False

        key = _cache_key(lookup)
        with self._lock:
            if key in self._queued_keys:
                if not high_priority:
                    return False
                # Promote an already-queued low-priority cell to the front.
                for existing in self._queue:
                    if _cache_key(existing.lookup) == key:
                        self._queue.remove(existing)
                        self._queue.appendleft(
                            _PrefetchItem(lookup, high_priority=True)
                        )
                        return True
                return False
            if len(self._queue) >= self._max_queue:
                if not high_priority:
                    return False
                dropped = self._queue.pop()
                self._queued_keys.discard(_cache_key(dropped.lookup))
            item = _PrefetchItem(lookup, high_priority=high_priority)
            if high_priority:
                self._queue.appendleft(item)
            else:
                self._queue.append(item)
            self._queued_keys.add(key)

        self._ensure_worker()
        return True

    def _ensure_worker(self) -> None:
        with self._lock:
            if self._worker is not None and self._worker.is_alive():
                return
            generation = self._generation
            self._worker = threading.Thread(
                target=self._run,
                args=(generation,),
                daemon=True,
                name="trickplay-prefetch",
            )
            self._worker.start()

    def _pop_crop_batch_locked(self) -> list[TrickplayLookup] | None:
        """Take a small same-sprite batch. Caller must hold ``_lock``."""
        if not self._queue:
            return None
        item = self._queue.popleft()
        self._queued_keys.discard(_cache_key(item.lookup))
        batch = [item.lookup]
        tile_path = item.lookup.tile_path
        remaining: deque[_PrefetchItem] = deque()
        while self._queue:
            nxt = self._queue.popleft()
            key = _cache_key(nxt.lookup)
            self._queued_keys.discard(key)
            if (
                nxt.lookup.tile_path == tile_path
                and len(batch) < PREFETCH_CROP_BATCH_MAX
            ):
                batch.append(nxt.lookup)
            else:
                remaining.append(nxt)
                self._queued_keys.add(key)
        if remaining:
            self._queue.extendleft(reversed(remaining))
        return batch

    def _pop_crop_batch(self) -> list[TrickplayLookup] | None:
        """Take a small same-sprite batch, leaving leftover cells queued."""
        with self._lock:
            return self._pop_crop_batch_locked()

    def _run(self, generation: int) -> None:
        prepared_tile: str | None = None
        while True:
            with self._lock:
                if generation != self._generation:
                    return
            if foreground_crop_pending():
                time.sleep(0.025)
                continue
            with self._lock:
                if generation != self._generation:
                    return
                if not self._queue:
                    self._worker = None
                    self._prepared_tile = None
                    return
                batch = self._pop_crop_batch_locked()
            if not batch:
                continue
            tile_path = batch[0].tile_path

            cells: list[tuple[int, int, int, int]] = []
            seen_cells: set[tuple[int, int, int, int]] = set()
            for lookup in batch:
                if get_cached_thumb_path(
                    lookup.tile_path,
                    lookup.col,
                    lookup.row,
                    lookup.thumb_width,
                    lookup.thumb_height,
                ):
                    continue
                cell = (
                    lookup.col,
                    lookup.row,
                    lookup.thumb_width,
                    lookup.thumb_height,
                )
                if cell in seen_cells:
                    continue
                seen_cells.add(cell)
                cells.append(cell)

            if not cells:
                continue

            if tile_path != prepared_tile:
                temp_tile_copy(tile_path)
                prepared_tile = tile_path
                with self._lock:
                    if generation == self._generation:
                        self._prepared_tile = prepared_tile

            if self._debug:
                _log(
                    f"Prefetch batch crop {len(cells)} cell(s) from "
                    f"{os.path.basename(tile_path)}"
                )

            if len(cells) == 1:
                col, row, thumb_w, thumb_h = cells[0]
                get_cropped_thumb_path(
                    tile_path,
                    col,
                    row,
                    thumb_w,
                    thumb_h,
                    debug=self._debug,
                )
            else:
                crop_tile_cells_batch(tile_path, cells, debug=self._debug)
