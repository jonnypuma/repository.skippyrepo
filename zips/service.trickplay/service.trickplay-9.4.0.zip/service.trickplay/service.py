"""Kodi background service that exposes Jellyfin trickplay previews while seeking."""

from __future__ import annotations

import sys
import threading
import time

import xbmc
import xbmcgui
import xbmcaddon

ADDON = xbmcaddon.Addon("service.trickplay")
_ADDON_PATH = ADDON.getAddonInfo("path")
if _ADDON_PATH and _ADDON_PATH not in sys.path:
    sys.path.insert(0, _ADDON_PATH)

from prefetch import ThumbPrefetch
from prefetch_settings import read_prefetch_settings
from generator_settings import read_runtime_settings, read_generator_settings
from generator_worker import GeneratorWorker
from library_update_batch import LibraryUpdateBatch
from thumb_cropper import (
    begin_decoded_tile_session,
    end_decoded_tile_session,
)
from preview_dialog import (
    PREVIEW_PROPERTIES,
    PROP_PREVIEW_VISIBLE,
    PreviewDialogController,
    clear_trickplay_property,
    resync_preview_to_seekbar,
    sync_display_settings,
    sync_trickplay_property,
)
from trickplay_resolver import (
    enrich_resolution,
    load_trickplay_for_file,
    lookup_thumbnail,
    TrickplayResolution,
)

from skin_profiles import (
    DEFAULT_PROFILE,
    active_profile,
    current_skin_id,
    is_known_skin,
    profile_summary,
    setting_skin_profile_override,
)
from preview_hold import PreviewHoldMixin
from skippy_suppress import PROP_SUPPRESS_AFTER_SKIP, SkippySuppressMixin

HOME_WINDOW = xbmcgui.Window(10000)

SEEKBAR_WINDOW_ID = 10115

POLL_MS_IDLE = 1000
POLL_MS_IDLE_GENERATOR = 500
POLL_MS_MIN = 25
POLL_MS_MAX = 250
PLAYBACK_SCRUB_GUARD_SEC = 3.0
EPISODE_PRECROP_IDLE_SEC = 1.5
LAST_TILE_REFINE_IDLE_SEC = 2.0

PROP_TILE = "Trickplay.TileImage"
PROP_COL = "Trickplay.TileCol"
PROP_ROW = "Trickplay.TileRow"
PROP_THUMB_W = "Trickplay.ThumbWidth"
PROP_THUMB_H = "Trickplay.ThumbHeight"
PROP_SEEKING = "Trickplay.IsSeeking"
PROP_AVAILABLE = "Trickplay.Available"


def _log(message: str, level=xbmc.LOGINFO) -> None:
    xbmc.log(f"[service.trickplay] {message}", level)


def _debug(message: str) -> None:
    if read_runtime_settings().debug_logging:
        _log(message, xbmc.LOGINFO)


def _clamp_poll_ms(value: int, default: int = 100) -> int:
    try:
        parsed = int(value)
    except (TypeError, ValueError):
        parsed = default
    return max(POLL_MS_MIN, min(parsed, POLL_MS_MAX))


def _setting_int(setting_id: str, default: int) -> int:
    # Fresh Addon() — module-level instance can return stale values in a long-lived service.
    addon = xbmcaddon.Addon("service.trickplay")
    try:
        return int(addon.getSettingInt(setting_id))
    except (TypeError, ValueError):
        raw = addon.getSettingString(setting_id)
        try:
            return int(raw)
        except (TypeError, ValueError):
            return default


def _parse_time_label(label: str) -> int:
    """Convert Kodi time labels (HH:MM:SS or MM:SS) to seconds."""
    if not label:
        return 0

    parts = label.strip().split(":")
    try:
        values = [int(part) for part in parts]
    except ValueError:
        return 0

    if len(values) == 3:
        hours, minutes, seconds = values
        return hours * 3600 + minutes * 60 + seconds
    if len(values) == 2:
        minutes, seconds = values
        return minutes * 60 + seconds
    if len(values) == 1:
        return values[0]
    return 0


def _player_time_seconds(player: xbmc.Player) -> int:
    try:
        return max(int(player.getTime()), 0)
    except RuntimeError:
        return _parse_time_label(xbmc.getInfoLabel("Player.Time"))


def _player_duration_seconds(player: xbmc.Player) -> int:
    duration = _parse_time_label(xbmc.getInfoLabel("Player.Duration"))
    if duration > 0:
        return duration
    try:
        return max(int(player.getTotalTime()), 0)
    except RuntimeError:
        return 0


class TrickplayMonitor(xbmc.Monitor):
    def __init__(
        self,
        library_batch: LibraryUpdateBatch,
        on_settings_changed=None,
    ) -> None:
        super().__init__()
        self._library_batch = library_batch
        self._on_settings_changed = on_settings_changed

    def onNotification(self, sender: str, method: str, data: str) -> None:
        try:
            self._library_batch.on_notification(sender, method, data)
        except Exception as exc:
            _log(f"Library notification error: {exc}", xbmc.LOGERROR)

    def onSettingsChanged(self) -> None:
        try:
            from settings_cache import invalidate_settings_cache

            invalidate_settings_cache()
            if self._on_settings_changed is not None:
                self._on_settings_changed()
        except Exception as exc:
            _log(f"Settings change error: {exc}", xbmc.LOGERROR)


class TrickplayService(SkippySuppressMixin, PreviewHoldMixin):
    def __init__(self) -> None:
        self.player = KodiPlayer(service=self)
        self.generator = GeneratorWorker()
        self.library_batch = LibraryUpdateBatch(self.generator)
        self.preview = PreviewDialogController(ADDON.getAddonInfo("path"))
        self.monitor = TrickplayMonitor(
            self.library_batch,
            on_settings_changed=self._on_addon_settings_changed,
        )
        self.prefetch = ThumbPrefetch()
        self.resolution: TrickplayResolution | None = None
        self.playing_file = ""
        self.last_preview_second = -1
        self._last_preview_thumb_index = -1
        self.was_seeking = False
        self.preview_active = False
        self.preview_visible = False
        self.committed_seek_second = -1
        self.committed_seek_at = 0.0
        self.last_play_time = -1
        self.playback_started_at = 0.0
        self.cached_duration = 0
        self.poll_ms = _clamp_poll_ms(_setting_int("poll_ms", 100))
        self._next_poll_ms = self.poll_ms
        self._last_poll_scrubbing = False
        self._last_poll_seek_ui = False
        self._active_skin_id = ""
        self._active_skin_override = ""
        self.seek_hold_until = 0.0
        self._had_compact_seekbar = False
        self._had_dialog_seekbar = False
        self._had_seek_ui = False
        self._pending_seek_ui_warm = False
        self._last_idle_prefetch_at = 0.0
        self._last_seek_activity_at = 0.0
        self._last_tile_refine_started_for = ""
        self._load_target = ""
        self._load_settled_for = ""
        self._load_thread: threading.Thread | None = None
        self._playback_block_reason = ""
        self._preview_tools_install_prompt_pending = False
        self._preview_tools_install_prompt_done = False
        self._skin_snippet_prompt_done = False
        self._skippy_skipping_latched = False
        self._skip_landing_second = -1
        self._skip_hiding_since = 0.0
        self._log_skin_profile(force=True)

    def _on_addon_settings_changed(self) -> None:
        self.preview.on_settings_changed()
        self.poll_ms = _clamp_poll_ms(_setting_int("poll_ms", 100))

    def _log_skin_profile(self, force: bool = False) -> None:
        skin_id = current_skin_id()
        override = setting_skin_profile_override()
        if (
            not force
            and skin_id == self._active_skin_id
            and override == self._active_skin_override
        ):
            return
        self._active_skin_id = skin_id
        self._active_skin_override = override
        profile = active_profile(force_refresh=True)
        _log(f"Skin profile: {profile_summary(profile, skin_id, override)}")
        if override == "auto" and skin_id and not is_known_skin(skin_id):
            _log(
                f"Unknown skin '{skin_id}'; using {DEFAULT_PROFILE.label} geometry. "
                "Merge the matching skin snippet or set Skin profile in addon settings.",
                xbmc.LOGWARNING,
            )

    def _interval_ms(self) -> int:
        if self.resolution is not None:
            return self.resolution.interval_ms
        return read_runtime_settings().interval_ms

    def _effective_duration_seconds(self) -> int:
        duration = _player_duration_seconds(self.player)
        if duration > 0:
            self.cached_duration = duration
            return duration
        if self.cached_duration > 0:
            return self.cached_duration
        if self.resolution is not None and self.resolution.thumbnail_count > 0:
            return int(self.resolution.thumbnail_count * self._interval_ms() / 1000)
        return 0

    def _clear_preview_session(self, reason: str = "") -> None:
        if reason:
            _debug(f"Preview session cleared: {reason}")
        self.last_preview_second = -1
        self._last_preview_thumb_index = -1
        self.was_seeking = False
        self.preview_active = False
        self.seek_hold_until = 0.0
        self.clear_preview_properties()

    def clear_preview_properties(self) -> None:
        self.preview.hide_preview()
        self.preview_visible = False
        self.committed_seek_second = -1
        self.committed_seek_at = 0.0
        for prop in (
            PROP_TILE,
            PROP_COL,
            PROP_ROW,
            PROP_THUMB_W,
            PROP_THUMB_H,
            PROP_SEEKING,
            PROP_AVAILABLE,
            *PREVIEW_PROPERTIES,
        ):
            clear_trickplay_property(prop)

    def reset_playback_state(self) -> None:
        self.resolution = None
        self.playing_file = ""
        self.last_preview_second = -1
        self._last_preview_thumb_index = -1
        self.was_seeking = False
        self.preview_active = False
        self.preview_visible = False
        self.committed_seek_second = -1
        self.committed_seek_at = 0.0
        self.last_play_time = -1
        self.playback_started_at = 0.0
        self.cached_duration = 0
        self.seek_hold_until = 0.0
        self._had_compact_seekbar = False
        self._had_dialog_seekbar = False
        self._had_seek_ui = False
        self._pending_seek_ui_warm = False
        self._last_idle_prefetch_at = 0.0
        self._last_seek_activity_at = 0.0
        self._last_tile_refine_started_for = ""
        self._load_target = ""
        self._load_settled_for = ""
        self._skippy_skipping_latched = False
        self._skip_landing_second = -1
        self._skip_hiding_since = 0.0
        self.prefetch.cancel()
        end_decoded_tile_session()
        self._playback_block_reason = ""
        clear_trickplay_property(PROP_SUPPRESS_AFTER_SKIP)
        self.clear_preview_properties()

    def _refresh_resolution_if_needed(self) -> None:
        if self.resolution is None or self.resolution.is_usable:
            return

        duration_seconds = _player_duration_seconds(self.player)
        if duration_seconds > 0:
            self.cached_duration = duration_seconds
        runtime = read_runtime_settings()
        auto_tile_grid, manual_tile_grid = runtime.auto_tile_grid, runtime.manual_tile_grid
        self.resolution = enrich_resolution(
            self.resolution,
            duration_seconds,
            self._interval_ms(),
            auto_tile_grid=auto_tile_grid,
            manual_tile_grid=manual_tile_grid,
            debug=runtime.debug_logging,
        )
        if self.resolution.is_usable:
            _log(
                f"Trickplay metadata refreshed: {self.resolution.thumbnail_count} thumbs, "
                f"thumb size {self.resolution.thumb_width}x{self.resolution.thumb_height}"
            )

    def _scrub_guard_active(self) -> bool:
        return time.monotonic() - self.playback_started_at < PLAYBACK_SCRUB_GUARD_SEC

    def _preview_allowed(self) -> bool:
        return self.resolution is not None and self.resolution.is_usable

    def _playback_block_message(self) -> str:
        if self._load_in_progress():
            return "trickplay still loading"
        if self.playing_file and self._load_settled_for != self.playing_file:
            return "trickplay load has not finished"
        if self.resolution is None:
            return "no trickplay sidecar for this file"
        if not self.resolution.is_usable:
            return "trickplay metadata unusable (check kodi.log at playback start)"
        return ""

    def _log_playback_block_once(self) -> None:
        message = self._playback_block_message()
        if not message or message == self._playback_block_reason:
            return
        self._playback_block_reason = message
        _log(f"Preview unavailable during playback: {message}", xbmc.LOGINFO)

    def _current_playing_file(self) -> str:
        try:
            if not self.player.isPlayingVideo():
                return ""
            return self.player.getPlayingFile() or ""
        except RuntimeError:
            return ""

    def _load_in_progress(self) -> bool:
        return self._load_thread is not None and self._load_thread.is_alive()

    def _ensure_playback_loaded(self) -> None:
        playing_file = self._current_playing_file()
        if not playing_file:
            return
        if playing_file == self._load_settled_for:
            return
        if playing_file == self.playing_file and self.resolution is not None:
            return
        if self._load_in_progress() and playing_file == self._load_target:
            return
        self.on_video_started(playing_file)

    def _mark_load_settled(self, playing_file: str) -> None:
        if playing_file == self.playing_file:
            self._load_settled_for = playing_file

    def _load_trickplay_worker(self, playing_file: str) -> None:
        try:
            duration_seconds = _player_duration_seconds(self.player)
            if duration_seconds > 0:
                self.cached_duration = duration_seconds
            runtime = read_runtime_settings()
            auto_tile_grid, manual_tile_grid = (
                runtime.auto_tile_grid,
                runtime.manual_tile_grid,
            )

            resolution = load_trickplay_for_file(
                playing_file,
                preferred_width=runtime.preferred_width,
                interval_ms=runtime.interval_ms,
                duration_seconds=duration_seconds,
                auto_tile_grid=auto_tile_grid,
                manual_tile_grid=manual_tile_grid,
                interval_preference=runtime.interval_preference,
                debug=runtime.debug_logging,
            )
            if resolution is None:
                _log(f"No trickplay data for {playing_file}")
                return

            if playing_file != self.playing_file:
                return

            self.resolution = resolution
            if not self.resolution.is_usable:
                self._refresh_resolution_if_needed()

            if self.resolution is None or not self.resolution.is_usable:
                tile_count = len(self.resolution.tile_paths) if self.resolution else 0
                _log(
                    f"Trickplay folder found but metadata unusable for {playing_file} "
                    f"(tiles={tile_count})",
                    xbmc.LOGWARNING,
                )
                return

            if playing_file != self.playing_file:
                return

            HOME_WINDOW.setProperty(PROP_AVAILABLE, "true")
            sync_trickplay_property(PROP_AVAILABLE, "true")
            sync_display_settings()
            prefetch_settings = read_prefetch_settings()
            begin_decoded_tile_session(
                len(self.resolution.tile_paths),
                ram_max=prefetch_settings.decoded_tile_ram_max,
            )
            _log(
                f"Loaded trickplay for {playing_file} "
                f"({self.resolution.thumbnail_count} thumbs, "
                f"{self.resolution.thumb_width}x{self.resolution.thumb_height}, "
                f"{len(self.resolution.tile_paths)} tile file(s))"
            )

            from pillow_installer import pillow_is_available

            if not pillow_is_available():
                _log(
                    "Preview cropping needs Pillow; use Install preview tools in add-on settings",
                    xbmc.LOGWARNING,
                )
                self._preview_tools_install_prompt_pending = True

            play_seconds = _player_time_seconds(self.player)
            runtime = read_runtime_settings()
            warm_lookup = lookup_thumbnail(
                self.resolution, play_seconds, self._interval_ms()
            )
            first_tile = (
                self.resolution.tile_paths[0] if self.resolution.tile_paths else ""
            )
            prioritize = tuple(
                path
                for path in (first_tile, warm_lookup.tile_path if warm_lookup else "")
                if path
            )
            self.prefetch.schedule_episode_preload(
                self.resolution,
                self._interval_ms(),
                prioritize=prioritize,
                settings=prefetch_settings,
                debug=runtime.debug_logging,
            )
            if warm_lookup is not None:
                self.prefetch.start_playback_tile_cache(
                    self.resolution,
                    warm_lookup,
                    self._interval_ms(),
                    settings=prefetch_settings,
                )
                self.prefetch.schedule_playhead_warm(
                    self.resolution,
                    warm_lookup,
                    self._interval_ms(),
                    settings=prefetch_settings,
                    debug=runtime.debug_logging,
                )
            if prefetch_settings.preload_tiles:
                self.prefetch.enable_episode_precrop()
            if playing_file == self.playing_file:
                self._pending_seek_ui_warm = True
        except Exception as exc:
            _log(f"Trickplay load failed for {playing_file!r}: {exc}", xbmc.LOGERROR)
        finally:
            self._mark_load_settled(playing_file)

    def on_video_started(self, playing_file: str) -> None:
        if not playing_file:
            return
        if playing_file == self._load_settled_for:
            return
        if playing_file == self.playing_file and self.resolution is not None:
            return
        if self._load_in_progress() and playing_file == self._load_target:
            return

        _log(f"Playback started: {playing_file}")
        self._log_skin_profile()
        self.preview.detach_overlay()
        self.generator.pause_for_playback()
        self.reset_playback_state()
        self.playing_file = playing_file
        self._load_target = playing_file
        self._playback_block_reason = ""
        self.playback_started_at = time.monotonic()

        self._load_thread = threading.Thread(
            target=self._load_trickplay_worker,
            args=(playing_file,),
            daemon=True,
            name="trickplay-load",
        )
        self._load_thread.start()

    def _start_last_tile_refine(self, playing_file: str) -> None:
        if self.resolution is None or len(self.resolution.tile_paths) <= 1:
            return
        if self._last_tile_refine_started_for == playing_file:
            return
        self._last_tile_refine_started_for = playing_file
        threading.Thread(
            target=self._refine_last_tile_count,
            args=(playing_file,),
            daemon=True,
            name="trickplay-last-tile",
        ).start()

    def _refine_last_tile_count(self, playing_file: str) -> None:
        """Probe the last sprite after 0.jpg is already local, to count a partial tile."""
        if self.resolution is None or playing_file != self.playing_file:
            return
        runtime = read_runtime_settings()
        try:
            refined = enrich_resolution(
                self.resolution,
                self._effective_duration_seconds(),
                self._interval_ms(),
                auto_tile_grid=runtime.auto_tile_grid,
                manual_tile_grid=runtime.manual_tile_grid,
                debug=runtime.debug_logging,
                probe_last_tile=True,
            )
        except Exception as exc:
            _log(f"Last-tile count refine failed: {exc}", xbmc.LOGWARNING)
            return
        if playing_file != self.playing_file:
            return
        if refined.is_usable:
            self.resolution = refined
            _debug(
                f"Refined thumbnail count from last tile: {refined.thumbnail_count}"
            )

    def _publish_sprite_properties(self, lookup) -> None:
        """Publish thumb grid indices for skin/debug."""
        sync_trickplay_property(PROP_COL, str(lookup.col))
        sync_trickplay_property(PROP_ROW, str(lookup.row))
        sync_trickplay_property(PROP_THUMB_W, str(lookup.thumb_width))
        sync_trickplay_property(PROP_THUMB_H, str(lookup.thumb_height))

    def update_preview(self, target_second: int, seeking: bool) -> bool:
        if self.resolution is None:
            return False

        self._refresh_resolution_if_needed()
        if not self.resolution.is_usable:
            return False

        target_second = max(target_second, 0)
        if not seeking and target_second == self.last_preview_second:
            return self.preview_visible

        interval_ms = self._interval_ms()
        lookup = lookup_thumbnail(self.resolution, target_second, interval_ms)
        if lookup is None:
            _debug(f"No trickplay lookup for {target_second}s")
            return False

        if (
            seeking
            and target_second == self.last_preview_second
            and lookup.thumb_index == self._last_preview_thumb_index
        ):
            return self.preview_visible

        self.last_preview_second = target_second
        sync_trickplay_property(PROP_SEEKING, "true" if seeking else "false")
        self._publish_sprite_properties(lookup)
        _debug(
            f"Preview {target_second}s -> tile {lookup.tile_path} "
            f"cell ({lookup.col},{lookup.row}) index {lookup.thumb_index}"
        )

        scrub_direction = 0
        if self._last_preview_thumb_index >= 0:
            if lookup.thumb_index > self._last_preview_thumb_index:
                scrub_direction = 1
            elif lookup.thumb_index < self._last_preview_thumb_index:
                scrub_direction = -1
        self._last_preview_thumb_index = lookup.thumb_index

        prefetch_settings = read_prefetch_settings()
        runtime = read_runtime_settings()
        # Free crop bandwidth before the foreground thumb path runs.
        if seeking:
            self.prefetch.yield_for_scrub(
                lookup.tile_path,
                keep_index=lookup.thumb_index,
                scrub_direction=scrub_direction,
            )
            next_tile = self._adjacent_tile_path(lookup, scrub_direction)
            # All tiles are scheduled once at playback load. During scrub only
            # move the two useful tiles to the front; rebuilding the complete
            # copy deque on every poll was O(tile count) at seek frequency.
            self.prefetch.prioritize_tile_copy(lookup.tile_path)
            if next_tile:
                self.prefetch.prioritize_tile_copy(next_tile)

        duration_seconds = self._effective_duration_seconds()
        self.preview.show_preview(
            lookup,
            duration_seconds,
            self.player,
            eager=seeking,
            resolution=self.resolution,
            interval_ms=interval_ms,
        )
        if prefetch_settings.enabled:
            self.prefetch.schedule_neighbors(
                self.resolution,
                lookup,
                interval_ms,
                scrub_direction=scrub_direction,
                settings=prefetch_settings,
                debug=runtime.debug_logging,
                seeking=seeking,
            )
            if seeking:
                # Neighbour jobs that are still far from the cursor wait; keep
                # only the current window so a long drag does not FIFO the path.
                self.prefetch.yield_for_scrub(
                    lookup.tile_path,
                    keep_index=lookup.thumb_index,
                    scrub_direction=scrub_direction,
                )
        return True

    def _adjacent_tile_path(self, lookup, scrub_direction: int) -> str | None:
        if self.resolution is None or not self.resolution.tile_paths:
            return None
        try:
            index = self.resolution.tile_paths.index(lookup.tile_path)
        except ValueError:
            return None
        if scrub_direction > 0 and index + 1 < len(self.resolution.tile_paths):
            return self.resolution.tile_paths[index + 1]
        if scrub_direction < 0 and index > 0:
            return self.resolution.tile_paths[index - 1]
        # No direction yet: warm the next tile if any.
        if index + 1 < len(self.resolution.tile_paths):
            return self.resolution.tile_paths[index + 1]
        if index > 0:
            return self.resolution.tile_paths[index - 1]
        return None

    def _maybe_playback_prefetch(
        self,
        play_seconds: int,
        *,
        high_priority: bool = False,
        force: bool = False,
    ) -> None:
        if self.resolution is None or not self.resolution.is_usable:
            return
        prefetch_settings = read_prefetch_settings()
        if not prefetch_settings.enabled or not prefetch_settings.during_playback:
            return
        runtime = read_runtime_settings()
        self.prefetch.schedule_playhead_follow(
            self.resolution,
            play_seconds,
            self._interval_ms(),
            settings=prefetch_settings,
            debug=runtime.debug_logging,
            high_priority=high_priority,
            force=force,
        )

    def _maybe_idle_prefetch(self, play_seconds: int) -> None:
        prefetch_settings = read_prefetch_settings()
        if (
            not prefetch_settings.enabled
            or not prefetch_settings.idle_tile
            or self.resolution is None
        ):
            return

        now = time.monotonic()
        if now - self._last_idle_prefetch_at < 3.0:
            return
        self._last_idle_prefetch_at = now

        runtime = read_runtime_settings()
        lookup = lookup_thumbnail(self.resolution, play_seconds, self._interval_ms())
        if lookup is None:
            return

        self.prefetch.schedule_idle_tile(
            self.resolution,
            lookup,
            self._interval_ms(),
            settings=prefetch_settings,
            debug=runtime.debug_logging,
        )

    def _prepare_seek_ui_preview(self, play_seconds: int) -> None:
        """Queue the playhead sprite and neighbors when seek OSD opens.

        Does not crop on this thread, so the seek bar is not blocked on a
        cold sprite decode.
        """
        if not self._preview_allowed():
            return
        if self._skippy_suppress_active():
            return

        runtime = read_runtime_settings()
        prefetch_settings = read_prefetch_settings()
        interval_ms = self._interval_ms()
        lookup = lookup_thumbnail(self.resolution, play_seconds, interval_ms)
        if lookup is None:
            return

        if prefetch_settings.enabled:
            self.prefetch.start_playback_tile_cache(
                self.resolution,
                lookup,
                interval_ms,
                settings=prefetch_settings,
            )
            self.prefetch.schedule_all_tile_copies(
                self.resolution.tile_paths,
                prioritize=(lookup.tile_path,),
                debug=runtime.debug_logging,
            )
            self.prefetch.schedule_playhead_warm(
                self.resolution,
                lookup,
                interval_ms,
                settings=prefetch_settings,
                debug=runtime.debug_logging,
            )
            self.prefetch.schedule_neighbors(
                self.resolution,
                lookup,
                interval_ms,
                scrub_direction=0,
                settings=prefetch_settings,
                debug=runtime.debug_logging,
            )
        _debug(
            f"Seek UI warm at {play_seconds}s -> index {lookup.thumb_index}"
        )

    def on_playback_seek(self, time_ms: int) -> None:
        """Authoritative seek target from Kodi; survives SeekTime label flicker."""
        if not self._preview_allowed():
            return
        target_second = max(int(time_ms / 1000), 0)

        # First seek while Skippy.Skipping is set = segment skip landing (keep hidden).
        if self._skippy_skipping_set() and self._skip_landing_second < 0:
            self._note_skip_landing(target_second)
            if self.preview_active or self.preview_visible:
                self._clear_preview_session("Skippy skip")
            return

        # Later seek / OSD intent: clear Skippy.Skipping so the seekbar can show.
        if self._skippy_suppress_active(
            scrubbing=True,
            target_second=target_second,
            allow_seek_clear=True,
        ):
            if self.preview_active or self.preview_visible:
                self._clear_preview_session("Skippy skip")
            return

        self.committed_seek_second = target_second
        self.committed_seek_at = time.monotonic()
        _debug(f"Seek event -> {target_second}s")

        play_seconds = _player_time_seconds(self.player)
        user_seek = (
            xbmc.getCondVisibility(
                "Player.Seeking | !String.IsEmpty(Player.SeekNumeric)"
            )
            or self._seek_ui_visible()
            or abs(target_second - play_seconds) > 2
        )
        if not user_seek:
            return

        self._touch_seek_hold()
        sync_display_settings()
        if not self.update_preview(target_second, seeking=True):
            return
        self.preview_active = True
        self.was_seeking = True
        self._set_preview_visible(True)
        self._maybe_playback_prefetch(
            target_second, high_priority=True, force=True
        )

    def _seek_target_seconds(self, play_seconds: int) -> int:
        seek_seconds = _parse_time_label(xbmc.getInfoLabel("Player.SeekTime"))
        if seek_seconds > 0 and abs(seek_seconds - play_seconds) >= 1:
            return seek_seconds
        if seek_seconds > 0:
            return seek_seconds

        now = time.monotonic()
        if (
            self.committed_seek_second >= 0
            and now - self.committed_seek_at < 2.0
        ):
            return self.committed_seek_second

        if (
            self.was_seeking
            and self.last_preview_second >= 0
            and abs(self.last_preview_second - play_seconds) > 2
            and (
                self._seek_ui_visible()
                or xbmc.getCondVisibility(
                    "Player.Seeking | !String.IsEmpty(Player.SeekNumeric)"
                )
            )
        ):
            return self.last_preview_second

        return play_seconds

    def _dialog_seekbar_visible(self) -> bool:
        return xbmc.getCondVisibility(
            "Window.IsVisible(seekbar) | Window.IsActive(seekbar) | "
            "Window.IsVisible(DialogSeekBar.xml)"
        )

    def _video_osd_visible(self) -> bool:
        return active_profile().full_osd_visible()

    def _seek_ui_visible(self) -> bool:
        profile = active_profile()
        return (
            self._dialog_seekbar_visible()
            or self._video_osd_visible()
            or profile.fullscreen_seek_ui_visible()
        )

    def _window_focus_id(self, window_id: int) -> int:
        try:
            return xbmcgui.Window(window_id).getFocusId()
        except RuntimeError:
            return 0

    def _seekbar_focused(self) -> bool:
        focus_id = active_profile().seekbar_focus_id
        if xbmc.getCondVisibility(f"Control.HasFocus({focus_id})"):
            return True
        if self._dialog_seekbar_visible():
            return self._window_focus_id(SEEKBAR_WINDOW_ID) == focus_id
        return False

    def _osd_play_controls_focused(self) -> bool:
        return active_profile().osd_play_controls_focused()

    def _set_preview_visible(self, visible: bool) -> None:
        if visible == self.preview_visible:
            return
        self.preview_visible = visible
        sync_display_settings()
        sync_trickplay_property(PROP_PREVIEW_VISIBLE, "true" if visible else "false")
        _debug(f"Preview visible -> {visible}")

    def _maybe_idle_heavy_work(self, seeking_active: bool) -> None:
        """Episode pre-crop and last-tile probe wait until scrubbing is idle."""
        if self.resolution is None or not self.playing_file:
            return
        now = time.monotonic()
        busy = (
            seeking_active
            or self._last_poll_scrubbing
            or self.preview.fast_scrub_active
        )
        if busy:
            self._last_seek_activity_at = now
            return
        started = self._last_seek_activity_at or self.playback_started_at
        idle_for = now - started if started else 0.0
        if idle_for >= EPISODE_PRECROP_IDLE_SEC and self.preview_visible:
            self.prefetch.enable_episode_precrop()
        last_tile = (
            self.resolution.tile_paths[-1] if self.resolution.tile_paths else ""
        )
        copies_ready = (
            len(self.resolution.tile_paths) <= 1
            or self.prefetch.tile_copy_is_done(last_tile)
        )
        if copies_ready or idle_for >= LAST_TILE_REFINE_IDLE_SEC:
            self._start_last_tile_refine(self.playing_file)

    def _preview_should_show(self, scrubbing: bool) -> bool:
        if not self.preview_active or self.last_preview_second < 0:
            return False
        if self._skippy_suppress_active(
            scrubbing=scrubbing, target_second=self.last_preview_second
        ):
            return False
        if not self._seek_ui_visible():
            return False
        if self._osd_play_controls_focused():
            try:
                from preview_settings import read_preview_adjustment_settings

                if not read_preview_adjustment_settings().show_during_play_controls:
                    return False
            except ImportError:  # pragma: no cover
                return False
        if scrubbing or self._seek_hold_active():
            return True
        if self._preview_follows_playhead() and not xbmc.getCondVisibility(
            "Player.Paused"
        ):
            return True
        if self._seekbar_focused():
            return True
        # Full video OSD without seekbar focus: hide stale preview.
        return not self._video_osd_visible()

    def _is_scrubbing(self) -> tuple[bool, int]:
        play_seconds = _player_time_seconds(self.player)

        if xbmc.getCondVisibility("!String.IsEmpty(Player.SeekNumeric)"):
            return True, self._seek_target_seconds(play_seconds)

        if xbmc.getCondVisibility("Player.Seeking") and self._explicit_seek_active():
            if not self._scrub_guard_active() or self._seek_ui_visible():
                return True, self._seek_target_seconds(play_seconds)

        if not xbmc.getCondVisibility("Player.Paused"):
            return False, play_seconds

        if not self._seek_ui_visible():
            return False, play_seconds

        if self._scrub_guard_active():
            return False, play_seconds

        seek_label = xbmc.getInfoLabel("Player.SeekTime")
        seek_seconds = _parse_time_label(seek_label) if seek_label else play_seconds

        # Paused skip while seek UI is open (SeekTime label ahead of playhead).
        if seek_label and abs(seek_seconds - play_seconds) >= 1:
            return True, seek_seconds

        # Paused frame-step / chapter step.
        if play_seconds != self.last_play_time:
            return True, play_seconds

        return False, play_seconds

    def _maybe_prompt_preview_tools_install(self) -> None:
        if (
            self._preview_tools_install_prompt_done
            or not self._preview_tools_install_prompt_pending
        ):
            return
        if not self.player.isPlayingVideo() or not self._preview_allowed():
            return

        self._preview_tools_install_prompt_done = True
        self._preview_tools_install_prompt_pending = False

        try:
            from pillow_installer import should_offer_pillow_download

            if not should_offer_pillow_download():
                return
        except ImportError:
            return

        title = ADDON.getLocalizedString(32131)
        message = ADDON.getLocalizedString(32130)
        if xbmcgui.Dialog().yesno(
            title,
            message,
            yeslabel=ADDON.getLocalizedString(32105),
            nolabel=ADDON.getLocalizedString(32100),
        ):
            _log("First-playback Pillow install accepted; launching install_tools")
            xbmc.executebuiltin("RunScript(service.trickplay,install_tools,playback)")
        else:
            _log("First-playback Pillow install declined")

    def _maybe_prompt_snippet_install(self) -> None:
        if self._skin_snippet_prompt_done:
            return
        if not self.player.isPlayingVideo():
            return
        self._skin_snippet_prompt_done = True
        try:
            from snippet_nudge import prompt_snippet_install, snippet_needs_attention

            if not snippet_needs_attention():
                return
            prompt_snippet_install(from_playback=True)
        except Exception as exc:
            _log(f"Skin snippet prompt failed: {exc}", xbmc.LOGWARNING)

    def _adaptive_poll_ms(self) -> int:
        if not self.player.isPlayingVideo():
            generator = read_generator_settings()
            if generator.enabled and generator.while_idle:
                return POLL_MS_IDLE_GENERATOR
            return POLL_MS_IDLE
        return self.poll_ms

    def poll_seek_state(self) -> None:
        try:
            self._poll_seek_state()
        except Exception as exc:
            _log(f"Poll error: {exc}", xbmc.LOGERROR)
            self._next_poll_ms = self.poll_ms

    def _poll_seek_state(self) -> None:
        self._log_skin_profile()
        self.preview.poll()
        self._ensure_playback_loaded()

        if not self.player.isPlayingVideo():
            if self.preview_active or self.preview_visible or self.was_seeking:
                self._clear_preview_session()
            self.last_play_time = -1
            self.generator.resume_after_playback()
            self.library_batch.maybe_flush(True)
            self.generator.maybe_idle_tick(True)
            self._next_poll_ms = self._adaptive_poll_ms()
            return

        self.generator.pause_for_playback()
        self._maybe_prompt_snippet_install()

        if not self._preview_allowed():
            if self.player.isPlayingVideo() and self._seek_ui_visible():
                self._log_playback_block_once()
            self._next_poll_ms = self.poll_ms
            return

        self._maybe_prompt_preview_tools_install()

        play_seconds = _player_time_seconds(self.player)
        if not xbmc.getCondVisibility("Player.Paused"):
            self.last_play_time = play_seconds

        dialog_seekbar = self._dialog_seekbar_visible()
        video_osd = self._video_osd_visible()
        seek_ui = self._seek_ui_visible()
        compact_seekbar = dialog_seekbar and not video_osd

        scrubbing, target_second = self._is_scrubbing()
        self._last_poll_scrubbing = scrubbing

        if self._skippy_suppress_active(
            scrubbing=scrubbing,
            target_second=target_second,
            allow_seek_clear=False,
        ):
            if self.preview_active or self.preview_visible or self.last_preview_second >= 0:
                self._clear_preview_session("Skippy skip")
            self._next_poll_ms = self._adaptive_poll_ms()
            return

        seeking_active = scrubbing or xbmc.getCondVisibility(
            "Player.Seeking | !String.IsEmpty(Player.SeekNumeric)"
        )
        self._maybe_idle_heavy_work(seeking_active)
        seek_ui_rising = seek_ui and not self._had_seek_ui
        self._last_poll_seek_ui = seek_ui

        if seek_ui_rising or self._pending_seek_ui_warm:
            self._prepare_seek_ui_preview(play_seconds)
            self._pending_seek_ui_warm = False

        if (
            video_osd
            and self._had_compact_seekbar
            and not compact_seekbar
            and not seeking_active
            and self.preview_active
            and active_profile().clears_preview_on_osd_handoff()
        ):
            self._clear_preview_session("compact seekbar -> full OSD")
            # Drop the scrub-path FIFO; local sprite copies stay warm.
            self.prefetch.cancel(clear_copies=False)

        compact_seekbar_rising = compact_seekbar and not self._had_compact_seekbar
        self._had_compact_seekbar = compact_seekbar

        if (
            compact_seekbar_rising
            and self._had_seek_ui
            and not seek_ui_rising
        ):
            # Seek UI never fell (full OSD still counted as seek UI). Re-warm
            # the playhead so the next scrub starts from the current cell.
            self.prefetch.cancel(clear_copies=False)
            self._prepare_seek_ui_preview(play_seconds)

        if dialog_seekbar and not self._had_dialog_seekbar:
            if self.last_preview_second >= 0 or self.preview_visible:
                resync_preview_to_seekbar(force=True)
        if not dialog_seekbar:
            self._had_dialog_seekbar = False
        else:
            self._had_dialog_seekbar = True

        if not seek_ui:
            self._had_seek_ui = False
            if self.preview_active or self.last_preview_second >= 0 or self.preview_visible:
                self._clear_preview_session()
            self._next_poll_ms = self._adaptive_poll_ms()
            return

        self._had_seek_ui = True
        sync_display_settings()

        if scrubbing:
            if self.update_preview(target_second, seeking=True):
                self.preview_active = True
                self.was_seeking = True
                self._touch_seek_hold()
                self._set_preview_visible(True)
            self._next_poll_ms = self._adaptive_poll_ms()
            return

        if self.was_seeking:
            self.was_seeking = False
            if self._preview_should_show(False):
                self._set_preview_visible(True)
            else:
                self._clear_preview_session()
            self._next_poll_ms = self._adaptive_poll_ms()
            return

        if self._preview_should_show(False):
            resync_preview_to_seekbar()
            if self._preview_follows_playhead() and not xbmc.getCondVisibility(
                "Player.Paused"
            ):
                if self.update_preview(play_seconds, seeking=False):
                    self._set_preview_visible(True)
            else:
                self._maybe_idle_prefetch(
                    self.last_preview_second
                    if self.last_preview_second >= 0
                    else play_seconds
                )
                if not scrubbing:
                    self._maybe_playback_prefetch(play_seconds)
                self._set_preview_visible(True)
            self._next_poll_ms = self._adaptive_poll_ms()
            return

        self._clear_preview_session()
        self._next_poll_ms = self._adaptive_poll_ms()

    def run(self) -> None:
        try:
            from pillow_installer import invalidate_pillow_cache
            from thumb_cropper import invalidate_playback_ffmpeg_cache

            invalidate_pillow_cache()
            invalidate_playback_ffmpeg_cache()
        except ImportError:
            pass
        try:
            from temp_cleanup import cleanup_orphaned_generator_temp

            cleanup_orphaned_generator_temp()
        except ImportError:
            pass
        _log(
            f"Service initialized (display=skin v{ADDON.getAddonInfo('version')})"
        )
        try:
            from snippet_nudge import notify_stale_or_missing_snippet

            notify_stale_or_missing_snippet()
        except Exception as exc:
            _log(f"Skin snippet startup check failed: {exc}", xbmc.LOGWARNING)
        while not self.monitor.abortRequested():
            self.poll_seek_state()
            if self.monitor.waitForAbort(self._next_poll_ms / 1000.0):
                break
        self.reset_playback_state()
        self.generator.cancel()
        _log("Service stopped")


class KodiPlayer(xbmc.Player):
    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self.service: TrickplayService = kwargs["service"]
        self._is_playing_video = False

    def _start_trickplay_for_current_file(self) -> None:
        if not self.isPlayingVideo():
            return
        try:
            playing_file = self.getPlayingFile()
        except RuntimeError:
            return
        if playing_file:
            self._is_playing_video = True
            self.service.on_video_started(playing_file)

    def onAVStarted(self) -> None:
        self._start_trickplay_for_current_file()

    def onPlayBackStarted(self) -> None:
        self._start_trickplay_for_current_file()

    def onPlayBackEnded(self) -> None:
        self._on_playback_stopped()

    def onPlayBackStopped(self) -> None:
        self._on_playback_stopped()

    def onPlayBackSeek(self, time_ms: int, seek_offset: int) -> None:
        self.service.on_playback_seek(time_ms)

    def _on_playback_stopped(self) -> None:
        self._is_playing_video = False
        self.service.reset_playback_state()


if __name__ == "__main__":
    TrickplayService().run()
