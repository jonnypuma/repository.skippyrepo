"""Tests for post-segment-skip preview suppression."""
from __future__ import annotations

import sys
import types
import unittest
from pathlib import Path
from unittest.mock import MagicMock, patch

ROOT = str(Path(__file__).resolve().parents[1])
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

for _name in ("xbmc", "xbmcaddon", "xbmcvfs", "xbmcgui"):
    sys.modules.setdefault(_name, types.ModuleType(_name))

sys.modules["xbmc"].LOGINFO = 1
sys.modules["xbmc"].LOGWARNING = 2
sys.modules["xbmc"].LOGERROR = 3
sys.modules["xbmc"].getCondVisibility = MagicMock(return_value=False)
sys.modules["xbmc"].getInfoLabel = MagicMock(return_value="")
sys.modules["xbmc"].executeJSONRPC = MagicMock(return_value="{}")
sys.modules["xbmc"].log = MagicMock()
sys.modules["xbmc"].Monitor = type("Monitor", (), {"__init__": lambda self: None})
sys.modules["xbmc"].Player = type("Player", (), {"__init__": lambda self, *a, **k: None})
sys.modules["xbmcvfs"].translatePath = lambda path: path
sys.modules["xbmcaddon"].Addon = MagicMock(
    return_value=MagicMock(
        getAddonInfo=MagicMock(return_value=ROOT),
        getSettingInt=MagicMock(return_value=100),
        getSettingString=MagicMock(return_value=""),
        getSettingBool=MagicMock(return_value=False),
        getLocalizedString=MagicMock(return_value=""),
    )
)
sys.modules["xbmcgui"].Window = MagicMock()
sys.modules["xbmcgui"].Dialog = MagicMock()

import service as trickplay_service  # noqa: E402


def _bind(svc, name: str):
    return getattr(trickplay_service.TrickplayService, name).__get__(
        svc, trickplay_service.TrickplayService
    )


class SkipSuppressTests(unittest.TestCase):
    def setUp(self) -> None:
        self.svc = MagicMock()
        self.svc._suppress_after_skip = False
        self.svc._skippy_skipping_latched = False
        self.svc._video_osd_visible = MagicMock(return_value=False)
        self.svc._seekbar_focused = MagicMock(return_value=False)
        self.svc._seek_ui_visible = MagicMock(return_value=False)
        for name in (
            "_set_suppress_after_skip",
            "_watch_segment_skip",
            "_user_clears_skip_suppress",
            "_skippy_suppress_active",
        ):
            setattr(self.svc, name, _bind(self.svc, name))

    def test_dialog_ignored(self) -> None:
        with patch.object(
            trickplay_service.xbmc,
            "getCondVisibility",
            side_effect=lambda cond: "SkipDialog" in cond,
        ):
            self.assertFalse(self.svc._skippy_suppress_active())
        self.assertFalse(self.svc._suppress_after_skip)

    def test_skipping_rising_edge_enters_suppress(self) -> None:
        with patch.object(
            trickplay_service,
            "sync_trickplay_property",
            MagicMock(),
        ), patch.object(
            trickplay_service.xbmc,
            "getCondVisibility",
            side_effect=lambda cond: "Skippy.Skipping" in cond,
        ):
            self.assertTrue(self.svc._skippy_suppress_active())
        self.assertTrue(self.svc._suppress_after_skip)

    def test_skip_seek_does_not_clear_while_skipping(self) -> None:
        self.svc._suppress_after_skip = True
        self.svc._skippy_skipping_latched = True

        def _cond(cond: str) -> bool:
            return "Skippy.Skipping" in cond or "Player.Seeking" in cond

        with patch.object(trickplay_service.xbmc, "getCondVisibility", side_effect=_cond):
            self.assertTrue(self.svc._skippy_suppress_active(scrubbing=True))
        self.assertTrue(self.svc._suppress_after_skip)

    def test_scrub_after_skipping_clears(self) -> None:
        self.svc._suppress_after_skip = True
        self.svc._skippy_skipping_latched = False
        with patch.object(
            trickplay_service,
            "clear_trickplay_property",
            MagicMock(),
        ), patch.object(
            trickplay_service.xbmc, "getCondVisibility", return_value=False
        ):
            self.assertFalse(self.svc._skippy_suppress_active(scrubbing=True))
        self.assertFalse(self.svc._suppress_after_skip)

    def test_osd_seekbar_focus_clears(self) -> None:
        self.svc._suppress_after_skip = True
        self.svc._skippy_skipping_latched = False
        self.svc._video_osd_visible.return_value = True
        self.svc._seekbar_focused.return_value = True
        with patch.object(
            trickplay_service,
            "clear_trickplay_property",
            MagicMock(),
        ), patch.object(
            trickplay_service.xbmc, "getCondVisibility", return_value=False
        ):
            self.assertFalse(self.svc._skippy_suppress_active(scrubbing=False))
        self.assertFalse(self.svc._suppress_after_skip)

    def test_sticky_after_skipping_clears(self) -> None:
        """Suppress stays on after Skippy.Skipping drops until user intent."""
        self.svc._suppress_after_skip = True
        self.svc._skippy_skipping_latched = True
        with patch.object(
            trickplay_service.xbmc, "getCondVisibility", return_value=False
        ):
            self.assertTrue(self.svc._skippy_suppress_active(scrubbing=False))
        self.assertFalse(self.svc._skippy_skipping_latched)
        self.assertTrue(self.svc._suppress_after_skip)


if __name__ == "__main__":
    unittest.main()
