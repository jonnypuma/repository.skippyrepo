"""Addon settings for the trickplay generator."""

from __future__ import annotations

from dataclasses import dataclass

try:
    import xbmcaddon
except ImportError:  # pragma: no cover
    xbmcaddon = None  # type: ignore[assignment]

from grid_settings import resolve_grid_preset


@dataclass(frozen=True)
class GeneratorSettings:
    enabled: bool = False
    while_idle: bool = False
    overwrite_existing: bool = False
    library_path: str = ""
    tile_width: int = 320
    interval_ms: int = 10000
    grid: str = "10x10"
    debug: bool = False


def _addon() -> xbmcaddon.Addon | None:
    if xbmcaddon is None:
        return None
    try:
        return xbmcaddon.Addon("service.trickplay")
    except RuntimeError:
        return None


def _setting_bool(setting_id: str, default: bool) -> bool:
    addon = _addon()
    if addon is None:
        return default
    try:
        return addon.getSettingBool(setting_id)
    except (RuntimeError, TypeError, ValueError):
        pass
    try:
        raw = addon.getSettingString(setting_id)
        if not raw:
            return default
        return raw.strip().lower() in ("true", "1", "yes", "on")
    except (RuntimeError, TypeError, ValueError):
        return default


def _setting_int(setting_id: str, default: int) -> int:
    addon = _addon()
    if addon is None:
        return default
    try:
        return int(addon.getSettingInt(setting_id))
    except (TypeError, ValueError, RuntimeError):
        pass
    try:
        raw = addon.getSettingString(setting_id)
        return int(raw)
    except (TypeError, ValueError, RuntimeError):
        return default


def _setting_string(setting_id: str, default: str) -> str:
    addon = _addon()
    if addon is None:
        return default
    try:
        value = addon.getSettingString(setting_id)
    except (TypeError, ValueError, RuntimeError):
        return default
    return value if value else default


def read_display_grid_settings() -> tuple[bool, str]:
    """Return (use_folder_grid, manual_grid_string)."""
    auto = _setting_bool("auto_tile_calculation", True)
    if auto:
        return True, "10x10"
    preset = _setting_string("display_tile_grid_preset", "")
    if not preset:
        return False, _setting_string("manual_tile_grid", "10x10")
    custom = _setting_string("display_tile_grid_custom", "10x10")
    return False, resolve_grid_preset(preset, custom, "10x10")


def _read_overwrite_existing() -> bool:
    return _setting_bool("generator_overwrite_existing", False)


def read_generator_settings() -> GeneratorSettings:
    preset = _setting_string("generator_tile_grid_preset", "10x10")
    custom = _setting_string("generator_tile_grid_custom", "10x10")
    return GeneratorSettings(
        enabled=_setting_bool("generator_enabled", False),
        while_idle=_setting_bool("generator_while_idle", False),
        overwrite_existing=_read_overwrite_existing(),
        library_path=_setting_string("generator_library_path", "").strip(),
        tile_width=max(_setting_int("preferred_width", 320), 120),
        interval_ms=max(_setting_int("interval_ms", 10000), 1000),
        grid=resolve_grid_preset(preset, custom, "10x10"),
        debug=_setting_bool("debug_logging", False),
    )
