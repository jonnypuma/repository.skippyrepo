"""Generate Jellyfin-compatible trickplay sprite sidecars with ffmpeg."""

from __future__ import annotations

import os
import re
import shutil
import subprocess
import uuid

import xbmc
import xbmcvfs

from generator_settings import GeneratorSettings
from grid_settings import grid_tuple
from thumb_cropper import resolve_ffmpeg_tools
from trickplay_resolver import resolve_media_path, trickplay_root_for_media

GENERATE_TEMP_ROOT = xbmcvfs.translatePath("special://temp/service.trickplay/generate/")

_VIDEO_EXTENSIONS = frozenset(
    {
        ".mkv",
        ".mp4",
        ".avi",
        ".m4v",
        ".wmv",
        ".mpg",
        ".mpeg",
        ".ts",
        ".m2ts",
        ".webm",
        ".mov",
        ".flv",
    }
)

_DURATION_RE = re.compile(r"Duration:\s(\d+):(\d+):(\d+(?:\.\d+)?)")


def _log(message: str, level=xbmc.LOGINFO) -> None:
    xbmc.log(f"[service.trickplay.generator] {message}", level)


def _debug(settings: GeneratorSettings, message: str) -> None:
    if settings.debug:
        _log(message, xbmc.LOGINFO)


def _local_path(path: str) -> str:
    if path.startswith(("special://", "vfs://", "zip://")):
        return xbmcvfs.translatePath(path)
    return path


def _ensure_dir(path: str) -> None:
    if not xbmcvfs.exists(path):
        xbmcvfs.mkdirs(path)


def _list_jpg_tiles(directory: str) -> list[str]:
    if not xbmcvfs.exists(directory):
        return []
    try:
        entries = xbmcvfs.listdir(directory)
    except OSError:
        return []
    files = entries[1] if isinstance(entries, (list, tuple)) and len(entries) == 2 else entries
    paths: list[str] = []
    for name in files:
        if str(name).lower().endswith(".jpg"):
            paths.append(os.path.join(directory, name))
    return paths


def _clear_sidecar_tiles(directory: str) -> None:
    for path in _list_jpg_tiles(directory):
        try:
            if xbmcvfs.exists(path):
                xbmcvfs.delete(path)
        except OSError:
            pass


def _has_jpg_tiles(directory: str) -> bool:
    if not xbmcvfs.exists(directory):
        return False
    try:
        entries = xbmcvfs.listdir(directory)
    except OSError:
        return False
    files = entries[1] if isinstance(entries, (list, tuple)) and len(entries) == 2 else entries
    return any(str(name).lower().endswith(".jpg") for name in files)


def sidecar_dir_for_grid(media_path: str, tile_width: int, grid: str) -> str:
    cols, rows = grid_tuple(grid)
    root = trickplay_root_for_media(media_path)
    folder = f"{tile_width} - {cols}x{rows}"
    return os.path.join(root, folder)


def has_generated_sidecar(
    media_path: str,
    tile_width: int,
    grid: str,
) -> bool:
    return _has_jpg_tiles(sidecar_dir_for_grid(media_path, tile_width, grid))


def probe_video_duration_seconds(media_path: str, debug: bool = False) -> int:
    _, ffprobe, env = resolve_ffmpeg_tools()
    local = _local_path(media_path)
    if not ffprobe or not xbmcvfs.exists(media_path):
        return 0

    cmd = [
        ffprobe,
        "-v",
        "error",
        "-show_entries",
        "format=duration",
        "-of",
        "default=noprint_wrappers=1:nokey=1",
        local,
    ]
    try:
        completed = subprocess.run(
            cmd,
            check=False,
            capture_output=True,
            text=True,
            timeout=60,
            env=env,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        _log(f"ffprobe duration failed for {media_path}: {exc}", xbmc.LOGWARNING)
        return 0

    if completed.returncode == 0:
        try:
            duration = float((completed.stdout or "").strip())
            if duration > 0:
                return max(int(duration), 1)
        except ValueError:
            pass

    ffmpeg, _, _ = resolve_ffmpeg_tools()
    if not ffmpeg:
        return 0
    try:
        completed = subprocess.run(
            [ffmpeg, "-hide_banner", "-i", local],
            check=False,
            capture_output=True,
            text=True,
            timeout=60,
            env=env,
        )
    except (OSError, subprocess.SubprocessError):
        return 0

    match = _DURATION_RE.search(completed.stderr or "")
    if not match:
        return 0
    hours, minutes, seconds = match.groups()
    duration = int(hours) * 3600 + int(minutes) * 60 + float(seconds)
    if debug:
        _log(f"Duration {int(duration)}s for {media_path} via ffmpeg stderr")
    return max(int(duration), 1)


def _extract_frame(
    ffmpeg: str,
    env: dict[str, str],
    media_path: str,
    timestamp: float,
    tile_width: int,
    output_path: str,
    debug: bool = False,
) -> bool:
    local_out = _local_path(output_path)
    _ensure_dir(os.path.dirname(local_out))
    cmd = [
        ffmpeg,
        "-y",
        "-loglevel",
        "error",
        "-ss",
        f"{max(timestamp, 0.0):.3f}",
        "-i",
        _local_path(media_path),
        "-an",
        "-sn",
        "-dn",
        "-frames:v",
        "1",
        "-vf",
        f"scale={tile_width}:-2",
        "-q:v",
        "2",
        local_out,
    ]
    try:
        completed = subprocess.run(
            cmd,
            check=False,
            capture_output=True,
            text=True,
            timeout=120,
            env=env,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        _log(f"Frame extract failed at {timestamp:.1f}s: {exc}", xbmc.LOGWARNING)
        return False

    if completed.returncode != 0:
        detail = (completed.stderr or completed.stdout or "").strip()
        _log(f"Frame extract failed at {timestamp:.1f}s: {detail}", xbmc.LOGWARNING)
        return False

    if debug:
        _log(f"Extracted frame at {timestamp:.1f}s -> {output_path}")
    return xbmcvfs.exists(output_path)


def _tile_frames(
    ffmpeg: str,
    env: dict[str, str],
    frame_paths: list[str],
    cols: int,
    rows: int,
    output_path: str,
    debug: bool = False,
) -> bool:
    if not frame_paths:
        return False

    local_out = _local_path(output_path)
    _ensure_dir(os.path.dirname(local_out))

    if len(frame_paths) == 1:
        try:
            xbmcvfs.copy(frame_paths[0], output_path)
            return xbmcvfs.exists(output_path)
        except (OSError, RuntimeError, ValueError):
            return False

    count = len(frame_paths)
    layout_cols = min(cols, count)
    layout_rows = (count + layout_cols - 1) // layout_cols

    inputs: list[str] = []
    for path in frame_paths:
        inputs.extend(["-i", _local_path(path)])

    cmd = [
        ffmpeg,
        "-y",
        "-loglevel",
        "error",
        *inputs,
        "-filter_complex",
        f"tile={layout_cols}x{layout_rows}",
        "-frames:v",
        "1",
        "-q:v",
        "2",
        local_out,
    ]
    try:
        completed = subprocess.run(
            cmd,
            check=False,
            capture_output=True,
            text=True,
            timeout=180,
            env=env,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        _log(f"Tile assembly failed: {exc}", xbmc.LOGWARNING)
        return False

    if completed.returncode != 0:
        detail = (completed.stderr or completed.stdout or "").strip()
        _log(f"Tile assembly failed: {detail}", xbmc.LOGWARNING)
        return False

    if debug:
        _log(
            f"Tiled {count} frame(s) as {layout_cols}x{layout_rows} -> {output_path}"
        )
    return xbmcvfs.exists(output_path)


def _remove_tree(path: str) -> None:
    local = _local_path(path)
    if os.path.isdir(local):
        shutil.rmtree(local, ignore_errors=True)


def generate_trickplay_for_media(
    media_path: str,
    settings: GeneratorSettings,
) -> bool:
    """Write Jellyfin-format trickplay sprites next to media_path."""
    media_path = resolve_media_path(media_path) or media_path
    if not media_path or not xbmcvfs.exists(media_path):
        _log(f"Media not found: {media_path!r}", xbmc.LOGWARNING)
        return False

    cols, rows = grid_tuple(settings.grid)
    output_dir = sidecar_dir_for_grid(media_path, settings.tile_width, settings.grid)

    if _has_jpg_tiles(output_dir):
        if not settings.overwrite_existing:
            _debug(settings, f"Skipping existing sidecar: {output_dir}")
            return True
        _clear_sidecar_tiles(output_dir)
        _log(f"Overwriting existing sidecar: {output_dir}")

    ffmpeg, _, env = resolve_ffmpeg_tools()
    if not ffmpeg:
        _log("ffmpeg not found; install tools.ffmpeg-tools", xbmc.LOGERROR)
        return False

    duration = probe_video_duration_seconds(media_path, debug=settings.debug)
    if duration <= 0:
        _log(f"Could not determine duration for {media_path}", xbmc.LOGWARNING)
        return False

    interval_sec = max(settings.interval_ms / 1000.0, 0.001)
    thumb_count = int(duration / interval_sec) + 1
    thumbs_per_tile = cols * rows
    tile_count = (thumb_count + thumbs_per_tile - 1) // thumbs_per_tile

    _ensure_dir(output_dir)
    work_dir = os.path.join(GENERATE_TEMP_ROOT, uuid.uuid4().hex)
    _ensure_dir(work_dir)

    _log(
        f"Generating trickplay for {os.path.basename(media_path)} "
        f"({thumb_count} thumbs, {settings.grid}, {settings.tile_width}px) "
        f"-> {output_dir}"
    )

    success = True
    try:
        for tile_index in range(tile_count):
            start_index = tile_index * thumbs_per_tile
            end_index = min(start_index + thumbs_per_tile, thumb_count)
            frame_paths: list[str] = []

            for thumb_index in range(start_index, end_index):
                timestamp = thumb_index * interval_sec
                frame_path = os.path.join(
                    work_dir, f"t{tile_index:04d}_f{thumb_index:05d}.jpg"
                )
                if not _extract_frame(
                    ffmpeg,
                    env,
                    media_path,
                    timestamp,
                    settings.tile_width,
                    frame_path,
                    debug=settings.debug,
                ):
                    success = False
                    break
                frame_paths.append(frame_path)

            if not success or not frame_paths:
                success = False
                break

            tile_path = os.path.join(output_dir, f"{tile_index}.jpg")
            if not _tile_frames(
                ffmpeg,
                env,
                frame_paths,
                cols,
                rows,
                tile_path,
                debug=settings.debug,
            ):
                success = False
                break

            for frame_path in frame_paths:
                try:
                    if xbmcvfs.exists(frame_path):
                        xbmcvfs.delete(frame_path)
                except OSError:
                    pass

        if success:
            _log(
                f"Generated {tile_count} tile(s) for {os.path.basename(media_path)}"
            )
        else:
            _log(
                f"Generation failed for {os.path.basename(media_path)}",
                xbmc.LOGWARNING,
            )
    finally:
        _remove_tree(work_dir)

    return success


def iter_library_videos(root: str) -> list[str]:
    """Recursively list local video files under root."""
    root = (root or "").strip()
    if not root or not xbmcvfs.exists(root):
        return []

    results: list[str] = []
    stack = [_local_path(root) if root.startswith("special://") else root]

    while stack:
        current = stack.pop()
        try:
            entries = xbmcvfs.listdir(current)
        except OSError:
            continue

        if isinstance(entries, (list, tuple)) and len(entries) == 2:
            dirs, files = entries
        else:
            dirs, files = [], entries if isinstance(entries, list) else []

        for name in files:
            ext = os.path.splitext(str(name))[1].lower()
            if ext not in _VIDEO_EXTENSIONS:
                continue
            results.append(os.path.join(current, name))

        for name in dirs:
            if str(name) in (".", ".."):
                continue
            stack.append(os.path.join(current, name))

    return sorted(results)


def collect_generation_candidates(
    root: str,
    settings: GeneratorSettings,
) -> list[str]:
    """Return media paths under root that still need trickplay sidecars."""
    candidates: list[str] = []
    for media_path in iter_library_videos(root):
        resolved = resolve_media_path(media_path) or media_path
        if (
            not settings.overwrite_existing
            and has_generated_sidecar(
                resolved,
                settings.tile_width,
                settings.grid,
            )
        ):
            continue
        candidates.append(resolved)
    return candidates
