"""Manual library batch trickplay generation."""

from __future__ import annotations

import os
import sys

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

_ADDON = xbmcaddon.Addon()
_ADDON_PATH = _ADDON.getAddonInfo("path")
if _ADDON_PATH and _ADDON_PATH not in sys.path:
    sys.path.insert(0, _ADDON_PATH)

from generator_settings import read_generator_settings
from trickplay_generator import collect_generation_candidates, generate_trickplay_for_media


def _browse_library_path(current: str) -> str | None:
    dialog = xbmcgui.Dialog()
    start = current if current and xbmcvfs.exists(current) else "special://home"
    folder = dialog.browse(
        0,
        _ADDON.getLocalizedString(32061),
        "files",
        "",
        False,
        False,
        start,
    )
    if not folder:
        return None
    return folder


def run_batch_dialog() -> None:
    settings = read_generator_settings()
    if not settings.enabled:
        xbmcgui.Dialog().ok(
            _ADDON.getLocalizedString(32040),
            _ADDON.getLocalizedString(32062),
        )
        return

    folder = settings.library_path
    if not folder or not xbmcvfs.exists(folder):
        folder = _browse_library_path(folder)
        if not folder:
            return
    else:
        choice = xbmcgui.Dialog().yesno(
            _ADDON.getLocalizedString(32063),
            _ADDON.getLocalizedString(32064) % folder,
            yeslabel=_ADDON.getLocalizedString(32065),
            nolabel=_ADDON.getLocalizedString(32066),
        )
        if not choice:
            folder = _browse_library_path(folder)
            if not folder:
                return

    candidates = collect_generation_candidates(folder, settings)
    if not candidates:
        xbmcgui.Dialog().notification(
            _ADDON.getLocalizedString(32063),
            _ADDON.getLocalizedString(32067),
            xbmcgui.NOTIFICATION_INFO,
            4000,
        )
        return

    if not xbmcgui.Dialog().yesno(
        _ADDON.getLocalizedString(32063),
        _ADDON.getLocalizedString(32068) % len(candidates),
    ):
        return

    monitor = xbmc.Monitor()
    progress = xbmcgui.DialogProgress()
    progress.create(
        _ADDON.getLocalizedString(32063),
        _ADDON.getLocalizedString(32069),
    )

    ok_count = 0
    fail_count = 0
    total = len(candidates)

    try:
        for index, media_path in enumerate(candidates):
            if monitor.abortRequested() or progress.iscanceled():
                break

            label = os.path.basename(media_path)
            progress.update(
                int((index * 100) / max(total, 1)),
                _ADDON.getLocalizedString(32070) % (index + 1, total),
                label,
            )
            if generate_trickplay_for_media(media_path, settings):
                ok_count += 1
            else:
                fail_count += 1
    finally:
        progress.close()

    xbmcgui.Dialog().ok(
        _ADDON.getLocalizedString(32063),
        _ADDON.getLocalizedString(32071) % (ok_count, fail_count),
    )


if __name__ == "__main__":
    mode = sys.argv[1] if len(sys.argv) > 1 else "batch"
    if mode == "batch":
        run_batch_dialog()
