"""Tests for Skippy skip preview suppression."""
from __future__ import annotations

import sys
import time
import types
import unittest
from pathlib import Path
from unittest.mock import MagicMock, patch

ROOT = str(Path(__file__).resolve().parents[1])
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

for _name in ("xbmc", "xbmcaddon", "xbmcvfs", "xbmcgui"):
    sys.modules.setdefault(_name, types.ModuleType(_name))

sys.modules["xbmc"].LOGINFO = 1
sys.modules["xbmc"].LOGWARNING = 2
sys.modules["xbmc"].LOGERROR = 3
sys.modules["xbmc"].getCondVisibility = MagicMock(return_value=False)
sys.modules["xbmc"].getInfoLabel = MagicMock(return_value="")
sys.modules["xbmc"].executeJSONRPC = MagicMock(return_value="{}")
sys.modules["xbmc"].log = MagicMock()
sys.modules["xbmc"].Monitor = type("Monitor", (), {"__init__": lambda self: None})
sys.modules["xbmc"].Player = type("Player", (), {"__init__": lambda self, *a, **k: None})
sys.modules["xbmcvfs"].translatePath = lambda path: path
sys.modules["xbmcaddon"].Addon = MagicMock(
    return_value=MagicMock(
        getAddonInfo=MagicMock(return_value=ROOT),
        getSettingInt=MagicMock(return_value=100),
        getSettingString=MagicMock(return_value=""),
        getSettingBool=MagicMock(return_value=False),
        getLocalizedString=MagicMock(return_value=""),
    )
)
sys.modules["xbmcgui"].Window = MagicMock()
sys.modules["xbmcgui"].Dialog = MagicMock()

import service as trickplay_service  # noqa: E402


def _bind(svc, name: str):
    return getattr(trickplay_service.TrickplayService, name).__get__(
        svc, trickplay_service.TrickplayService
    )


class SkippySuppressTests(unittest.TestCase):
    def setUp(self) -> None:
        self.svc = MagicMock()
        self.svc._skippy_suppress_until = 0.0
        self.svc._skippy_signal_latched = False
        self.svc._skippy_suppress_seek_second = -1
        self.svc._scrub_guard_active = MagicMock(return_value=False)
        self.svc._seek_ui_visible = MagicMock(return_value=False)
        for name in (
            "_skippy_signal_present",
            "_clear_skippy_suppress",
            "_stamp_skippy_suppress",
            "_note_skippy_activity",
            "_user_scrub_cancels_skippy_suppress",
            "_skippy_suppress_active",
        ):
            setattr(self.svc, name, _bind(self.svc, name))

    def test_dialog_stamps_grace_once(self) -> None:
        with patch.object(
            trickplay_service.xbmc,
            "getCondVisibility",
            side_effect=lambda cond: "SkipDialog" in cond,
        ):
            self.assertTrue(self.svc._skippy_suppress_active())
            first_until = self.svc._skippy_suppress_until
            time.sleep(0.05)
            self.assertTrue(self.svc._skippy_suppress_active())
            # Lingering toast must not keep pushing the deadline forward.
            self.assertEqual(self.svc._skippy_suppress_until, first_until)

    def test_grace_holds_after_dialog_closes(self) -> None:
        self.svc._skippy_suppress_until = time.monotonic() + 2.0
        with patch.object(
            trickplay_service.xbmc, "getCondVisibility", return_value=False
        ):
            self.assertTrue(self.svc._skippy_suppress_active())

    def test_idle_when_no_skippy(self) -> None:
        self.svc._skippy_suppress_until = 0.0
        with patch.object(
            trickplay_service.xbmc, "getCondVisibility", return_value=False
        ):
            self.assertFalse(self.svc._skippy_suppress_active())

    def test_pause_scrub_clears_grace(self) -> None:
        self.svc._skippy_suppress_until = time.monotonic() + 5.0
        self.svc._skippy_suppress_seek_second = 90
        self.svc._seek_ui_visible.return_value = True

        def _cond(cond: str) -> bool:
            if "Player.Paused" in cond:
                return True
            return False

        with patch.object(trickplay_service.xbmc, "getCondVisibility", side_effect=_cond):
            self.assertFalse(self.svc._skippy_suppress_active(scrubbing=True, target_second=120))
        self.assertEqual(self.svc._skippy_suppress_until, 0.0)

    def test_play_scrub_away_from_skip_clears_grace(self) -> None:
        self.svc._skippy_suppress_until = time.monotonic() + 5.0
        self.svc._skippy_suppress_seek_second = 90
        self.svc._seek_ui_visible.return_value = True
        with patch.object(
            trickplay_service.xbmc, "getCondVisibility", return_value=False
        ):
            self.assertFalse(
                self.svc._skippy_suppress_active(scrubbing=True, target_second=200)
            )
        self.assertEqual(self.svc._skippy_suppress_until, 0.0)

    def test_skipping_property_keeps_suppress_during_scrub(self) -> None:
        self.svc._skippy_suppress_until = time.monotonic() + 5.0
        self.svc._seek_ui_visible.return_value = True

        def _cond(cond: str) -> bool:
            return "Skippy.Skipping" in cond

        with patch.object(trickplay_service.xbmc, "getCondVisibility", side_effect=_cond):
            self.assertTrue(
                self.svc._skippy_suppress_active(scrubbing=True, target_second=200)
            )


if __name__ == "__main__":
    unittest.main()
