"""First-run / stale skin-snippet prompts and update toasts."""

from __future__ import annotations

import xbmc
import xbmcaddon
import xbmcgui

from addon_health import AddonHealth, collect_addon_health
from skin_profiles import snippet_install_supported

_ADDON = xbmcaddon.Addon("service.trickplay")

SNIPPET_ATTENTION_STATES = frozenset({"missing", "stale"})


def _log(message: str, level=xbmc.LOGINFO) -> None:
    xbmc.log(f"[service.trickplay] {message}", level)


def snippet_needs_attention(health: AddonHealth | None = None) -> bool:
    try:
        from preview_overlay import DISPLAY_MODE_OVERLAY, preview_display_mode

        if preview_display_mode() == DISPLAY_MODE_OVERLAY:
            return False
    except ImportError:
        pass
    report = health or collect_addon_health()
    return (
        snippet_install_supported(report.skin_id)
        and report.snippet_state in SNIPPET_ATTENTION_STATES
    )


def _addon() -> xbmcaddon.Addon:
    return xbmcaddon.Addon("service.trickplay")


def auto_reapply_skin_snippet_enabled() -> bool:
    addon = _addon()
    try:
        return bool(addon.getSettingBool("auto_reapply_skin_snippet"))
    except (RuntimeError, TypeError, ValueError):
        raw = addon.getSettingString("auto_reapply_skin_snippet")
        if not raw:
            return False
        return raw.strip().lower() in ("true", "1", "yes", "on")


def maybe_auto_reapply_snippet(health: AddonHealth | None = None) -> bool:
    """Re-install the active skin snippet automatically when enabled and stale/missing."""
    if not auto_reapply_skin_snippet_enabled():
        return False
    report = health or collect_addon_health()
    if not snippet_needs_attention(report):
        return False
    from skin_snippet_installer import (
        InstallScope,
        build_install_plan,
        execute_install_plan,
        plan_has_installable_targets,
        schedule_skin_reload,
        summarize_outcomes,
    )

    addon_path = _addon().getAddonInfo("path")
    plan = build_install_plan(addon_path, scope=InstallScope.CURRENT)
    if not plan_has_installable_targets(plan):
        return False
    outcomes = execute_install_plan(plan)
    ok_count, _fail_count, _skipped_count, _skin_count = summarize_outcomes(outcomes)
    if ok_count <= 0:
        return False
    _log(
        f"Auto-reapplied skin snippet for {report.skin_id} "
        f"(was {report.snippet_state}, rev {report.overlay_revision})"
    )
    schedule_skin_reload()
    title = _ADDON.getLocalizedString(32158)
    message = _ADDON.getLocalizedString(32275) or (
        "Trickplay skin overlay automatically re-applied."
    )
    try:
        xbmcgui.Dialog().notification(
            title,
            message,
            xbmcgui.NOTIFICATION_INFO,
            5000,
        )
    except (RuntimeError, TypeError, AttributeError):
        pass
    return True


def notify_stale_or_missing_snippet(health: AddonHealth | None = None) -> bool:
    """Toast on service start when the active skin overlay is missing or stale."""
    report = health or collect_addon_health()
    if not snippet_needs_attention(report):
        return False
    if maybe_auto_reapply_snippet(report):
        return False
    title = _ADDON.getLocalizedString(32158)
    message = _ADDON.getLocalizedString(32239)
    try:
        xbmcgui.Dialog().notification(
            title,
            message,
            xbmcgui.NOTIFICATION_INFO,
            8000,
        )
    except (RuntimeError, TypeError, AttributeError):
        pass
    _log(
        f"Skin snippet {report.snippet_state} for {report.skin_id} "
        f"(overlay rev {report.overlay_revision})"
    )
    return True


def prompt_message_for_snippet(health: AddonHealth) -> str:
    if health.snippet_state == "stale":
        return _ADDON.getLocalizedString(32241)
    return _ADDON.getLocalizedString(32240)


def prompt_snippet_install(*, from_playback: bool = False, inline: bool = False) -> bool:
    """Yes/No install prompt. Returns True when the user accepted."""
    health = collect_addon_health()
    if not snippet_needs_attention(health):
        return False
    if maybe_auto_reapply_snippet(health):
        return True
    title = _ADDON.getLocalizedString(32158)
    message = prompt_message_for_snippet(health)
    accepted = bool(
        xbmcgui.Dialog().yesno(
            title,
            message,
            yeslabel=_ADDON.getLocalizedString(32164),
            nolabel=_ADDON.getLocalizedString(32100),
        )
    )
    if not accepted:
        _log(
            "Skin snippet install declined"
            + (" (playback prompt)" if from_playback else "")
        )
        return False
    _log(
        "Skin snippet install accepted"
        + (" (playback prompt)" if from_playback else "")
    )
    if inline:
        from skin_snippet_installer import InstallScope
        from script_skin import run_install_skin_dialog

        run_install_skin_dialog(InstallScope.CURRENT)
    else:
        xbmc.executebuiltin("RunScript(service.trickplay,install_skin,current)")
    return True
