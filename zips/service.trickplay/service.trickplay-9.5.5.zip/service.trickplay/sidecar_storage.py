"""Sidecar directory filesystem helpers and atomic promotion."""

from __future__ import annotations

import os
import shutil
import stat
import uuid

import xbmc
import xbmcvfs

from vfs_paths import (
    extended_length_path,
    local_path as _local_path,
    vfs_join,
    writable_os_path,
)


def _log(message: str, level=xbmc.LOGINFO) -> None:
    xbmc.log(f"[service.trickplay] {message}", level)


def _ensure_dir(path: str) -> None:
    if not xbmcvfs.exists(path):
        xbmcvfs.mkdirs(path)


def _ensure_local_dir(path: str) -> None:
    """Ensure a directory exists for local subprocess I/O (ffmpeg image sequences)."""
    local = _local_path(path)
    os.makedirs(local, exist_ok=True)


def _jpg_sort_key(path: str) -> int:
    base = os.path.splitext(os.path.basename(path))[0]
    try:
        return int(base)
    except ValueError:
        return 0


def _list_jpg_files(directory: str) -> list[str]:
    """List JPEGs in directory; prefer os.listdir for ffmpeg temp output."""
    if not directory:
        return []
    local = _local_path(directory)
    paths: list[str] = []
    if local and os.path.isdir(local):
        try:
            for name in os.listdir(local):
                if str(name).lower().endswith(".jpg"):
                    paths.append(os.path.join(local, name))
        except OSError:
            pass
    if not paths:
        if not xbmcvfs.exists(directory):
            return []
        try:
            entries = xbmcvfs.listdir(directory)
        except OSError:
            return []
        files = entries[1] if isinstance(entries, (list, tuple)) and len(entries) == 2 else entries
        for name in files:
            if str(name).lower().endswith(".jpg"):
                paths.append(vfs_join(directory, name))
    return sorted(paths, key=_jpg_sort_key)


def _clear_jpg_files(directory: str) -> None:
    """Remove leftover JPEGs before a seek fallback after a failed fps batch."""
    for path in _list_jpg_files(directory):
        local = _local_path(path)
        try:
            if local and os.path.isfile(local):
                os.remove(local)
            elif xbmcvfs.exists(path):
                xbmcvfs.delete(path)
        except (OSError, RuntimeError):
            pass


def _list_jpg_tiles(directory: str) -> list[str]:
    return _list_jpg_files(directory)


def _path_exists(path: str) -> bool:
    if not path:
        return False
    local = _local_path(path)
    if local and "://" not in local:
        try:
            if os.path.exists(extended_length_path(local)):
                return True
        except OSError:
            pass
    try:
        return xbmcvfs.exists(path)
    except OSError:
        return False


def _list_immediate_entries(directory: str) -> tuple[list[str], list[str]]:
    """Return (subdir names, file names); prefer os.listdir on NFS/OS mounts."""
    dirs: list[str] = []
    files: list[str] = []
    local = _local_path(directory)
    if local and os.path.isdir(local):
        try:
            for entry in os.listdir(local):
                full = os.path.join(local, entry)
                if os.path.isdir(full):
                    dirs.append(str(entry))
                elif os.path.isfile(full):
                    files.append(str(entry))
        except OSError:
            pass
        if dirs or files:
            return dirs, files

    if not _path_exists(directory):
        return [], []

    try:
        entries = xbmcvfs.listdir(directory)
    except OSError:
        return [], []

    if isinstance(entries, (list, tuple)) and len(entries) == 2:
        return [str(name) for name in entries[0]], [str(name) for name in entries[1]]
    file_names = entries if isinstance(entries, list) else []
    return [], [str(name) for name in file_names]


def _delete_path(path: str) -> None:
    local = _local_path(path)
    if local and os.path.isfile(local):
        try:
            os.remove(local)
            return
        except OSError:
            pass
    if _path_exists(path):
        try:
            xbmcvfs.delete(path)
        except OSError:
            pass


def _remove_directory_tree(directory: str) -> None:
    if not directory:
        return
    local = _local_path(directory)
    if local and os.path.isdir(local):
        shutil.rmtree(local, ignore_errors=True)
        return
    if not _path_exists(directory):
        return

    subdirs, files = _list_immediate_entries(directory)
    for name in files:
        _delete_path(vfs_join(directory, name))
    for name in subdirs:
        _remove_directory_tree(vfs_join(directory, name))
    try:
        xbmcvfs.rmdir(directory)
    except OSError:
        pass


def _trickplay_root_for_sidecar_dir(sidecar_dir: str) -> str | None:
    parent = os.path.dirname(sidecar_dir.rstrip("/\\"))
    if parent.endswith(".trickplay"):
        return parent
    return None


def _remove_trickplay_root_if_empty(trickplay_root: str) -> None:
    if not trickplay_root or not trickplay_root.endswith(".trickplay"):
        return
    if not _path_exists(trickplay_root):
        return
    subdirs, files = _list_immediate_entries(trickplay_root)
    if subdirs or files:
        if subdirs:
            _log(
                f"Kept trickplay root ({len(subdirs)} resolution folder(s)): "
                f"{trickplay_root}"
            )
        return
    _remove_directory_tree(trickplay_root)
    _log(f"Removed empty trickplay root: {trickplay_root}")


def _clear_sidecar_tiles(directory: str) -> None:
    for path in _list_jpg_tiles(directory):
        _delete_path(path)


def _cleanup_cancelled_sidecar(directory: str) -> None:
    """Remove the in-progress resolution folder; drop parent .trickplay if alone."""
    if not directory:
        return
    trickplay_root = _trickplay_root_for_sidecar_dir(directory)
    if _path_exists(directory):
        _remove_directory_tree(directory)
        _log(f"Removed cancelled sidecar folder: {directory}")
    if trickplay_root:
        _remove_trickplay_root_if_empty(trickplay_root)


def _remove_empty_sidecar_dir(directory: str) -> None:
    """Remove a sidecar resolution folder when it contains no tile JPEGs."""
    if not directory or not _path_exists(directory):
        return
    if _has_jpg_tiles(directory):
        return
    subdirs, files = _list_immediate_entries(directory)
    if subdirs or files:
        return
    trickplay_root = _trickplay_root_for_sidecar_dir(directory)
    _remove_directory_tree(directory)
    _log(f"Removed empty sidecar folder: {directory}")
    if trickplay_root:
        _remove_trickplay_root_if_empty(trickplay_root)


def _os_error_text(exc: OSError) -> str:
    winerror = getattr(exc, "winerror", None)
    detail = exc.strerror or str(exc)
    if winerror:
        return f"WinError {winerror}: {detail}"
    if exc.errno:
        return f"errno {exc.errno}: {detail}"
    return detail


def _clear_readonly(path: str) -> None:
    try:
        os.chmod(path, os.stat(path).st_mode | stat.S_IWRITE)
    except OSError:
        pass


def _rename_should_copy_files(exc: OSError) -> bool:
    """Directory rename can be denied when the destination folder already exists."""
    winerror = getattr(exc, "winerror", None)
    if winerror in (5, 32, 183):
        return True
    return exc.errno in (1, 13, 17)


def _promote_path_attempts(
    staging: str,
    final: str,
    backup: str,
) -> list[tuple[str, str, str]]:
    """Plain paths first when they fit. Extended paths cover names past 260 characters."""
    if os.name != "nt":
        return [(staging, final, backup)]
    extended = (
        extended_length_path(staging),
        extended_length_path(final),
        extended_length_path(backup),
    )
    if max(len(staging), len(final), len(backup)) >= 260:
        return [extended]
    if extended[0] == staging:
        return [(staging, final, backup)]
    return [(staging, final, backup), extended]


def _child_path(parent: str, name: str) -> str:
    if parent.startswith("\\\\?\\"):
        return parent.rstrip("\\") + "\\" + name
    return os.path.join(parent, name)


def _replace_directory(staging: str, final: str, backup: str) -> None:
    if os.path.exists(final):
        _clear_readonly(final)
        os.replace(final, backup)
    os.replace(staging, final)
    if os.path.exists(backup):
        shutil.rmtree(backup, ignore_errors=True)


def _move_file_over(src: str, dst: str) -> None:
    if os.path.lexists(dst):
        _clear_readonly(dst)
    try:
        os.replace(src, dst)
        return
    except OSError:
        if os.path.lexists(dst):
            _clear_readonly(dst)
        shutil.copyfile(src, dst)
        _clear_readonly(src)
        os.remove(src)


def _rmtree(path: str) -> None:
    def _retry(func, item, _exc):
        _clear_readonly(item)
        func(item)

    try:
        shutil.rmtree(path, onexc=_retry)
    except TypeError:
        shutil.rmtree(path, onerror=_retry)


def _remove_existing_and_rename(staging: str, final: str) -> None:
    """Delete a destination folder Windows will not rename, then move staging into place."""
    final_io = ""
    for candidate in (final, extended_length_path(final)):
        if os.path.isdir(candidate):
            final_io = candidate
            break
    if not final_io:
        raise OSError(2, "destination folder is not present")
    _rmtree(final_io)
    staging_io = ""
    for candidate in (staging, extended_length_path(staging)):
        if os.path.isdir(candidate):
            staging_io = candidate
            break
    if not staging_io:
        raise OSError(2, "staging directory missing")
    destination = (
        extended_length_path(final)
        if staging_io.startswith("\\\\?\\") or (os.name == "nt" and len(final) >= 260)
        else final
    )
    os.replace(staging_io, destination)


def _promote_tiles_into_folder(staging: str, final: str) -> None:
    """Move staged JPEGs into the final folder when the folder itself cannot be renamed."""
    staging_io = ""
    for candidate in (staging, extended_length_path(staging)):
        if os.path.isdir(candidate):
            staging_io = candidate
            break
    if not staging_io:
        raise OSError(2, "staging directory missing")
    use_extended = staging_io.startswith("\\\\?\\") or (
        os.name == "nt" and len(final) >= 260
    )
    final_io = extended_length_path(final) if use_extended else final
    os.makedirs(final_io, exist_ok=True)
    names: list[str] = []
    for name in os.listdir(staging_io):
        src = _child_path(staging_io, name)
        if not os.path.isfile(src):
            continue
        _move_file_over(src, _child_path(final_io, name))
        names.append(name)
    if not names:
        raise OSError(2, "staging directory has no tiles")
    kept = set(names)
    for name in os.listdir(final_io):
        if name in kept or not os.path.isfile(_child_path(final_io, name)):
            continue
        extra = _child_path(final_io, name)
        _clear_readonly(extra)
        try:
            os.remove(extra)
        except OSError:
            _log(f"Could not remove old sidecar file {extra}", xbmc.LOGWARNING)
    try:
        os.rmdir(staging_io)
    except OSError:
        shutil.rmtree(staging_io, ignore_errors=True)


def _atomic_promote_sidecar(
    staging_dir: str,
    final_dir: str,
    *,
    path_resolver=None,
) -> tuple[bool, str]:
    """Replace a sidecar directory only after generation succeeds.

    Uses a mapped OS path when the VFS URL is an nfs/smb mount so network
    sidecars get the same atomic rename as local disks. Short Windows paths
    are renamed as plain paths. Paths past 260 characters use the ``\\\\?\\``
    prefix. When Windows denies the directory rename (WinError 5, typical when
    the destination folder already exists on a network share), the tiles are
    moved into that folder instead.
    Returns (promoted, error message). The message is empty on success.
    """
    resolve = writable_os_path if path_resolver is None else path_resolver
    staging = resolve(staging_dir)
    final = resolve(final_dir)
    if not staging or not final:
        return False, "no writable OS path"
    backup = f"{final}.previous-{uuid.uuid4().hex[:8]}"
    attempts = _promote_path_attempts(staging, final, backup)
    if not any(os.path.isdir(src) for src, _final, _backup in attempts):
        _log(
            "Sidecar promote failed: staging directory missing "
            f"(len={len(staging)}): {staging}",
            xbmc.LOGERROR,
        )
        return False, "staging directory missing"
    last_error = ""
    copy_tiles = False
    for src, dst, old in attempts:
        try:
            _replace_directory(src, dst, old)
            return True, ""
        except OSError as exc:
            last_error = _os_error_text(exc)
            _log(
                f"Sidecar folder rename failed ({last_error}): "
                f"staging len={len(staging)} final len={len(final)} "
                f"{staging} -> {final}",
                xbmc.LOGWARNING,
            )
            try:
                if not os.path.exists(dst) and os.path.exists(old):
                    os.replace(old, dst)
            except OSError:
                pass
            if _rename_should_copy_files(exc):
                copy_tiles = True
    if copy_tiles:
        try:
            _remove_existing_and_rename(staging, final)
        except OSError as exc:
            _log(
                "Could not replace the existing sidecar folder "
                f"({_os_error_text(exc)}); copying tiles instead",
                xbmc.LOGWARNING,
            )
        else:
            _log(f"Promoted sidecar by replacing the existing folder {final}")
            return True, ""
        try:
            _promote_tiles_into_folder(staging, final)
        except OSError as exc:
            fallback = _os_error_text(exc)
            _log(
                f"Sidecar tile copy failed ({fallback}): {staging} -> {final}",
                xbmc.LOGERROR,
            )
            if last_error:
                return False, f"{last_error}; tile copy failed: {fallback}"
            return False, fallback
        _log(f"Promoted sidecar by replacing tiles in {final}")
        return True, ""
    return False, last_error or "atomic sidecar promotion failed"


def _has_jpg_tiles(directory: str) -> bool:
    return bool(_list_jpg_files(directory))
