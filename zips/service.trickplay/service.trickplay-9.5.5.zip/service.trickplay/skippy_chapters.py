"""Fallback chapter/segment lookup from service.skippy and sidecar files."""

from __future__ import annotations

import json
import os
import re
import xml.etree.ElementTree as ET
from dataclasses import dataclass

import xbmc
import xbmcgui
import xbmcvfs

from vfs_paths import path_variants

SKIPPY_SNAPSHOT_PROP = "skippy.parse_cache_snapshot.v1"
_CHAPTER_XML_SUFFIXES = ("_chapters.xml", "-chapters.xml", ".chapters.xml")
_EDL_ACTION_LABELS = {
    0: "Cut",
    1: "Mute",
    2: "Scene",
    3: "Commercial",
    4: "Skip",
}
_TIME_RE = re.compile(r"^\s*(\d+):(\d{1,2}):(\d{1,2}(?:\.\d+)?)\s*$")


@dataclass(frozen=True)
class ChapterSpan:
    start_seconds: float
    end_seconds: float | None  # None means open-ended until next chapter
    label: str


_sidecar_cache_file: str = ""
_sidecar_cache_spans: tuple[ChapterSpan, ...] = ()


def invalidate_skippy_chapter_cache() -> None:
    global _sidecar_cache_file, _sidecar_cache_spans
    _sidecar_cache_file = ""
    _sidecar_cache_spans = ()


def _parse_hms_seconds(text: str) -> float | None:
    match = _TIME_RE.match(text or "")
    if not match:
        return None
    hours, minutes, seconds = match.groups()
    try:
        return int(hours) * 3600 + int(minutes) * 60 + float(seconds)
    except ValueError:
        return None


def _read_text_file(path: str) -> str:
    if not path:
        return ""
    if "://" not in path and os.path.isfile(path):
        try:
            with open(path, encoding="utf-8", errors="ignore") as handle:
                return handle.read()
        except OSError:
            return ""
    try:
        if not xbmcvfs.exists(path):
            return ""
        with xbmcvfs.File(path, "r") as handle:
            return handle.read() or ""
    except (OSError, RuntimeError):
        return ""


def parse_chapters_xml_text(text: str) -> tuple[ChapterSpan, ...]:
    if not text.strip():
        return ()
    try:
        root = ET.fromstring(text)
    except ET.ParseError:
        return ()
    raw: list[tuple[float, str]] = []
    for atom in root.findall(".//ChapterAtom"):
        start_el = atom.find("ChapterTimeStart")
        if start_el is None or not (start_el.text or "").strip():
            continue
        start_sec = _parse_hms_seconds(start_el.text or "")
        if start_sec is None:
            continue
        title = ""
        disp = atom.find("ChapterDisplay/ChapterString")
        if disp is not None and disp.text:
            title = disp.text.strip()
        if title:
            raw.append((start_sec, title))
    raw.sort(key=lambda item: item[0])
    spans: list[ChapterSpan] = []
    for idx, (start_sec, title) in enumerate(raw):
        end_sec = raw[idx + 1][0] if idx + 1 < len(raw) else None
        spans.append(ChapterSpan(start_sec, end_sec, title))
    return tuple(spans)


def parse_edl_text(text: str) -> tuple[ChapterSpan, ...]:
    spans: list[ChapterSpan] = []
    for line in (text or "").splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        comment = ""
        if "#" in stripped:
            stripped, comment = stripped.split("#", 1)
            stripped = stripped.strip()
            comment = comment.strip()
        parts = stripped.split()
        if len(parts) < 2:
            continue
        try:
            start = float(parts[0])
            end = float(parts[1])
            action = int(parts[2]) if len(parts) > 2 else 4
        except ValueError:
            continue
        if start < 0 or end <= start:
            continue
        label = comment or _EDL_ACTION_LABELS.get(action, "Skip")
        spans.append(ChapterSpan(start, end, label))
    spans.sort(key=lambda s: s.start_seconds)
    return tuple(spans)


def _sidecar_spans_for_media(media_path: str) -> tuple[ChapterSpan, ...]:
    global _sidecar_cache_file, _sidecar_cache_spans
    if not media_path:
        return ()
    if media_path == _sidecar_cache_file:
        return _sidecar_cache_spans

    spans: tuple[ChapterSpan, ...] = ()
    for variant in path_variants(media_path):
        stem, _ext = os.path.splitext(variant)
        if not stem:
            continue
        for suffix in _CHAPTER_XML_SUFFIXES:
            text = _read_text_file(f"{stem}{suffix}")
            if text:
                spans = parse_chapters_xml_text(text)
                if spans:
                    break
        if spans:
            break
        edl_text = _read_text_file(f"{stem}.edl")
        if edl_text:
            spans = parse_edl_text(edl_text)
            if spans:
                break

    _sidecar_cache_file = media_path
    _sidecar_cache_spans = spans
    return spans


def _skippy_snapshot_spans() -> tuple[ChapterSpan, ...]:
    try:
        raw = xbmcgui.Window(10000).getProperty(SKIPPY_SNAPSHOT_PROP)
    except (RuntimeError, AttributeError):
        return ()
    if not raw:
        return ()
    try:
        data = json.loads(raw)
    except (ValueError, TypeError):
        return ()
    if not isinstance(data, dict):
        return ()
    spans: list[ChapterSpan] = []
    for seg in data.get("segments") or []:
        if not isinstance(seg, dict):
            continue
        label = str(seg.get("label") or "").strip()
        if not label:
            continue
        try:
            start = float(seg.get("start", 0.0))
            end = float(seg.get("end", 0.0))
        except (TypeError, ValueError):
            continue
        if end > start >= 0:
            spans.append(ChapterSpan(start, end, label))
    return tuple(spans)


def _match_span(spans: tuple[ChapterSpan, ...], target_second: int) -> str:
    t = float(max(target_second, 0))
    for span in spans:
        if t < span.start_seconds:
            continue
        if span.end_seconds is None or t <= span.end_seconds:
            return span.label
    return ""


def resolve_chapter_or_skippy_label(
    target_second: int,
    playing_file: str = "",
) -> str:
    """Return Kodi chapter name, or fall back to Skippy snapshot / sidecar files."""
    try:
        kodi_chapter = (xbmc.getInfoLabel("Player.ChapterName") or "").strip()
    except (AttributeError, RuntimeError, TypeError):
        kodi_chapter = ""
    if kodi_chapter:
        return kodi_chapter

    snap_match = _match_span(_skippy_snapshot_spans(), target_second)
    if snap_match:
        return snap_match

    if playing_file:
        return _match_span(_sidecar_spans_for_media(playing_file), target_second)
    return ""
