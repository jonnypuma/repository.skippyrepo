"""Zero-skin-edit preview overlay attached directly to VideoFullScreen (no input stealing)."""

from __future__ import annotations

import os
from dataclasses import dataclass

import xbmc
import xbmcaddon
import xbmcgui

from settings_cache import get_cached
from skin_profiles import current_skin_id

ADDON_ID = "service.trickplay"
VIDEO_FULLSCREEN_WINDOW_ID = 12005

DISPLAY_MODE_AUTO = "auto"
DISPLAY_MODE_SKIN = "skin"
DISPLAY_MODE_OVERLAY = "overlay"
_VALID_DISPLAY_MODES = frozenset(
    {DISPLAY_MODE_AUTO, DISPLAY_MODE_SKIN, DISPLAY_MODE_OVERLAY}
)

# Hide the overlay when modal OSD sub-menus are open so it never clutters them.
_BLOCKING_DIALOGS_COND = (
    "Window.IsVisible(OSDVideoSettings) | "
    "Window.IsVisible(OSDAudioSettings) | "
    "Window.IsVisible(OSDSubtitleSettings) | "
    "Window.IsVisible(DialogSelect.xml) | "
    "Window.IsVisible(DialogContextMenu.xml) | "
    "Window.IsVisible(DialogYesNo.xml) | "
    "Window.IsVisible(DialogBusy.xml) | "
    "Window.IsVisible(VideoBookmarks)"
)

# Kodi ControlLabel alignment flags: center-x (2) | center-y (4).
_ALIGN_CENTER = 0x00000002 | 0x00000004
# Kodi ControlImage aspectRatio: 2 = keep, 0 = stretch (for 1x1 border).
_ASPECT_STRETCH = 0
_ASPECT_KEEP = 2
_BORDER_PX_1080P = 2

_snippet_installed_cache: tuple[str, bool] | None = None


@dataclass(frozen=True)
class OverlayRenderState:
    left: int
    top: int
    width: int
    height: int
    label_height: int
    image_path: str
    time_label: str
    show_timestamp: bool
    color_diffuse: str


def _log(message: str, level=xbmc.LOGINFO) -> None:
    xbmc.log(f"[service.trickplay] {message}", level)


def _load_display_mode() -> str:
    try:
        raw = (
            xbmcaddon.Addon(ADDON_ID).getSettingString("preview_display_mode") or ""
        ).strip().lower()
    except (RuntimeError, AttributeError, TypeError):
        return DISPLAY_MODE_AUTO
    return raw if raw in _VALID_DISPLAY_MODES else DISPLAY_MODE_AUTO


def preview_display_mode() -> str:
    return get_cached("preview_display_mode", _load_display_mode)


def invalidate_overlay_mode_cache() -> None:
    global _snippet_installed_cache
    _snippet_installed_cache = None


def _active_skin_has_snippet() -> bool:
    global _snippet_installed_cache
    skin_id = current_skin_id() or ""
    if _snippet_installed_cache is not None and _snippet_installed_cache[0] == skin_id:
        return _snippet_installed_cache[1]
    installed = False
    try:
        from skin_snippet_installer import current_skin_overlay_installed

        installed = bool(current_skin_overlay_installed())
    except Exception:
        installed = False
    _snippet_installed_cache = (skin_id, installed)
    return installed


def should_use_builtin_overlay() -> bool:
    mode = preview_display_mode()
    if mode == DISPLAY_MODE_SKIN:
        return False
    if mode == DISPLAY_MODE_OVERLAY:
        return True
    # Auto: prefer the installed skin snippet (renders inside DialogSeekBar
    # smoothly during long jumps); fall back to zero-skin-edit VideoFullScreen.
    return not _active_skin_has_snippet()


def can_fallback_to_skin_snippet() -> bool:
    return preview_display_mode() == DISPLAY_MODE_AUTO and _active_skin_has_snippet()


def blocking_dialog_visible() -> bool:
    try:
        return bool(xbmc.getCondVisibility(_BLOCKING_DIALOGS_COND))
    except (RuntimeError, AttributeError, TypeError):
        return False


def _fullscreen_video_window() -> xbmcgui.Window | None:
    try:
        return xbmcgui.Window(VIDEO_FULLSCREEN_WINDOW_ID)
    except RuntimeError:
        return None


def _window_coord_scale(window: xbmcgui.Window) -> tuple[float, float]:
    """Return scale factors from 1920x1080 placement coords to the window's coord space."""
    try:
        width = int(window.getWidth() or 0)
        height = int(window.getHeight() or 0)
    except (RuntimeError, TypeError, ValueError, AttributeError):
        width, height = 0, 0
    if width <= 0 or height <= 0:
        return 1280.0 / 1920.0, 720.0 / 1080.0
    return width / 1920.0, height / 1080.0


def _scale_rect(
    state: OverlayRenderState,
    scale_x: float,
    scale_y: float,
) -> tuple[int, int, int, int, int]:
    left = int(round(state.left * scale_x))
    top = int(round(state.top * scale_y))
    width = max(int(round(state.width * scale_x)), 1)
    height = max(int(round(state.height * scale_y)), 1)
    label_h = max(int(round(state.label_height * scale_y)), 1)
    return left, top, width, height, label_h


def _border_color_diffuse(color_diffuse: str) -> str:
    """Scale ~80% white border opacity by the user's preview opacity."""
    try:
        alpha = int(color_diffuse[:2], 16)
    except (ValueError, TypeError, IndexError):
        alpha = 255
    scaled = int(round(alpha * 0.8))
    return f"0x{scaled:02X}FFFFFF"


class BuiltInPreviewOverlay:
    """Attach non-focusable ControlImage + ControlLabel to VideoFullScreen.

    Unlike a WindowXMLDialog, adding controls directly to VideoFullScreen
    (window 12005) never opens a modal/top-level dialog and never intercepts
    remote or keyboard scrubbing input.
    """

    def __init__(self, addon_path: str) -> None:
        self.addon_path = addon_path
        self._border_texture = os.path.join(
            addon_path, "resources", "media", "white.png"
        )
        self._window: xbmcgui.Window | None = None
        self._border: xbmcgui.ControlImage | None = None
        self._image: xbmcgui.ControlImage | None = None
        self._label: xbmcgui.ControlLabel | None = None
        self._visible = False
        self._last_image = ""
        self._last_label = ""
        self._last_rect: tuple[int, int, int, int, int] | None = None
        self._last_show_ts: bool | None = None
        self._last_diffuse = ""

    @property
    def is_visible(self) -> bool:
        return self._visible

    def _ensure_controls(
        self,
        window: xbmcgui.Window,
        rect: tuple[int, int, int, int, int],
        border_px: int,
        state: OverlayRenderState,
    ) -> bool:
        if (
            self._image is not None
            and self._label is not None
            and self._window is not None
        ):
            return True
        left, top, width, height, label_h = rect
        try:
            border = xbmcgui.ControlImage(
                left - border_px,
                top - border_px,
                width + border_px * 2,
                height + border_px * 2,
                self._border_texture,
                aspectRatio=_ASPECT_STRETCH,
                colorDiffuse=_border_color_diffuse(state.color_diffuse),
            )
            image = xbmcgui.ControlImage(
                left,
                top,
                width,
                height,
                state.image_path,
                aspectRatio=_ASPECT_KEEP,
                colorDiffuse=f"0x{state.color_diffuse}",
            )
            label = xbmcgui.ControlLabel(
                left,
                top + height + border_px + 2,
                width,
                label_h,
                state.time_label if state.show_timestamp else "",
                font="font13",
                textColor="0xFFFFFFFF",
                alignment=_ALIGN_CENTER,
            )
            window.addControls([border, image, label])
        except (RuntimeError, TypeError, AttributeError) as exc:
            _log(f"Could not attach built-in overlay controls: {exc}", xbmc.LOGWARNING)
            self._window = None
            self._border = None
            self._image = None
            self._label = None
            return False
        self._window = window
        self._border = border
        self._image = image
        self._label = label
        self._last_rect = rect
        self._last_image = state.image_path
        self._last_label = state.time_label if state.show_timestamp else ""
        self._last_show_ts = state.show_timestamp
        self._last_diffuse = state.color_diffuse
        try:
            label.setVisible(state.show_timestamp)
        except (RuntimeError, TypeError, AttributeError):
            pass
        return True

    def show_or_update(self, state: OverlayRenderState) -> bool:
        if not state.image_path or blocking_dialog_visible():
            self.hide()
            return False
        window = self._window or _fullscreen_video_window()
        if window is None:
            self.hide()
            return False

        scale_x, scale_y = _window_coord_scale(window)
        rect = _scale_rect(state, scale_x, scale_y)
        border_px = max(1, int(round(_BORDER_PX_1080P * min(scale_x, scale_y))))
        created_now = self._image is None or self._label is None
        if not self._ensure_controls(window, rect, border_px, state):
            return False

        assert self._image is not None and self._label is not None
        if not created_now:
            left, top, width, height, label_h = rect
            try:
                if rect != self._last_rect:
                    if self._border is not None:
                        self._border.setPosition(left - border_px, top - border_px)
                        self._border.setWidth(width + border_px * 2)
                        self._border.setHeight(height + border_px * 2)
                    self._image.setPosition(left, top)
                    self._image.setWidth(width)
                    self._image.setHeight(height)
                    self._label.setPosition(left, top + height + border_px + 2)
                    self._label.setWidth(width)
                    self._label.setHeight(label_h)
                    self._last_rect = rect

                if state.image_path != self._last_image:
                    # Live paths are monotonic & unique, so default texture loading
                    # won't collide with earlier frames and avoids synchronous stalls.
                    self._image.setImage(state.image_path)
                    self._last_image = state.image_path

                if state.color_diffuse != self._last_diffuse:
                    if self._border is not None:
                        self._border.setColorDiffuse(
                            _border_color_diffuse(state.color_diffuse)
                        )
                    self._image.setColorDiffuse(f"0x{state.color_diffuse}")
                    self._last_diffuse = state.color_diffuse

                if state.show_timestamp != self._last_show_ts:
                    self._label.setVisible(state.show_timestamp)
                    self._last_show_ts = state.show_timestamp

                next_label = state.time_label if state.show_timestamp else ""
                if next_label != self._last_label:
                    self._label.setLabel(next_label)
                    self._last_label = next_label
            except (RuntimeError, TypeError, AttributeError):
                # VideoFullScreen may have been recreated; drop and re-attach next tick.
                self.hide()
                return False

        try:
            if self._border is not None:
                self._border.setVisible(True)
            self._image.setVisible(True)
            self._label.setVisible(state.show_timestamp)
        except (RuntimeError, TypeError, AttributeError):
            self.hide()
            return False

        self._visible = True
        return True

    def hide(self) -> None:
        window = self._window
        controls = [c for c in (self._border, self._image, self._label) if c is not None]
        self._window = None
        self._border = None
        self._image = None
        self._label = None
        self._visible = False
        self._last_image = ""
        self._last_label = ""
        self._last_rect = None
        self._last_show_ts = None
        self._last_diffuse = ""
        for ctrl in controls:
            try:
                ctrl.setVisible(False)
            except (RuntimeError, TypeError, AttributeError):
                pass
        if window is not None and controls:
            try:
                window.removeControls(controls)
            except (RuntimeError, TypeError, AttributeError):
                pass
