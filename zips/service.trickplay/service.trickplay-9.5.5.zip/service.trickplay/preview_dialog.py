"""Trickplay preview: crop thumbs and publish DialogSeekBar window properties."""

from __future__ import annotations

import threading
import time

from dataclasses import dataclass

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from osd_layout import preview_layout_mode, preview_placement
from prefetch import nearest_ready_thumb_path
from preview_overlay import (
    BuiltInPreviewOverlay,
    OverlayRenderState,
    invalidate_overlay_mode_cache,
    should_use_builtin_overlay,
)
from settings_cache import get_cached
from thumb_cropper import (
    get_cropped_thumb_path,
    get_ready_thumb_path,
    record_preview_latency,
    set_foreground_crop_pending,
)
from trickplay_resolver import TrickplayLookup, TrickplayResolution

HOME_WINDOW = xbmcgui.Window(10000)
SEEKBAR_WINDOW_ID = 10115
ADDON_ID = "service.trickplay"


def _addon() -> xbmcaddon.Addon:
    # Fresh instance each call — module-level Addon() returns stale settings in services.
    return xbmcaddon.Addon(ADDON_ID)

PROP_PREFIX = "Trickplay."
PROP_PREVIEW_IMAGE = "Trickplay.PreviewImage"
PROP_PREVIEW_VISIBLE = "Trickplay.PreviewVisible"
PROP_PREVIEW_TIME = "Trickplay.PreviewTime"
PROP_PREVIEW_DELTA = "Trickplay.PreviewDelta"
PROP_PREVIEW_CHAPTER = "Trickplay.PreviewChapter"
PROP_PREVIEW_SLOT = "Trickplay.PreviewSlot"
PROP_PREVIEW_LEFT = "Trickplay.PreviewLeft"
PROP_PREVIEW_TOP = "Trickplay.PreviewTop"
PROP_PREVIEW_LEFT_WIDE = "Trickplay.PreviewLeftWide"
PROP_PREVIEW_WIDTH = "Trickplay.PreviewWidth"
PROP_PREVIEW_HEIGHT = "Trickplay.PreviewHeight"
PROP_PREVIEW_LABEL_H = "Trickplay.PreviewLabelHeight"
PROP_PREVIEW_TOTAL_H = "Trickplay.PreviewTotalHeight"
PROP_DURATION = "Trickplay.Duration"
PROP_THUMB_W = "Trickplay.ThumbWidth"
PROP_THUMB_H = "Trickplay.ThumbHeight"
PROP_SHOW_TIMESTAMP = "Trickplay.ShowTimestamp"
PROP_PREVIEW_COLOR_DIFFUSE = "Trickplay.PreviewColorDiffuse"
PROP_PREVIEW_LAYOUT = "Trickplay.PreviewLayout"

DISPLAY_PROPERTIES = (
    PROP_SHOW_TIMESTAMP,
    PROP_PREVIEW_COLOR_DIFFUSE,
)

PREVIEW_PROPERTIES = (
    PROP_PREVIEW_IMAGE,
    PROP_PREVIEW_VISIBLE,
    PROP_PREVIEW_TIME,
    PROP_PREVIEW_DELTA,
    PROP_PREVIEW_CHAPTER,
    PROP_PREVIEW_SLOT,
    PROP_PREVIEW_LEFT,
    PROP_PREVIEW_TOP,
    PROP_PREVIEW_LEFT_WIDE,
    PROP_PREVIEW_WIDTH,
    PROP_PREVIEW_HEIGHT,
    PROP_PREVIEW_LABEL_H,
    PROP_PREVIEW_TOTAL_H,
    PROP_DURATION,
    PROP_THUMB_W,
    PROP_THUMB_H,
    PROP_PREVIEW_LAYOUT,
)

_RESYNC_PROPERTIES = PREVIEW_PROPERTIES + DISPLAY_PROPERTIES
_seekbar_visible_last = False
_last_resync_snapshot: tuple[tuple[str, str], ...] | None = None

SCRUB_COALESCE_SEC = 0.12
SCRUB_GAP_SEC = 0.25
SCRUB_JUMP_THUMBS = 3
SCRUB_PROGRESS_INTERVAL_SEC = 0.25

DEFAULT_ASPECT_RATIO = 16 / 9


@dataclass(frozen=True)
class DisplaySyncSettings:
    show_timestamp: bool
    color_diffuse: str
    show_seek_delta: bool = True
    show_chapter_name: bool = True


def _debug_logging() -> bool:
    try:
        from generator_settings import read_runtime_settings

        return read_runtime_settings().debug_logging
    except ImportError:  # pragma: no cover
        return False


def display_aspect_ratio(
    lookup: TrickplayLookup,
    player: xbmc.Player | None = None,
) -> float:
    if lookup.thumb_width > 0 and lookup.thumb_height > 0:
        return lookup.thumb_width / float(lookup.thumb_height)
    if player is not None:
        try:
            tag = player.getVideoInfoTag()
            width = int(tag.getWidth() or 0)
            height = int(tag.getHeight() or 0)
            if width > 0 and height > 0:
                return width / float(height)
        except (AttributeError, RuntimeError, TypeError, ValueError):
            pass
    return DEFAULT_ASPECT_RATIO


def lookup_cache_key(lookup: TrickplayLookup) -> tuple[str, int, int, int, int]:
    return (
        lookup.tile_path,
        lookup.col,
        lookup.row,
        lookup.thumb_width,
        lookup.thumb_height,
    )


_CHAPTER_LABEL_MAX_CHARS = 28


def format_preview_time(seconds: int) -> str:
    seconds = max(int(seconds), 0)
    hours = seconds // 3600
    minutes = (seconds % 3600) // 60
    secs = seconds % 60
    if hours:
        return f"{hours}:{minutes:02d}:{secs:02d}"
    return f"{minutes}:{secs:02d}"


def format_seek_delta(target_seconds: int, play_seconds: int | None) -> str:
    if play_seconds is None:
        return ""
    delta = int(target_seconds) - int(play_seconds)
    if abs(delta) < 1:
        return ""
    sign = "+" if delta > 0 else "-"
    return f"{sign}{format_preview_time(abs(delta))}"


def current_chapter_name(target_second: int = 0, playing_file: str = "") -> str:
    try:
        from skippy_chapters import resolve_chapter_or_skippy_label

        return resolve_chapter_or_skippy_label(target_second, playing_file)
    except Exception:
        try:
            return (xbmc.getInfoLabel("Player.ChapterName") or "").strip()
        except (AttributeError, RuntimeError, TypeError):
            return ""


def _truncate_chapter_label(name: str, max_chars: int = _CHAPTER_LABEL_MAX_CHARS) -> str:
    clean = " ".join((name or "").split())
    if len(clean) <= max_chars:
        return clean
    return clean[: max_chars - 1].rstrip() + "…"


def format_preview_label(
    target_seconds: int,
    *,
    play_seconds: int | None = None,
    show_delta: bool = True,
    chapter_name: str = "",
    show_chapter: bool = True,
) -> str:
    label = format_preview_time(target_seconds)
    if show_delta:
        delta = format_seek_delta(target_seconds, play_seconds)
        if delta:
            label = f"{label} ({delta})"
    if show_chapter and chapter_name:
        short_chapter = _truncate_chapter_label(chapter_name)
        if short_chapter:
            label = f"{label} · {short_chapter}"
    return label


def _thumb_texture_path(thumb_path: str) -> str:
    if thumb_path.startswith(("special://", "vfs://", "zip://")):
        return thumb_path.replace("\\", "/")
    local = xbmcvfs.translatePath(thumb_path)
    if local:
        local = local.replace("\\", "/")
        profile = xbmcvfs.translatePath("special://profile/").replace("\\", "/")
        if profile and local.lower().startswith(profile.lower()):
            rel = local[len(profile) :].lstrip("/")
            return f"special://profile/{rel}"
        if xbmcvfs.exists(local):
            return local
    return thumb_path.replace("\\", "/")


def _seekbar_window_unconditional() -> xbmcgui.Window | None:
    try:
        return xbmcgui.Window(SEEKBAR_WINDOW_ID)
    except RuntimeError:
        return None


def _set_properties(updates: dict[str, str | None]) -> None:
    """Apply a batch of property updates with a single DialogSeekBar lookup."""
    if not updates:
        return
    seekbar = _seekbar_window_unconditional()
    for name, value in updates.items():
        if value:
            HOME_WINDOW.setProperty(name, value)
        else:
            HOME_WINDOW.clearProperty(name)
        if seekbar is not None:
            try:
                if value:
                    seekbar.setProperty(name, value)
                else:
                    seekbar.clearProperty(name)
            except RuntimeError:
                seekbar = None


def _set_property(name: str, value: str) -> None:
    _set_properties({name: value})


def _setting_bool(setting_id: str, default: bool) -> bool:
    addon = _addon()
    try:
        return addon.getSettingBool(setting_id)
    except (RuntimeError, TypeError, ValueError):
        raw = addon.getSettingString(setting_id)
        if not raw:
            return default
        return raw.strip().lower() in ("true", "1", "yes", "on")


def _show_timestamp_setting() -> bool:
    return _setting_bool("show_timestamp", True)


def _setting_int(setting_id: str, default: int) -> int:
    addon = _addon()
    try:
        return int(addon.getSettingInt(setting_id))
    except (TypeError, ValueError):
        raw = addon.getSettingString(setting_id)
        try:
            return int(raw)
        except (TypeError, ValueError):
            return default


def preview_opacity_percent() -> int:
    return max(0, min(_setting_int("preview_opacity", 100), 100))


def preview_color_diffuse(opacity_percent: int | None = None) -> str:
    opacity = preview_opacity_percent() if opacity_percent is None else opacity_percent
    opacity = max(0, min(int(opacity), 100))
    alpha = int(round(opacity * 255 / 100))
    return f"{alpha:02X}FFFFFF"


def _load_display_sync_settings() -> DisplaySyncSettings:
    show_timestamp = _show_timestamp_setting()
    return DisplaySyncSettings(
        show_timestamp=show_timestamp,
        color_diffuse=preview_color_diffuse(
            opacity_percent=_setting_int("preview_opacity", 100)
        ),
        show_seek_delta=_setting_bool("show_seek_delta", True),
        show_chapter_name=_setting_bool("show_chapter_name", True),
    )


def _display_sync_settings() -> DisplaySyncSettings:
    return get_cached("display_sync", _load_display_sync_settings)


def show_timestamp_enabled() -> bool:
    return _display_sync_settings().show_timestamp


def sync_display_settings() -> None:
    display = _display_sync_settings()
    # Kodi boolean props: "true" or clear (empty). Avoid "false" — skins key off IsEqual/empty.
    _set_properties(
        {
            PROP_SHOW_TIMESTAMP: "true" if display.show_timestamp else None,
            PROP_PREVIEW_COLOR_DIFFUSE: display.color_diffuse,
        }
    )


def apply_display_settings() -> None:
    """Re-read display settings after the user changes add-on options."""
    from settings_cache import invalidate_settings_cache

    invalidate_settings_cache()
    sync_display_settings()
    if not show_timestamp_enabled():
        _set_properties(
            {
                PROP_PREVIEW_TIME: None,
                PROP_PREVIEW_DELTA: None,
                PROP_PREVIEW_CHAPTER: None,
            }
        )


def _clear_property(name: str) -> None:
    _set_properties({name: None})


def _clear_preview_properties() -> None:
    _reset_resync_state()
    _set_properties({prop: None for prop in _RESYNC_PROPERTIES})


def sync_trickplay_property(name: str, value: str) -> None:
    _set_property(name, value)


def clear_trickplay_property(name: str) -> None:
    _clear_property(name)


def _dialog_seekbar_visible() -> bool:
    return xbmc.getCondVisibility(
        "Window.IsVisible(seekbar) | Window.IsActive(seekbar) | "
        "Window.IsVisible(DialogSeekBar.xml)"
    )


def _collect_resync_snapshot() -> tuple[tuple[str, str], ...]:
    return tuple(
        (prop, HOME_WINDOW.getProperty(prop) or "") for prop in _RESYNC_PROPERTIES
    )


def _seekbar_properties_match(
    seekbar: xbmcgui.Window, snapshot: tuple[tuple[str, str], ...]
) -> bool:
    for prop, value in snapshot:
        try:
            if (seekbar.getProperty(prop) or "") != value:
                return False
        except RuntimeError:
            return False
    return True


def _reset_resync_state() -> None:
    global _seekbar_visible_last, _last_resync_snapshot
    _seekbar_visible_last = False
    _last_resync_snapshot = None


def resync_preview_to_seekbar(*, force: bool = False) -> None:
    """Copy preview properties to DialogSeekBar when it opens after publish."""
    global _seekbar_visible_last, _last_resync_snapshot

    if not _dialog_seekbar_visible():
        _seekbar_visible_last = False
        return

    seekbar = _seekbar_window_unconditional()
    if seekbar is None:
        _seekbar_visible_last = False
        _last_resync_snapshot = None
        return

    snapshot = _collect_resync_snapshot()
    visibility_transition = not _seekbar_visible_last

    if not force and not visibility_transition:
        if _seekbar_properties_match(seekbar, snapshot):
            _last_resync_snapshot = snapshot
            return

    for prop, value in snapshot:
        try:
            if value:
                seekbar.setProperty(prop, value)
            else:
                seekbar.clearProperty(prop)
        except RuntimeError:
            pass

    _last_resync_snapshot = snapshot
    _seekbar_visible_last = True


class PreviewDialogController:
    """Publish DialogSeekBar skin properties for trickplay preview (atlas or crop)."""

    def __init__(self, addon_path: str) -> None:
        self.addon_path = addon_path
        self._crop_lock = threading.Lock()
        self._crop_target_id = 0
        self._crop_thread: threading.Thread | None = None
        self._pending_lookup: TrickplayLookup | None = None
        self._pending_duration = 0
        self._pending_player: xbmc.Player | None = None
        self._pending_play_seconds: int | None = None
        self._pending_playing_file = ""
        self._pending_requested_at = 0.0
        self._crop_failed = False
        self._crop_ready: (
            tuple[TrickplayLookup, int, str, xbmc.Player | None, float] | None
        ) = None
        self._requested_key: tuple[str, int, int, int, int] | None = None
        self._shown_thumb_index = -1
        self._last_thumb_path: str | None = None
        self._last_lookup: TrickplayLookup | None = None
        self._last_duration = 0
        self._last_player: xbmc.Player | None = None
        self._last_play_seconds: int | None = None
        self._last_playing_file = ""
        self._last_placement_key: tuple[int, int, float, bool, str, tuple[int, int, int]] | None = None
        self._last_placement = None
        self._last_scrub_at = 0.0
        self._last_scrub_thumb_index = -1
        self._last_image_publish_at = 0.0
        self._scrub_burst_until = 0.0
        self._fast_scrub_active = False
        self._overlay = BuiltInPreviewOverlay(addon_path)
        self._overlay_state: OverlayRenderState | None = None
        self._overlay_dirty = False
        self._overlay_visible_requested = False

    @property
    def fast_scrub_active(self) -> bool:
        return self._fast_scrub_active

    def detach_overlay(self) -> None:
        self.hide_preview()

    def set_overlay_visible(self, visible: bool) -> bool:
        with self._crop_lock:
            self._overlay_visible_requested = visible
            state = self._overlay_state
            self._overlay_dirty = False
        if not visible or not should_use_builtin_overlay():
            self._overlay.hide()
            return False
        if state is None:
            return True
        return self._overlay.show_or_update(state)

    def _sync_overlay(self) -> None:
        with self._crop_lock:
            visible = self._overlay_visible_requested
            state = self._overlay_state
            self._overlay_dirty = False
        if not visible or not should_use_builtin_overlay():
            self._overlay.hide()
            return
        if state is not None:
            self._overlay.show_or_update(state)

    def on_settings_changed(self) -> None:
        """Invalidate cached placement so the next publish picks up display toggles."""
        apply_display_settings()
        invalidate_overlay_mode_cache()
        self._last_placement_key = None
        self._last_placement = None
        if not should_use_builtin_overlay():
            self._overlay.hide()

    def hide_preview(self) -> None:
        with self._crop_lock:
            self._crop_target_id += 1
            self._pending_lookup = None
            self._pending_duration = 0
            self._pending_player = None
            self._pending_play_seconds = None
            self._pending_requested_at = 0.0
            self._crop_ready = None
            self._overlay_state = None
            self._overlay_dirty = False
            self._overlay_visible_requested = False
        self._crop_failed = False
        self._requested_key = None
        self._shown_thumb_index = -1
        self._last_thumb_path = None
        self._last_lookup = None
        self._last_duration = 0
        self._last_player = None
        self._last_play_seconds = None
        self._last_placement_key = None
        self._last_placement = None
        self._last_scrub_at = 0.0
        self._last_scrub_thumb_index = -1
        self._last_image_publish_at = 0.0
        self._scrub_burst_until = 0.0
        self._fast_scrub_active = False
        set_foreground_crop_pending(False)
        self._overlay.hide()
        _clear_preview_properties()

    def _scrub_churn_active(self, lookup: TrickplayLookup, *, seeking: bool) -> bool:
        """True only during rapid successive scrub updates (not a single big jump)."""
        if not seeking:
            self._scrub_burst_until = 0.0
            return False
        now = time.monotonic()
        fast = False
        if now < self._scrub_burst_until:
            fast = True
        if (
            self._last_scrub_at > 0.0
            and now - self._last_scrub_at < SCRUB_COALESCE_SEC
        ):
            fast = True
        # Large index jumps only count as churn when updates are already arriving
        # quickly. A single leap still publishes the last/nearest thumb immediately
        # and queues the exact crop; this detector only affects nearest-ready
        # selection and prefetch yield.
        recent = (
            self._last_scrub_at > 0.0
            and now - self._last_scrub_at < SCRUB_GAP_SEC
        )
        if recent and self._last_scrub_thumb_index >= 0:
            jump = abs(lookup.thumb_index - self._last_scrub_thumb_index)
            if jump >= SCRUB_JUMP_THUMBS:
                fast = True
        if fast:
            self._scrub_burst_until = now + SCRUB_COALESCE_SEC
        return fast

    def _placement_key(
        self,
        lookup: TrickplayLookup,
        duration_seconds: int,
        player: xbmc.Player | None,
        layout: str,
    ) -> tuple[int, int, float, bool, str, tuple[int, int, int]]:
        from skin_profiles import active_profile

        return (
            lookup.target_second,
            max(duration_seconds, 0),
            display_aspect_ratio(lookup, player),
            show_timestamp_enabled(),
            layout,
            active_profile().active_seekbar(),
        )

    def _placement_properties(
        self,
        lookup: TrickplayLookup,
        duration_seconds: int,
        player: xbmc.Player | None,
        layout: str | None = None,
    ) -> dict[str, str]:
        if layout is None:
            layout = preview_layout_mode()
        aspect_ratio = display_aspect_ratio(lookup, player)
        placement = preview_placement(
            lookup.target_second,
            duration_seconds,
            aspect_ratio,
            show_timestamp=show_timestamp_enabled(),
            layout=layout,
        )
        self._last_placement = placement
        total_h = placement.preview_h + placement.label_h + 4
        if _debug_logging():
            xbmc.log(
                f"[service.trickplay] Preview slot {placement.slot} "
                f"({placement.left},{placement.top}) "
                f"{placement.preview_w}x{placement.preview_h} @ {lookup.target_second}s "
                f"(duration={duration_seconds}s)",
                xbmc.LOGINFO,
            )
        return {
            PROP_PREVIEW_LAYOUT: layout,
            PROP_PREVIEW_SLOT: str(placement.slot),
            PROP_PREVIEW_LEFT: str(placement.left),
            PROP_PREVIEW_TOP: str(placement.top),
            PROP_PREVIEW_LEFT_WIDE: str(placement.left_wide),
            PROP_PREVIEW_WIDTH: str(placement.preview_w),
            PROP_PREVIEW_HEIGHT: str(placement.preview_h),
            PROP_PREVIEW_LABEL_H: str(placement.label_h),
            PROP_PREVIEW_TOTAL_H: str(total_h),
        }

    def _publish_placement(
        self,
        lookup: TrickplayLookup,
        duration_seconds: int,
        player: xbmc.Player | None,
        layout: str | None = None,
    ) -> None:
        _set_properties(
            self._placement_properties(lookup, duration_seconds, player, layout)
        )

    def _publish_preview_state(
        self,
        lookup: TrickplayLookup,
        duration_seconds: int,
        image_path: str | None,
        player: xbmc.Player | None = None,
        *,
        keep_existing_image: bool = False,
        play_seconds: int | None = None,
    ) -> None:
        display = _display_sync_settings()
        updates: dict[str, str | None] = {
            PROP_SHOW_TIMESTAMP: "true" if display.show_timestamp else None,
            PROP_PREVIEW_COLOR_DIFFUSE: display.color_diffuse,
            PROP_DURATION: str(max(duration_seconds, 0)),
            PROP_THUMB_W: str(lookup.thumb_width),
            PROP_THUMB_H: str(lookup.thumb_height),
        }
        delta_text = (
            format_seek_delta(lookup.target_second, play_seconds)
            if display.show_seek_delta
            else ""
        )
        chapter_text = (
            current_chapter_name(lookup.target_second, self._last_playing_file)
            if display.show_chapter_name
            else ""
        )
        updates[PROP_PREVIEW_DELTA] = delta_text or None
        updates[PROP_PREVIEW_CHAPTER] = chapter_text or None
        if display.show_timestamp:
            updates[PROP_PREVIEW_TIME] = format_preview_label(
                lookup.target_second,
                play_seconds=play_seconds,
                show_delta=display.show_seek_delta,
                chapter_name=chapter_text,
                show_chapter=display.show_chapter_name,
            )
        else:
            updates[PROP_PREVIEW_TIME] = None

        layout = preview_layout_mode()
        self._last_lookup = lookup
        self._last_duration = duration_seconds
        self._last_player = player
        self._last_play_seconds = play_seconds
        placement_key = self._placement_key(lookup, duration_seconds, player, layout)
        if placement_key != self._last_placement_key:
            updates.update(
                self._placement_properties(lookup, duration_seconds, player, layout)
            )
            self._last_placement_key = placement_key

        texture = ""
        if image_path:
            texture = _thumb_texture_path(image_path)
            updates[PROP_PREVIEW_IMAGE] = texture
            self._last_image_publish_at = time.monotonic()
            if _debug_logging():
                xbmc.log(
                    f"[service.trickplay] Preview texture: {texture}",
                    xbmc.LOGINFO,
                )
        elif not keep_existing_image:
            updates[PROP_PREVIEW_IMAGE] = None

        _set_properties(updates)
        if not _seekbar_visible_last and _dialog_seekbar_visible():
            resync_preview_to_seekbar(force=True)

        placement = self._last_placement
        if placement is not None:
            effective_image = texture or (
                _thumb_texture_path(self._last_thumb_path)
                if keep_existing_image and self._last_thumb_path
                else ""
            )
            use_wide = False
            try:
                use_wide = bool(xbmc.getCondVisibility("Skin.HasSetting(SmallOSDVideo)"))
            except (RuntimeError, TypeError, AttributeError):
                use_wide = False
            overlay_state = OverlayRenderState(
                left=placement.left_wide if use_wide else placement.left,
                top=placement.top,
                width=placement.preview_w,
                height=placement.preview_h,
                label_height=placement.label_h,
                image_path=effective_image,
                time_label=updates[PROP_PREVIEW_TIME] or "",
                show_timestamp=display.show_timestamp,
                color_diffuse=display.color_diffuse,
            )
            with self._crop_lock:
                self._overlay_state = overlay_state
                self._overlay_dirty = True

    def refresh_placement_if_needed(self) -> bool:
        """Re-publish placement & overlay position if OSD mode or geometry changed."""
        lookup = self._last_lookup
        if lookup is None:
            return False
        layout = preview_layout_mode()
        placement_key = self._placement_key(
            lookup, self._last_duration, self._last_player, layout
        )
        if placement_key == self._last_placement_key:
            return False
        self._publish_preview_state(
            lookup,
            self._last_duration,
            self._last_thumb_path,
            self._last_player,
            keep_existing_image=True,
            play_seconds=self._last_play_seconds,
        )
        self._sync_overlay()
        return True

    def show_preview(
        self,
        lookup: TrickplayLookup,
        duration_seconds: int,
        player: xbmc.Player | None = None,
        *,
        eager: bool = False,
        resolution: TrickplayResolution | None = None,
        interval_ms: int = 10000,
        play_seconds: int | None = None,
        playing_file: str = "",
    ) -> None:
        if playing_file:
            self._last_playing_file = playing_file
        fast_scrub = self._scrub_churn_active(lookup, seeking=eager)
        self._fast_scrub_active = fast_scrub
        self._last_scrub_at = time.monotonic()
        self._last_scrub_thumb_index = lookup.thumb_index

        cache_key = lookup_cache_key(lookup)
        self._requested_key = cache_key
        cached = get_ready_thumb_path(
            lookup.tile_path,
            lookup.col,
            lookup.row,
            lookup.thumb_width,
            lookup.thumb_height,
        )

        if cached:
            with self._crop_lock:
                self._crop_target_id += 1
                self._pending_lookup = None
                self._crop_ready = None
            set_foreground_crop_pending(False)
            self._shown_thumb_index = lookup.thumb_index
            self._last_thumb_path = cached
            self._publish_preview_state(
                lookup,
                duration_seconds,
                cached,
                player,
                keep_existing_image=True,
                play_seconds=play_seconds,
            )
            self._sync_overlay()
            return

        ready = None
        if resolution is not None:
            ready = nearest_ready_thumb_path(resolution, lookup, interval_ms)
        display = ready or self._last_thumb_path
        if display:
            self._last_thumb_path = display

        # Overlay follows the cursor immediately. Exact crops never run on the
        # service thread — even a single long jump queues the worker.
        self._publish_preview_state(
            lookup,
            duration_seconds,
            display,
            player,
            keep_existing_image=True,
            play_seconds=play_seconds,
        )
        self._sync_overlay()
        self._queue_exact_crop(
            lookup,
            duration_seconds,
            player,
            cache_key,
            play_seconds=play_seconds,
        )

    def _queue_exact_crop(
        self,
        lookup: TrickplayLookup,
        duration_seconds: int,
        player: xbmc.Player | None,
        cache_key: tuple[str, int, int, int, int],
        *,
        play_seconds: int | None = None,
    ) -> None:
        with self._crop_lock:
            pending_key = (
                lookup_cache_key(self._pending_lookup)
                if self._pending_lookup is not None
                else None
            )
            if pending_key != cache_key:
                self._crop_target_id += 1
            self._pending_lookup = lookup
            self._pending_duration = duration_seconds
            self._pending_player = player
            self._pending_play_seconds = play_seconds
            self._pending_requested_at = time.perf_counter()
            self._crop_failed = False
        set_foreground_crop_pending(True)
        self._ensure_crop_worker(_debug_logging())

    def _ensure_crop_worker(self, debug: bool) -> None:
        with self._crop_lock:
            if self._crop_thread is not None and self._crop_thread.is_alive():
                return
            self._crop_thread = threading.Thread(
                target=self._crop_worker_loop,
                args=(debug,),
                daemon=True,
                name="trickplay-crop",
            )
            self._crop_thread.start()

    def _crop_worker_loop(self, debug: bool) -> None:
        while True:
            with self._crop_lock:
                lookup = self._pending_lookup
                duration = self._pending_duration
                player = self._pending_player
                play_seconds = self._pending_play_seconds
                requested_at = self._pending_requested_at
                target_id = self._crop_target_id

            if lookup is None:
                set_foreground_crop_pending(False)
                return

            set_foreground_crop_pending(True)
            thumb_path = get_cropped_thumb_path(
                lookup.tile_path,
                lookup.col,
                lookup.row,
                lookup.thumb_width,
                lookup.thumb_height,
                debug=debug,
                should_abort=lambda: (
                    self._crop_target_id != target_id
                    and (time.monotonic() - self._last_image_publish_at)
                    < SCRUB_PROGRESS_INTERVAL_SEC
                ),
            )

            stale_target = False
            with self._crop_lock:
                if self._crop_target_id != target_id:
                    stale_target = True
                pending = self._pending_lookup
                if pending is None:
                    return
                if not thumb_path:
                    if stale_target:
                        continue
                    self._crop_failed = True
                    self._pending_lookup = None
                    set_foreground_crop_pending(False)
                    return
                if stale_target or lookup_cache_key(pending) != lookup_cache_key(lookup):
                    # Publish intermediate progress during long continuous scrubs so
                    # the preview never freezes until scrubbing stops.
                    if (
                        time.monotonic() - self._last_image_publish_at
                        >= SCRUB_PROGRESS_INTERVAL_SEC
                    ):
                        self._last_thumb_path = thumb_path
                        self._shown_thumb_index = lookup.thumb_index
                        self._publish_preview_state(
                            lookup,
                            duration,
                            thumb_path,
                            player,
                            keep_existing_image=True,
                            play_seconds=play_seconds,
                        )
                    continue
                self._last_thumb_path = thumb_path
                self._shown_thumb_index = lookup.thumb_index
                self._pending_lookup = None
                set_foreground_crop_pending(False)
            record_preview_latency(requested_at)
            self._publish_preview_state(
                lookup,
                duration,
                thumb_path,
                player,
                keep_existing_image=True,
                play_seconds=play_seconds,
            )
            return

    def poll(self) -> None:
        ready = None
        failed = False
        with self._crop_lock:
            ready = self._crop_ready
            self._crop_ready = None
            overlay_dirty = self._overlay_dirty
            if self._crop_failed:
                failed = True
                self._crop_failed = False
        if ready is not None:
            if len(ready) == 5:
                lookup, duration, thumb_path, player, requested_at = ready
            else:  # Backward-compatible test/runtime tuple from older workers.
                lookup, duration, thumb_path, player = ready
                requested_at = 0.0
            if (
                self._requested_key is None
                or lookup_cache_key(lookup) == self._requested_key
            ):
                self._last_thumb_path = thumb_path
                self._shown_thumb_index = lookup.thumb_index
                record_preview_latency(requested_at)
                self._publish_preview_state(
                    lookup,
                    duration,
                    thumb_path,
                    player,
                    keep_existing_image=True,
                )
                overlay_dirty = True
        if overlay_dirty or self._overlay.is_visible:
            self._sync_overlay()
        if failed and (
            self._crop_thread is None or not self._crop_thread.is_alive()
        ):
            xbmc.log(
                "[service.trickplay] Could not crop preview thumb; "
                "use Install preview tools in add-on settings",
                xbmc.LOGWARNING,
            )
