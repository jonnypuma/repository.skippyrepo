"""Install Pillow and generator ffmpeg/dovi_tool from settings."""

from __future__ import annotations

import xbmcgui

from script_common import _ADDON, _log
from generator_settings import GeneratorSettings, read_generator_settings
from hdr_ffmpeg_installer import (
    generator_install_tools_needed,
    install_tools_needed,
    prompt_and_install_generator_tools,
)
from pillow_installer import prompt_and_install_pillow, should_offer_pillow_download


def _install_tools_strings(settings: GeneratorSettings) -> dict[str, str]:
    return {
        "title": _ADDON.getLocalizedString(32131),
        "pillow_prompt_yes": _ADDON.getLocalizedString(32149),
        "pillow_progress_title": _ADDON.getLocalizedString(32150),
        "pillow_unsupported_message": _ADDON.getLocalizedString(32151),
        "pillow_failed_message": _ADDON.getLocalizedString(32152),
        "pillow_success_message": _ADDON.getLocalizedString(32153),
        "base_ffmpeg_prompt_yes": _ADDON.getLocalizedString(32125),
        "hdr_ffmpeg_prompt_yes": _ADDON.getLocalizedString(32099),
        "dovi_prompt_yes": _ADDON.getLocalizedString(32106),
        "prompt_no": _ADDON.getLocalizedString(32100),
        "download_yes": _ADDON.getLocalizedString(32105),
        "base_ffmpeg_progress_title": _ADDON.getLocalizedString(32126),
        "hdr_ffmpeg_progress_title": _ADDON.getLocalizedString(32101),
        "dovi_progress_title": _ADDON.getLocalizedString(32107),
        "ffmpeg_unsupported_message": _ADDON.getLocalizedString(32102),
        "dovi_unsupported_message": _ADDON.getLocalizedString(32108),
        "base_ffmpeg_failed_message": _ADDON.getLocalizedString(32127),
        "hdr_ffmpeg_failed_message": _ADDON.getLocalizedString(32103),
        "dovi_failed_message": _ADDON.getLocalizedString(32109),
        "base_ffmpeg_success_message": _ADDON.getLocalizedString(32128),
        "hdr_ffmpeg_success_message": _ADDON.getLocalizedString(32104),
        "dovi_success_message": _ADDON.getLocalizedString(32110),
        "vulkan_prompt_yes": _ADDON.getLocalizedString(32118),
        "vulkan_success_message": _ADDON.getLocalizedString(32119),
        "jellyfin_upgrade_prompt_yes": _ADDON.getLocalizedString(32225),
        "jellyfin_upgrade_success_message": _ADDON.getLocalizedString(32226),
        "already_installed": _ADDON.getLocalizedString(32129),
    }

def run_install_pillow_dialog() -> None:
    _log("run_install_pillow_dialog started")
    strings = _install_tools_strings(read_generator_settings())
    if not should_offer_pillow_download():
        xbmcgui.Dialog().notification(
            strings["title"],
            _ADDON.getLocalizedString(32185),
            xbmcgui.NOTIFICATION_INFO,
            4000,
        )
        return
    prompt_and_install_pillow(
        title=strings["title"],
        prompt_yes=strings["pillow_prompt_yes"],
        prompt_no=strings["prompt_no"],
        download_yes=strings["download_yes"],
        progress_title=strings["pillow_progress_title"],
        unsupported_message=strings["pillow_unsupported_message"],
        failed_message=strings["pillow_failed_message"],
        success_message=strings["pillow_success_message"],
    )
    try:
        from pillow_installer import invalidate_pillow_cache

        invalidate_pillow_cache()
    except ImportError:
        pass

def run_install_generator_tools_dialog() -> None:
    _log("run_install_generator_tools_dialog started")
    settings = read_generator_settings()
    strings = _install_tools_strings(settings)
    if not generator_install_tools_needed(
        hdr_tone_map_enabled=settings.hdr_tone_map,
        hdr_dovi_tool_fallback_enabled=settings.hdr_dovi_tool_fallback,
        custom_ffmpeg_path=settings.ffmpeg_path,
    ):
        xbmcgui.Dialog().notification(
            strings["title"],
            _ADDON.getLocalizedString(32186),
            xbmcgui.NOTIFICATION_INFO,
            4000,
        )
        return
    prompt_and_install_generator_tools(
        hdr_tone_map_enabled=settings.hdr_tone_map,
        hdr_dovi_tool_fallback_enabled=settings.hdr_dovi_tool_fallback,
        custom_ffmpeg_path=settings.ffmpeg_path,
        title=strings["title"],
        base_ffmpeg_prompt_yes=strings["base_ffmpeg_prompt_yes"],
        hdr_ffmpeg_prompt_yes=strings["hdr_ffmpeg_prompt_yes"],
        dovi_prompt_yes=strings["dovi_prompt_yes"],
        prompt_no=strings["prompt_no"],
        download_yes=strings["download_yes"],
        base_ffmpeg_progress_title=strings["base_ffmpeg_progress_title"],
        hdr_ffmpeg_progress_title=strings["hdr_ffmpeg_progress_title"],
        dovi_progress_title=strings["dovi_progress_title"],
        ffmpeg_unsupported_message=strings["ffmpeg_unsupported_message"],
        dovi_unsupported_message=strings["dovi_unsupported_message"],
        base_ffmpeg_failed_message=strings["base_ffmpeg_failed_message"],
        hdr_ffmpeg_failed_message=strings["hdr_ffmpeg_failed_message"],
        dovi_failed_message=strings["dovi_failed_message"],
        base_ffmpeg_success_message=strings["base_ffmpeg_success_message"],
        hdr_ffmpeg_success_message=strings["hdr_ffmpeg_success_message"],
        dovi_success_message=strings["dovi_success_message"],
        vulkan_prompt_yes=strings["vulkan_prompt_yes"],
        vulkan_success_message=strings["vulkan_success_message"],
        jellyfin_upgrade_prompt_yes=strings["jellyfin_upgrade_prompt_yes"],
        jellyfin_upgrade_success_message=strings["jellyfin_upgrade_success_message"],
    )
    try:
        from thumb_cropper import invalidate_playback_ffmpeg_cache

        invalidate_playback_ffmpeg_cache()
    except ImportError:
        pass

def run_install_tools_dialog(*, from_playback_prompt: bool = False) -> None:
    _log(
        "run_install_tools_dialog started "
        f"(from_playback_prompt={from_playback_prompt})"
    )
    settings = read_generator_settings()
    strings = _install_tools_strings(settings)
    include_generator = settings.enabled or settings.hdr_tone_map
    if not install_tools_needed(
        hdr_tone_map_enabled=settings.hdr_tone_map,
        hdr_dovi_tool_fallback_enabled=settings.hdr_dovi_tool_fallback,
        custom_ffmpeg_path=settings.ffmpeg_path,
        include_generator_tools=include_generator,
    ):
        _log("Install tools: nothing needed")
        if not from_playback_prompt:
            xbmcgui.Dialog().notification(
                strings["title"],
                strings["already_installed"],
                xbmcgui.NOTIFICATION_INFO,
                4000,
            )
        return

    if should_offer_pillow_download():
        prompt_and_install_pillow(
            title=strings["title"],
            prompt_yes=strings["pillow_prompt_yes"],
            prompt_no=strings["prompt_no"],
            download_yes=strings["download_yes"],
            progress_title=strings["pillow_progress_title"],
            unsupported_message=strings["pillow_unsupported_message"],
            failed_message=strings["pillow_failed_message"],
            success_message=strings["pillow_success_message"],
        )

    if include_generator and generator_install_tools_needed(
        hdr_tone_map_enabled=settings.hdr_tone_map,
        hdr_dovi_tool_fallback_enabled=settings.hdr_dovi_tool_fallback,
        custom_ffmpeg_path=settings.ffmpeg_path,
    ):
        prompt_and_install_generator_tools(
            hdr_tone_map_enabled=settings.hdr_tone_map,
            hdr_dovi_tool_fallback_enabled=settings.hdr_dovi_tool_fallback,
            custom_ffmpeg_path=settings.ffmpeg_path,
            title=strings["title"],
            base_ffmpeg_prompt_yes=strings["base_ffmpeg_prompt_yes"],
            hdr_ffmpeg_prompt_yes=strings["hdr_ffmpeg_prompt_yes"],
            dovi_prompt_yes=strings["dovi_prompt_yes"],
            prompt_no=strings["prompt_no"],
            download_yes=strings["download_yes"],
            base_ffmpeg_progress_title=strings["base_ffmpeg_progress_title"],
            hdr_ffmpeg_progress_title=strings["hdr_ffmpeg_progress_title"],
            dovi_progress_title=strings["dovi_progress_title"],
            ffmpeg_unsupported_message=strings["ffmpeg_unsupported_message"],
            dovi_unsupported_message=strings["dovi_unsupported_message"],
            base_ffmpeg_failed_message=strings["base_ffmpeg_failed_message"],
            hdr_ffmpeg_failed_message=strings["hdr_ffmpeg_failed_message"],
            dovi_failed_message=strings["dovi_failed_message"],
            base_ffmpeg_success_message=strings["base_ffmpeg_success_message"],
            hdr_ffmpeg_success_message=strings["hdr_ffmpeg_success_message"],
            dovi_success_message=strings["dovi_success_message"],
            vulkan_prompt_yes=strings["vulkan_prompt_yes"],
            vulkan_success_message=strings["vulkan_success_message"],
            jellyfin_upgrade_prompt_yes=strings["jellyfin_upgrade_prompt_yes"],
            jellyfin_upgrade_success_message=strings["jellyfin_upgrade_success_message"],
        )
    try:
        from pillow_installer import invalidate_pillow_cache
        from thumb_cropper import invalidate_playback_ffmpeg_cache

        invalidate_pillow_cache()
        invalidate_playback_ffmpeg_cache()
    except ImportError:
        pass


def run_convert_bif_dialog() -> None:
    """Convert existing .trickplay folders under Library folder to .bif (keeps .trickplay)."""
    import os
    import xbmcvfs
    from bif_format import (
        bif_output_path_for_media,
        convert_trickplay_to_bif,
        find_bif_for_media,
    )
    from generator_settings import read_generator_settings, read_runtime_settings
    from library_path_browse import browse_library_folder
    from pillow_installer import ensure_pillow_loaded
    from trickplay_generator import iter_library_videos
    from trickplay_resolver import (
        enrich_resolution,
        select_resolution,
        trickplay_root_for_media,
    )
    from vfs_paths import path_variants, vfs_is_dir

    title = _ADDON.getLocalizedString(32295) or "Convert .trickplay to .bif"
    if not ensure_pillow_loaded():
        xbmcgui.Dialog().ok(
            title,
            "Pillow is required to crop sprite tiles into .bif files. "
            "Run Install preview tools first.",
        )
        return

    gen_settings = read_generator_settings()
    library_path = (gen_settings.library_path or "").strip()

    options = [
        "Pick a movie or TV show folder",
        "Pick a single video file",
    ]
    if library_path and xbmcvfs.exists(library_path):
        options.append(f"Entire library folder ({library_path})")
    else:
        options.append("Entire library folder (browse...)")

    choice = xbmcgui.Dialog().select(title, options)
    if choice < 0:
        return

    media_files: list[str] = []
    scan_target = ""
    if choice == 0:
        chosen_dir = browse_library_folder(
            "Select movie or TV show folder",
            current=library_path,
        )
        if not chosen_dir:
            return
        scan_target = chosen_dir
    elif choice == 1:
        chosen_file = xbmcgui.Dialog().browse(
            1,
            "Select video file",
            "",
            "",
            False,
            False,
            library_path or "",
        )
        if not chosen_file:
            return
        media_files = [str(chosen_file)]
        scan_target = str(chosen_file)
    else:
        if not library_path or not xbmcvfs.exists(library_path):
            chosen_dir = browse_library_folder(title, current=library_path)
            if not chosen_dir:
                return
            library_path = chosen_dir
        scan_target = library_path

    runtime = read_runtime_settings()
    progress = xbmcgui.DialogProgress()
    progress.create(title, f"Scanning {scan_target}...")
    if not media_files:
        try:
            media_files = iter_library_videos(
                scan_target,
                should_cancel=progress.iscanceled,
            )
        except Exception as exc:
            progress.close()
            xbmcgui.Dialog().ok(title, f"Library scan failed: {exc}")
            return

    candidates: list[tuple[str, object, str]] = []
    for idx, media in enumerate(media_files):
        if progress.iscanceled():
            progress.close()
            return
        if idx % 20 == 0:
            progress.update(
                int(idx * 100 / max(len(media_files), 1)),
                f"Checking sidecars ({idx}/{len(media_files)})...",
            )
        if find_bif_for_media(media, runtime.preferred_width):
            continue
        for variant in path_variants(media):
            tp_root = trickplay_root_for_media(variant)
            if not vfs_is_dir(tp_root):
                continue
            res = select_resolution(
                tp_root,
                runtime.preferred_width,
                preferred_interval_ms=runtime.interval_ms,
                interval_preference=runtime.interval_preference,
            )
            if res is None:
                continue
            enriched = enrich_resolution(
                res,
                0,
                res.interval_ms,
                auto_tile_grid=runtime.auto_tile_grid,
                manual_tile_grid=runtime.manual_tile_grid,
                probe_last_tile=False,
            )
            if enriched.is_usable:
                out_path = bif_output_path_for_media(variant, enriched.width)
                candidates.append((media, enriched, out_path))
                break

    if not candidates:
        progress.close()
        xbmcgui.Dialog().ok(
            title,
            "No unconverted .trickplay sidecars found under the library folder.",
        )
        return

    converted = 0
    failed = 0
    cancelled = False
    for idx, (media, res, out_path) in enumerate(candidates):
        if progress.iscanceled():
            cancelled = True
            break
        name = os.path.basename(media)
        progress.update(
            int(idx * 100 / len(candidates)),
            f"Converting ({idx + 1}/{len(candidates)}): {name}",
        )
        ok, _count = convert_trickplay_to_bif(
            res,
            out_path,
            should_cancel=progress.iscanceled,
        )
        if progress.iscanceled():
            cancelled = True
            break
        if ok:
            converted += 1
        else:
            failed += 1

    progress.close()
    status = "Cancelled. " if cancelled else ""
    xbmcgui.Dialog().ok(
        title,
        f"{status}Converted {converted} file(s) to .bif ({failed} failed).\n"
        "Original .trickplay folders were kept intact.",
    )

