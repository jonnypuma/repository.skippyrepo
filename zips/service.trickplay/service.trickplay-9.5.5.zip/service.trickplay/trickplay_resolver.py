"""Resolve Jellyfin trickplay folders and map seek times to sprite tiles."""

from __future__ import annotations

import os
import re
from dataclasses import dataclass

import xbmc
import xbmcvfs

from thumb_cropper import probe_image_dimensions
from vfs_paths import (
    local_path as _local_path,
    network_url_to_local,
    path_variants,
    vfs_is_dir as _path_is_dir,
    vfs_join,
    vfs_list_file_names,
    vfs_list_subdir_names,
)

# Jellyfin stores tiles under:
# {basename}.trickplay/{width} - {tileW}x{tileH}/{index}.jpg
# {basename}.trickplay/{width} - {tileW}x{tileH} - {intervalMs}/{index}.jpg
DEFAULT_FOLDER_INTERVAL_MS = 10000
INTERVAL_PREF_PREFERRED = "preferred"
INTERVAL_PREF_SHORTEST = "shortest"
_RESOLUTION_DIR_RE = re.compile(
    r"^(?P<width>\d+)\s*-\s*(?P<tile_w>\d+)x(?P<tile_h>\d+)"
    r"(?:\s*-\s*(?P<interval_ms>\d+))?$",
    re.IGNORECASE,
)
_TILE_FILE_RE = re.compile(r"^\d+\.jpg$", re.IGNORECASE)
_TILE_GRID_RE = re.compile(r"^\s*(\d+)\s*[xX]\s*(\d+)\s*$")
_MAX_TILE_GRID = 50
_MIN_TILE_GRID = 1


@dataclass(frozen=True)
class TrickplayResolution:
    width: int
    tile_width: int
    tile_height: int
    tiles_dir: str
    tile_paths: tuple[str, ...]
    interval_ms: int = DEFAULT_FOLDER_INTERVAL_MS
    thumb_width: int = 0
    thumb_height: int = 0
    tile_image_width: int = 0
    tile_image_height: int = 0
    thumbnail_count: int = 0
    bif_path: str = ""

    @property
    def thumbs_per_tile(self) -> int:
        return self.tile_width * self.tile_height

    @property
    def is_usable(self) -> bool:
        return bool(
            (self.tile_paths or self.bif_path)
            and self.thumb_width > 0
            and self.thumb_height > 0
        )


@dataclass(frozen=True)
class TrickplayLookup:
    tile_path: str
    col: int
    row: int
    thumb_width: int
    thumb_height: int
    thumb_index: int
    target_second: int


@dataclass(frozen=True)
class SidecarCompatibility:
    name: str
    compatible: bool
    reason: str


def inspect_sidecar_directory_name(name: str) -> SidecarCompatibility:
    """Explain why a Jellyfin resolution directory is or is not usable."""
    parsed = parse_resolution_dir_name(name)
    if parsed is None:
        return SidecarCompatibility(
            name,
            False,
            "expected '<width> - <columns>x<rows>[-<interval_ms>]'",
        )
    width, columns, rows, interval = parsed
    if width <= 0 or columns < _MIN_TILE_GRID or rows < _MIN_TILE_GRID:
        return SidecarCompatibility(name, False, "width and grid must be positive")
    if columns > _MAX_TILE_GRID or rows > _MAX_TILE_GRID:
        return SidecarCompatibility(name, False, "grid exceeds supported 50x50 limit")
    if interval <= 0:
        return SidecarCompatibility(name, False, "interval must be positive")
    return SidecarCompatibility(name, True, "valid Jellyfin resolution directory")


def sidecar_compatibility_report(root: str) -> tuple[SidecarCompatibility, ...]:
    """Inspect all immediate resolution folders for diagnostics/UI."""
    return tuple(
        inspect_sidecar_directory_name(name)
        for name in _list_immediate_subdir_names(root)
    )


def _log(message: str, level=xbmc.LOGINFO) -> None:
    xbmc.log(f"[service.trickplay] {message}", level)


def _log_debug(debug: bool, message: str) -> None:
    if debug:
        _log(message, xbmc.LOGINFO)


def _vfs_join(base: str, *parts: str) -> str:
    return vfs_join(base, *parts)


def _list_immediate_subdir_names(directory: str) -> list[str]:
    """List child directory names; NFS/SMB VFS URLs and OS mounts."""
    return vfs_list_subdir_names(directory)


def _list_tile_jpg_names(tiles_dir: str) -> list[str]:
    """List numbered tile JPG names; NFS/SMB VFS URLs and OS mounts."""
    return [
        name
        for name in vfs_list_file_names(tiles_dir)
        if _TILE_FILE_RE.match(str(name))
    ]


def _sidecar_lookup_media_paths(media_path: str) -> tuple[str, ...]:
    """Paths that may share the same on-disk .trickplay sibling folder.

    Does not STAT the playing video. ``xbmcvfs.exists()`` on an NFS 4K MKV
    while Kodi is opening the same file can stall sidecar discovery for
    seconds. ``.trickplay`` folders are listed from URL/path variants and
    cheap OS mount maps instead.
    """
    path = (media_path or "").strip()
    if not path:
        return ()
    if path.lower().startswith(("plugin://", "http://", "https://")):
        return ()

    if path.lower().endswith(".strm"):
        try:
            with xbmcvfs.File(path, "r") as handle:
                target = (handle.read() or "").strip()
        except OSError:
            target = ""
        if target and not target.lower().startswith(
            ("plugin://", "http://", "https://")
        ):
            path = target

    if path.startswith("special://"):
        path = xbmcvfs.translatePath(path)

    return path_variants(path)


def resolve_media_path(playing_file: str) -> str | None:
    """Return a path Kodi can use for the playing item (prefers OS mount when mapped)."""
    if not playing_file:
        return None

    path = playing_file
    if path.lower().startswith(("plugin://", "http://", "https://")):
        return None

    if path.lower().endswith(".strm"):
        try:
            with xbmcvfs.File(path, "r") as handle:
                target = handle.read().strip()
        except OSError:
            return None
        if not target or target.lower().startswith(("plugin://", "http://", "https://")):
            return None
        path = target

    if path.startswith("special://"):
        path = xbmcvfs.translatePath(path)

    for candidate in path_variants(path):
        if "://" not in candidate and os.path.isfile(candidate):
            return candidate

    mapped = network_url_to_local(path)
    if mapped and os.path.isfile(mapped):
        return mapped

    if xbmcvfs.exists(path):
        return path

    if mapped and xbmcvfs.exists(mapped):
        return mapped

    return None


def trickplay_root_for_media(media_path: str) -> str:
    base, _ext = os.path.splitext(media_path)
    return f"{base}.trickplay"


def format_resolution_dir_name(
    width: int,
    tile_width: int,
    tile_height: int,
    interval_ms: int = DEFAULT_FOLDER_INTERVAL_MS,
) -> str:
    return f"{width} - {tile_width}x{tile_height} - {interval_ms}"


def parse_resolution_dir_name(name: str) -> tuple[int, int, int, int] | None:
    match = _RESOLUTION_DIR_RE.match(name)
    if not match:
        return None
    interval_raw = match.group("interval_ms")
    interval_ms = int(interval_raw) if interval_raw else DEFAULT_FOLDER_INTERVAL_MS
    return (
        int(match.group("width")),
        int(match.group("tile_w")),
        int(match.group("tile_h")),
        max(interval_ms, 1),
    )


def _list_resolution_dirs(trickplay_root: str, debug: bool = False) -> list[TrickplayResolution]:
    if not _path_is_dir(trickplay_root):
        return []

    resolutions: list[TrickplayResolution] = []
    for name in _list_immediate_subdir_names(trickplay_root):
        parsed = parse_resolution_dir_name(name)
        if parsed is None:
            continue

        width, tile_w, tile_h, interval_ms = parsed
        tiles_dir = _vfs_join(trickplay_root, name)
        tile_paths = _list_tile_paths(tiles_dir, debug=debug)
        if not tile_paths:
            _log_debug(debug, f"No tile JPGs found in {tiles_dir}")
            continue

        resolutions.append(
            TrickplayResolution(
                width=width,
                tile_width=tile_w,
                tile_height=tile_h,
                tiles_dir=tiles_dir,
                tile_paths=tile_paths,
                interval_ms=interval_ms,
            )
        )

    return resolutions


def _list_tile_paths(tiles_dir: str, debug: bool = False) -> tuple[str, ...]:
    names = _list_tile_jpg_names(tiles_dir)
    if not names:
        return ()

    def _tile_index(filename: str) -> int:
        return int(os.path.splitext(filename)[0])

    names = sorted(set(names), key=_tile_index)
    paths = tuple(_vfs_join(tiles_dir, name) for name in names)
    _log_debug(debug, f"Found {len(paths)} tile file(s) in {tiles_dir}")
    return paths


def select_resolution(
    trickplay_root: str,
    preferred_width: int,
    preferred_interval_ms: int = DEFAULT_FOLDER_INTERVAL_MS,
    interval_preference: str = INTERVAL_PREF_PREFERRED,
    debug: bool = False,
) -> TrickplayResolution | None:
    resolutions = _list_resolution_dirs(trickplay_root, debug=debug)
    if not resolutions:
        _log_debug(debug, f"No trickplay resolutions under {trickplay_root}")
        return None

    preference = normalize_interval_preference(interval_preference)
    same_width = [res for res in resolutions if res.width == preferred_width]
    pool = same_width if same_width else resolutions

    if preference == INTERVAL_PREF_SHORTEST:
        chosen = min(pool, key=lambda res: (res.interval_ms, res.width))
        _log(
            f"Using shortest interval {chosen.interval_ms}ms at {chosen.width}px "
            f"({chosen.tiles_dir}, {len(chosen.tile_paths)} tile file(s))"
        )
        return chosen

    exact = [
        res
        for res in pool
        if res.interval_ms == preferred_interval_ms
    ]
    if exact:
        chosen = exact[0]
        _log(
            f"Using preferred resolution {preferred_width}px / {preferred_interval_ms}ms "
            f"at {chosen.tiles_dir} ({len(chosen.tile_paths)} tile file(s))"
        )
        return chosen

    if same_width:
        chosen = min(
            same_width,
            key=lambda res: abs(res.interval_ms - preferred_interval_ms),
        )
        _log(
            f"Using resolution {chosen.width}px / {chosen.interval_ms}ms at "
            f"{chosen.tiles_dir} ({len(chosen.tile_paths)} tile file(s)); "
            f"preferred interval {preferred_interval_ms}ms not found"
        )
        return chosen

    chosen = sorted(resolutions, key=lambda res: res.width)[0]
    _log(
        f"Preferred width {preferred_width}px not found; using {chosen.width}px / "
        f"{chosen.interval_ms}ms at {chosen.tiles_dir} "
        f"({len(chosen.tile_paths)} tile file(s))"
    )
    return chosen


def _default_thumb_height(thumb_width: int) -> int:
    return max(int(round(thumb_width * 9 / 16)), 2)


def resolve_tile_grid(
    resolution: TrickplayResolution,
    auto_tile_grid: bool,
    manual_tile_grid: str,
    debug: bool = False,
) -> tuple[int, int]:
    """Return (columns, rows) for splitting each sprite JPG."""
    if auto_tile_grid:
        return resolution.tile_width, resolution.tile_height

    match = _TILE_GRID_RE.match((manual_tile_grid or "").strip())
    if not match:
        _log(
            f"Invalid manual tile grid {manual_tile_grid!r}; "
            f"using folder grid {resolution.tile_width}x{resolution.tile_height}",
            xbmc.LOGWARNING,
        )
        return resolution.tile_width, resolution.tile_height

    cols = max(min(int(match.group(1)), _MAX_TILE_GRID), _MIN_TILE_GRID)
    rows = max(min(int(match.group(2)), _MAX_TILE_GRID), _MIN_TILE_GRID)
    _log_debug(debug, f"Manual tile grid: {cols}x{rows}")
    return cols, rows


def parse_manual_tile_grid(manual_tile_grid: str) -> tuple[int, int] | None:
    """Parse a grid string like 10x10. Returns None if invalid."""
    match = _TILE_GRID_RE.match((manual_tile_grid or "").strip())
    if not match:
        return None
    cols = max(min(int(match.group(1)), _MAX_TILE_GRID), _MIN_TILE_GRID)
    rows = max(min(int(match.group(2)), _MAX_TILE_GRID), _MIN_TILE_GRID)
    return cols, rows


def normalize_interval_preference(value: str) -> str:
    normalized = (value or "").strip().lower()
    if normalized == INTERVAL_PREF_SHORTEST:
        return INTERVAL_PREF_SHORTEST
    return INTERVAL_PREF_PREFERRED


def _grid_cols_rows(grid: str) -> tuple[int, int]:
    parsed = parse_manual_tile_grid(grid)
    if parsed:
        return parsed
    return 10, 10


def resolution_matches_settings(
    resolution: TrickplayResolution,
    tile_width: int,
    grid: str,
    interval_ms: int,
) -> bool:
    """True when a sidecar folder matches generator width, grid, and interval."""
    if not resolution.tile_paths:
        return False
    cols, rows = _grid_cols_rows(grid)
    return (
        resolution.width == tile_width
        and resolution.tile_width == cols
        and resolution.tile_height == rows
        and resolution.interval_ms == interval_ms
    )


def find_matching_sidecar_resolution(
    media_path: str,
    tile_width: int,
    grid: str,
    interval_ms: int,
    debug: bool = False,
) -> TrickplayResolution | None:
    """Return an existing sidecar folder compatible with generator settings."""
    for lookup_path in _sidecar_lookup_media_paths(media_path):
        trickplay_root = trickplay_root_for_media(lookup_path)
        if not _path_is_dir(trickplay_root):
            _log_debug(debug, f"No trickplay root at {trickplay_root}")
            continue
        for resolution in _list_resolution_dirs(trickplay_root, debug=debug):
            if resolution_matches_settings(resolution, tile_width, grid, interval_ms):
                if debug:
                    _log(
                        f"Matching sidecar for {os.path.basename(lookup_path)}: "
                        f"{resolution.tiles_dir} "
                        f"({len(resolution.tile_paths)} tile file(s))"
                    )
                return resolution
            if debug:
                _log(
                    f"Sidecar folder not compatible for skip: {resolution.tiles_dir} "
                    f"(want {tile_width}px {grid} @ {interval_ms}ms, "
                    f"have {resolution.width}px "
                    f"{resolution.tile_width}x{resolution.tile_height} "
                    f"@ {resolution.interval_ms}ms)"
                )
    return None


def has_matching_sidecar(
    media_path: str,
    tile_width: int,
    grid: str,
    interval_ms: int,
    debug: bool = False,
) -> bool:
    """True when usable trickplay already exists for the requested layout."""
    return find_matching_sidecar_resolution(
        media_path,
        tile_width,
        grid,
        interval_ms,
        debug=debug,
    ) is not None


def _estimate_thumbnail_count(
    tile_count: int,
    thumbs_per_tile: int,
    duration_seconds: int,
    interval_ms: int,
) -> int:
    if tile_count <= 0:
        return 0

    from_files = max((tile_count - 1) * thumbs_per_tile + 1, 1)
    if duration_seconds > 0 and interval_ms > 0:
        interval_sec = max(interval_ms / 1000.0, 0.001)
        from_duration = int(duration_seconds / interval_sec) + 1
        if from_duration >= max(from_files // 2, 2):
            return min(from_files, from_duration)
    return from_files


def enrich_resolution(
    resolution: TrickplayResolution,
    duration_seconds: int,
    interval_ms: int,
    auto_tile_grid: bool = True,
    manual_tile_grid: str = "10x10",
    debug: bool = False,
    *,
    probe_last_tile: bool = True,
) -> TrickplayResolution:
    """Fill in thumb dimensions and total thumbnail count.

    ``probe_last_tile`` copies the last sprite to count a partial final tile.
    Skip it on first load so ``0.jpg`` can be copied and cropped before any
    later NFS sprite download.
    """
    if not resolution.tile_paths:
        return resolution

    grid_cols, grid_rows = resolve_tile_grid(
        resolution,
        auto_tile_grid,
        manual_tile_grid,
        debug=debug,
    )

    tile_w, tile_h = probe_image_dimensions(resolution.tile_paths[0], debug=debug)
    if tile_w <= 0 or tile_h <= 0:
        thumb_width = resolution.width
        thumb_height = _default_thumb_height(thumb_width)
        _log(
            f"Could not read tile dimensions from {resolution.tile_paths[0]}; "
            f"using fallback {thumb_width}x{thumb_height}",
            xbmc.LOGWARNING,
        )
    else:
        thumb_width = max(tile_w // grid_cols, 1)
        thumb_height = max(tile_h // grid_rows, 1)
        grid_source = (
            f"{grid_cols}x{grid_rows} from folder"
            if auto_tile_grid
            else f"{grid_cols}x{grid_rows} manual"
        )
        _log(
            f"Sprite {os.path.basename(resolution.tile_paths[0])} is {tile_w}x{tile_h} "
            f"-> cell {thumb_width}x{thumb_height} ({grid_source})"
        )

    thumbs_per_tile = grid_cols * grid_rows
    full_tiles = max(len(resolution.tile_paths) - 1, 0)
    if probe_last_tile and len(resolution.tile_paths) > 1:
        last_tile_thumbs = _count_thumbs_in_last_tile(
            resolution,
            thumb_width,
            thumb_height,
            full_tiles,
            grid_cols,
            grid_rows,
            debug=debug,
        )
    else:
        last_tile_thumbs = thumbs_per_tile
    from_files = full_tiles * thumbs_per_tile + last_tile_thumbs
    if duration_seconds > 0 and interval_ms > 0:
        interval_sec = max(interval_ms / 1000.0, 0.001)
        from_duration = int(duration_seconds / interval_sec) + 1
        # Kodi often reports 0–1s until metadata is ready. Never shrink the
        # file-based count until duration can explain most of the sprite set.
        if from_duration >= max(from_files // 2, 2):
            thumbnail_count = min(from_files, from_duration)
        else:
            thumbnail_count = from_files
    else:
        thumbnail_count = from_files

    if thumbnail_count <= 0:
        thumbnail_count = _estimate_thumbnail_count(
            len(resolution.tile_paths),
            thumbs_per_tile,
            duration_seconds,
            interval_ms,
        )

    enriched = TrickplayResolution(
        width=resolution.width,
        tile_width=grid_cols,
        tile_height=grid_rows,
        tiles_dir=resolution.tiles_dir,
        tile_paths=resolution.tile_paths,
        interval_ms=resolution.interval_ms,
        thumb_width=thumb_width,
        thumb_height=thumb_height,
        tile_image_width=tile_w if tile_w > 0 else thumb_width * grid_cols,
        tile_image_height=tile_h if tile_h > 0 else thumb_height * grid_rows,
        thumbnail_count=thumbnail_count,
    )
    _log_debug(
        debug,
        f"Enriched trickplay: grid={grid_cols}x{grid_rows}, "
        f"interval={resolution.interval_ms}ms, "
        f"thumb={thumb_width}x{thumb_height}, "
        f"count={thumbnail_count}, tiles={len(resolution.tile_paths)}",
    )
    return enriched


def _count_thumbs_in_last_tile(
    resolution: TrickplayResolution,
    thumb_width: int,
    thumb_height: int,
    full_tiles: int,
    grid_cols: int,
    grid_rows: int,
    debug: bool = False,
) -> int:
    if not resolution.tile_paths:
        return 0

    last_path = resolution.tile_paths[-1]
    tile_w, tile_h = probe_image_dimensions(last_path, debug=debug)
    thumbs_per_tile = grid_cols * grid_rows
    if tile_w <= 0 or tile_h <= 0 or thumb_width <= 0 or thumb_height <= 0:
        if full_tiles == 0:
            return 1
        return thumbs_per_tile

    cols = min(max(tile_w // thumb_width, 1), grid_cols)
    rows = min(max(tile_h // thumb_height, 1), grid_rows)
    count = cols * rows
    return max(count, 1)


def lookup_thumbnail(
    resolution: TrickplayResolution,
    target_second: int,
    interval_ms: int,
) -> TrickplayLookup | None:
    if not resolution.is_usable:
        return None

    interval_sec = max(interval_ms / 1000.0, 0.001)
    thumb_index = max(int(target_second / interval_sec), 0)
    if resolution.thumbnail_count > 0:
        thumb_index = min(thumb_index, resolution.thumbnail_count - 1)

    if resolution.bif_path:
        return TrickplayLookup(
            tile_path=resolution.bif_path,
            col=thumb_index,
            row=0,
            thumb_width=resolution.thumb_width,
            thumb_height=resolution.thumb_height,
            thumb_index=thumb_index,
            target_second=target_second,
        )

    thumbs_per_tile = resolution.thumbs_per_tile
    tile_index = thumb_index // thumbs_per_tile
    position_in_tile = thumb_index % thumbs_per_tile

    if tile_index >= len(resolution.tile_paths):
        tile_index = len(resolution.tile_paths) - 1
        position_in_tile = min(position_in_tile, thumbs_per_tile - 1)

    col = position_in_tile % resolution.tile_width
    row = position_in_tile // resolution.tile_width

    return TrickplayLookup(
        tile_path=resolution.tile_paths[tile_index],
        col=col,
        row=row,
        thumb_width=resolution.thumb_width,
        thumb_height=resolution.thumb_height,
        thumb_index=thumb_index,
        target_second=target_second,
    )


def lookup_by_index(
    resolution: TrickplayResolution,
    thumb_index: int,
    interval_ms: int,
) -> TrickplayLookup | None:
    if not resolution.is_usable or thumb_index < 0:
        return None
    if resolution.thumbnail_count > 0:
        thumb_index = min(thumb_index, resolution.thumbnail_count - 1)
    interval_sec = max(interval_ms / 1000.0, 0.001)
    target_second = int(thumb_index * interval_sec)
    return lookup_thumbnail(resolution, target_second, interval_ms)


def _prefer_bif_enabled() -> bool:
    try:
        import xbmcaddon

        addon = xbmcaddon.Addon("service.trickplay")
        try:
            return bool(addon.getSettingBool("prefer_bif"))
        except (RuntimeError, TypeError, ValueError):
            raw = addon.getSettingString("prefer_bif")
            if not raw:
                return True
            return raw.strip().lower() in ("true", "1", "yes", "on")
    except Exception:
        return True


def _load_bif_resolution(
    media_path: str,
    preferred_width: int,
    debug: bool = False,
) -> TrickplayResolution | None:
    try:
        from bif_format import find_bif_for_media, parse_bif_index
    except ImportError:
        return None
    bif_path = find_bif_for_media(media_path, preferred_width)
    if not bif_path:
        return None
    index = parse_bif_index(bif_path)
    if index is None or index.frame_count <= 0:
        return None
    thumb_w = index.thumb_width or int(preferred_width)
    thumb_h = index.thumb_height or max(int(round(thumb_w * 9 / 16)), 1)
    if debug:
        _log(
            f"Loaded .bif sidecar {bif_path} "
            f"({index.frame_count} frames @ {index.interval_ms}ms, {thumb_w}x{thumb_h})"
        )
    return TrickplayResolution(
        width=thumb_w,
        tile_width=1,
        tile_height=1,
        tiles_dir=os.path.dirname(bif_path),
        tile_paths=(),
        interval_ms=index.interval_ms,
        thumb_width=thumb_w,
        thumb_height=thumb_h,
        thumbnail_count=index.frame_count,
        bif_path=bif_path,
    )


def load_trickplay_for_file(
    playing_file: str,
    preferred_width: int,
    interval_ms: int,
    duration_seconds: int,
    auto_tile_grid: bool = True,
    manual_tile_grid: str = "10x10",
    interval_preference: str = INTERVAL_PREF_PREFERRED,
    debug: bool = False,
) -> TrickplayResolution | None:
    candidates = _sidecar_lookup_media_paths(playing_file)
    if not candidates:
        _log_debug(debug, f"Could not resolve media path from {playing_file!r}")
        return None

    if _prefer_bif_enabled():
        for media_path in candidates:
            bif_res = _load_bif_resolution(media_path, preferred_width, debug=debug)
            if bif_res is not None:
                return bif_res

    for media_path in candidates:
        trickplay_root = trickplay_root_for_media(media_path)
        if not _path_is_dir(trickplay_root):
            _log_debug(debug, f"No trickplay root at {trickplay_root}")
            continue

        resolution = select_resolution(
            trickplay_root,
            preferred_width,
            preferred_interval_ms=interval_ms,
            interval_preference=interval_preference,
            debug=debug,
        )
        if resolution is None:
            continue

        folder_interval_ms = resolution.interval_ms
        if debug and media_path != playing_file:
            _log(
                f"Loaded trickplay via path variant {media_path!r} "
                f"(playing file {playing_file!r})"
            )
        return enrich_resolution(
            resolution,
            duration_seconds,
            folder_interval_ms,
            auto_tile_grid=auto_tile_grid,
            manual_tile_grid=manual_tile_grid,
            debug=debug,
            probe_last_tile=False,
        )

    _log_debug(
        debug,
        f"No trickplay sidecar for {playing_file!r} "
        f"(tried {len(candidates)} media path variant(s))",
    )
    return None
