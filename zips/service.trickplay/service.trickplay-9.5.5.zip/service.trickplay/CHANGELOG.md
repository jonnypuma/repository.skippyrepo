# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).
From 9.0.0, minor versions are 0–9 (`9.1.0` … `9.9.0`), then the next major.

## [9.5.5] - 2026-11-22

### Fixed

- **Pillow post-install import on Docker / musl Linux** — invalidates Python
  import caches (`importlib.invalidate_caches()`) and clears stale `PIL` /
  `pillow.libs` directories after wheel extraction, selects `musllinux` wheels
  on Alpine/musl containers, and logs/reports the exact `ImportError` reason if
  import still fails.

## [9.5.4] - 2026-11-22

### Fixed

- **Pillow installer on Python 3.14 / Linux (`cp314`)** — falls back to the
  latest PyPI Pillow release when `10.4.0` has no wheel for the active Python
  ABI (e.g. `cp314` on headless Docker Kodi), and matches compound manylinux
  platform tags (`manylinux_2_27_x86_64.manylinux_2_28_x86_64`).
- **Generator ffmpeg / `dovi_tool` install path on non-CoreELEC Linux** —
  checks whether `/storage/.kodi` exists and is writable before selecting
  `/storage/.kodi/system/ffmpeg`, falling back to
  `special://profile/addon_data/service.trickplay/system/ffmpeg` on standard
  Linux and headless Docker containers instead of failing with `PermissionError`
  on `/storage`.

## [9.5.3] - 2026-11-22

### Fixed

- **Smooth long-jump updates in Auto display mode** — `Preview display mode → Auto`
  now uses the installed `DialogSeekBar.xml` skin snippet whenever present so
  thumbnails update live during long jumps on PC and CoreELEC (avoiding Kodi's
  `VideoFullScreen` seek-buffer stall), while still falling back to the
  zero-skin-edit `VideoFullScreen` overlay when no snippet is installed.

## [9.5.2] - 2026-11-22

### Fixed

- **`.bif` prefetch no longer triggers sprite decode errors** — skips `.bif`
  paths in `schedule_playhead_warm()`, `schedule_tile_warm()`, and
  `_enqueue_tile_decode()` so `.bif` archives are never sent to the JPEG sprite
  decoder.
- **Continuous preview updates during long 5+ min scrubs** — throttles in-flight
  crop cancellation so at least one fresh frame publishes every 250 ms during
  continuous rapid scrubbing, and preloads `.bif` files into RAM for
  synchronous `< 1 ms` live preview writes without SD/eMMC flash thrashing.
- **Aeon Fuse Small OSD clearance** — raised the Small OSD anchor (`bar.top = 816`)
  to clear the `AGOSD_Bubble` time pill and OSD panel when displaying the
  timestamp below the thumbnail.

## [9.5.1] - 2026-11-22

### Added

- **Aeon Fuse skin profile (`skin.aeon.fuse`)** — dedicated small OSD (VGlass
  compact seekbar) and big OSD (Aeon / VGlass and Fused Glass) geometry, with
  automatic switching between small and big OSD states.
- **Additional skin profiles** — added dedicated profiles for **Estuary (stock)**,
  **Bald** (small & big OSD), **Daylight** (small & big OSD), **Glass** (small &
  big OSD), **Duotone**, **Fold**, **Groove**, **Majan**, **Passepartout**, and
  **Six Degrees**.
- **Built-in overlay outline** — adds a crisp 2 px border around the built-in
  overlay thumbnail that automatically adapts to any thumbnail aspect ratio.
- **Skippy chapter/segment fallback** — when Kodi reports no embedded chapter
  name, falls back to `service.skippy`'s live segment snapshot
  (`skippy.parse_cache_snapshot.v1`) or sidecar `*_chapters.xml` / `.edl` files.
- **Native `.bif` reader & `.trickplay` → `.bif` converter** — reads sibling
  `.bif` archives directly with zero Pillow/sprite decoding overhead (ideal for
  CoreELEC/ARM), adds **Convert .trickplay to .bif** under **Tools & Skin**
  (supporting a single video, show/movie folder, or entire library while keeping
  `.trickplay` folders intact), and adds **Generator output format**
  (`Trickplay sprites`, `BIF archive`, or `Both`) in generator settings.

### Changed

- **Built-in overlay is now the default display method** — `Preview display mode`
  defaults to **Auto (built-in overlay, skin fallback)**, rendering via
  non-focusable `VideoFullScreen` controls with zero skin edits and falling back
  to an installed skin snippet if needed.
- **Verified existing skin profiles** — updated **Arctic Horizon 2** / **AH2.1
  Arizen** to match `view_pad=80` `(80, 720, 1760)` and added full-OSD `-74 px`
  lift geometry for **Arctic Zephyr**.

### Fixed

- **Preview repositions when switching between Small OSD and Big OSD** —
  refresh placement and built-in overlay coordinates when opening or closing the
  full OSD while a preview is already visible (even when scrubbing has stopped).

## [9.5.0] - 2026-11-21

### Added

- **Zero-skin-edit built-in overlay** — attaches non-focusable preview controls
  directly onto `VideoFullScreen` (never stealing remote/keyboard focus) to
  display scrubbing thumbnails on any skin without patching `DialogSeekBar.xml`.
- **Seek delta and chapter name in the preview overlay** — publishes
  `Trickplay.PreviewDelta` (e.g. `+1:30`, `-0:45`) and `Trickplay.PreviewChapter`
  and appends them to `Trickplay.PreviewTime` (e.g. `12:30 (+1:30) · Opening Credits`)
  so existing skins show them automatically. Configurable via **Show seek delta**
  and **Show chapter name** under **Preview adjustment**.
- **Auto-reapply skin snippet on skin updates** — optional toggle under
  **Tools & Skin** that automatically re-installs the Trickplay overlay and
  reloads the skin when the active skin updates or switches to a supported skin
  without the overlay.

### Changed

- **Lower CPU/IPC overhead during passive playback** — backs off polling to
  300 ms while video is playing with the seek UI closed (still reacting
  immediately to seek events and returning to `poll_ms` as soon as the OSD
  opens).
- **Batched `DialogSeekBar` property writes** — resolves `Window(10115)` once
  per preview publish batch instead of twice per property, and skips redundant
  post-publish resync passes when the seek bar is already visible.
- **Decluttered settings** — moved setup, diagnostics, tool installers, and skin
  snippet actions out of **General** into a dedicated **Tools & Skin** category.
- **Modularized sidecar storage** — extracted sidecar filesystem and atomic
  promotion helpers from `trickplay_generator.py` into `sidecar_storage.py`.
- **Repository cleanup** — removed stale conflict duplicates (`*-Jon.*`) and
  unused legacy dialog XMLs.

## [9.4.0] - 2026-09-23

### Fixed

- **Run showed no dialog after the folder picker** — loading the saved queue
  checked every completed file on the UI thread, so after a large batch the
  scan dialog never opened. The queue is read first, then the scan or resume
  prompt is shown. Completed-file checks run behind the wait dialog.

## [9.3.0] - 2026-09-23

### Fixed

- **Sidecar folder rename denied on existing network folders** — Windows
  returns WinError 5 when the destination sidecar directory already exists, even
  when the video file itself is readable. That folder is removed and the finished
  sidecar renamed into its place. If the folder cannot be removed, the tiles are
  copied into it. Short paths stay plain paths; the `\\?\` prefix remains only
  for paths past 260 characters.
- **Unreadable media names the probe error** — when duration cannot be read, the
  batch summary includes the ffprobe/ffmpeg line (for example an invalid
  Matroska header).

## [9.2.0] - 2026-09-22

### Fixed

- **Long Windows sidecar paths fail after the tiles are written** — the
  finished folder was renamed with `os.replace`, which stops at 260 characters.
  Deep `Y:\TV\...` paths were generated and then discarded. Rename and cleanup
  now use the `\\?\` extended path, and the Windows error is logged.
- **Batch summary hid the real error** — a promote failure was overwritten with
  "generation failed", and an unreadable file was listed with no reason. The
  summary keeps the promote error and records media not found, ffmpeg missing,
  unreadable duration, and Dolby Vision prep failure.

## [9.1.0] - 2026-09-22

### Changed

- **Cache the current sprite as soon as playback starts** — the playhead cell
  is cropped first, then the rest of that tile, without waiting for the seek
  bar. Preload still continues with the other sprites.
- **Seek bar does not wait on a cold crop** — opening the timebar no longer
  decodes a sprite on the service thread.
- **Scrub keeps a wider neighbor window** — while seeking, prefetch keeps 20
  thumbs ahead and 10 behind. Cells outside that window are dropped.
- **Stale scrub crops are abandoned** — if the cursor moves before JPEG encode,
  that cell is dropped and the latest thumb is published as soon as it exists.

## [9.0.0] - 2026-09-15

### Added

- **Remaining generation queue** — after a library scan, unfinished media paths
  are stored with the completed set. A crash or reboot no longer requires walking
  the library again.
- **Resume vs Rescan on Run** — if a remaining queue exists for the current
  folder and generator settings, Run asks **Resume N files** or **Rescan library**.
  Idle generation uses the same saved queue.

## [8.18.7] - 2026-09-14

### Fixed

- **Scrub shows the cursor cell, not the path** — after opening the large OSD
  and returning to the timebar, prefetch kept every already-local whole-tile
  crop and then drained them when you stopped. Scrub now keeps only nearby
  high-priority cells, skips whole-tile enqueue while seeking, yields the
  prefetch worker to the visible crop, and clears the leftover FIFO on OSD
  handoff.

## [8.18.6] - 2026-09-14

### Fixed

- **Accurate produces no usable tiles on corrupt WEB-DL** — seek-after-input
  must decode from the start, so a bad AU at 10s made every later stamp fail
  (~30s each) and copy the 0.0s frame. After the first Accurate miss, remaining
  thumbs (and later tiles) use Fast seek, which can skip past that region.

## [8.18.5] - 2026-09-14

### Fixed

- **Fast and Accurate skip corrupt stamps** — Fast (default 10s interval) no
  longer starts a ~15-minute fps-batch decode; it uses per-frame seek and reuses
  the previous JPEG when a timestamp fails, same as Fast seek. Accurate no longer
  aborts the tile on the first failed frame (wait was ~10 minutes); it reuses
  the previous JPEG and continues. A hung accurate stamp is capped at 25–180s
  instead of 600s+.

## [8.18.4] - 2026-09-14

### Fixed

- **Batch seeks abort then 15-minute fps-batch hang** — a corrupt timestamp no
  longer stops the tile (S14E05 aborted at 1/100 then started a 860s continuous
  decode). Failed cells reuse the previous JPEG; a timed-out chunk does not
  re-run the same Fast seek. If the tile is still short, retry is Fast seek,
  not fps-batch.
- **Batch progress dialog** — the dialog shows the current file (and tile) instead
  of staying on “Generating trickplay…” at 0% for a single-file job.

## [8.18.3] - 2026-09-14

### Fixed

- **Fast seek abort on corrupt H.264** — a hung/failed timestamp no longer
  drops the rest of the tile (S14E05 stopped after 1, 8, and 27 thumbs). Failed
  cells reuse the previous JPEG so the sprite grid stays complete. Per-frame wait
  is 25s (was 120s); healthy seeks on that file were ~0.3s.

## [8.18.2] - 2026-09-14

### Fixed

- **Batch seeks hang on Windows mapped drives** — Fast (batch seeks) no longer
  opens the same file eight times in one ffmpeg process on Windows (the pattern
  that froze Kodi for ~15 minutes on some WEB-DL files). Chunk wait is capped at
  25–60s instead of ~16 minutes; a timed-out chunk falls back to Fast seek.

## [8.18.1] - 2026-09-14

### Fixed

- **Last thumb at exact EOF** — when duration is a multiple of the interval
  (e.g. 2800s at 10s), generation no longer seeks ffmpeg to the last timestamp,
  which exited 0 with no JPEG and wrote a short final tile.

## [8.18.0] - 2026-09-13

### Changed

- **Foreground-first episode pre-crop** — full-sprite pre-cropping now works in
  chunks of eight cells and pauses while an exact visible thumb is pending.
- **Cheaper cache hits** — known crop paths are trusted for 30 seconds and LRU
  timestamp writes are debounced to once per minute instead of touching the
  filesystem on every scrub hit.
- **Bounded durable writer** — cold crops enqueue immutable JPEG bytes on one
  64-item persistence worker rather than spawning a thread that copies a reused
  live file. Live texture rotation now uses six slots to avoid overwrite races.
- **Lighter scrub prioritization** — seeking promotes only the current and
  adjacent sprites; it no longer rebuilds the complete copy queue every poll.
- **Crop latency diagnostics** — the exported diagnostic report now includes
  cache-source counters and copy, decode, crop, encode, write, exact-crop, and
  request-to-publish timing totals, averages, and maxima.

## [8.17.0] - 2026-09-13

### Added

- **Generator queue** — Settings → Trickplay generator → Show generator queue lists
  the current file, paused/running state, and the next idle/batch items.
- **Weak device preset** — one action sets Fast seek and turns off HDR tone mapping
  and hardware decode (CoreELEC / Amlogic / 4K / network).
- **Idle: recently added only** — optional filter so idle generation only considers
  library items added in the last N days (default 14). Falls back to file mtime if
  the library query is unavailable.

## [8.16.0] - 2026-09-10

### Fixed

- **Overlay follows the cursor first** — seeking always publishes slot/time and the
  last or nearest ready thumb on the service thread, then crops the exact cell in
  the background. A single long jump no longer freezes the overlay on Pillow
  encode. The crop worker stores the result; the poll loop applies it.
- **Preview image stays up while seeking** — a missed crop no longer clears
  `PreviewImage` (Estuary hides the group when that property is empty).
- **Sidecar load no longer STAT-s the playing video** — NFS `exists()` on the MKV
  was gating `.trickplay` discovery. Lookup uses the playing URL; `resolve_media_path`
  remains for generation.
- **Unset duration does not shrink thumb count** — a 0–1s player duration no longer
  `min()`s the sprite file count down to one cell.
- **Estuary Mod v2 overlay tracks `PreviewLeft`** — slots 0–11 were all `end="0,0"`,
  so the thumb sat at a fixed X. The snippet now binds `PreviewLeft` /
  `PreviewLeftWide`. Reinstall the skin snippet (overlay revision 10).
- **Episode pre-crop waits for idle seek UI** — 100-cell JPEG encodes no longer
  start the moment the preview appears, which was stalling live scrub on GIL.
- **Last-tile probe is delayed** — `2.jpg` is not STAT-ed at playback start; it
  waits until later tiles are copied or the seek UI has been idle.
- **Windows NFS/SMB mapping** — `nfs://` / `smb://` try `\\host\share\…` with one
  share STAT (no drive-letter scan) so sprites can use local copies when the UNC
  path exists.

## [8.15.2] - 2026-08-17

### Fixed

- **Faster first thumbs** — sidecar lookup no longer STAT-s the playing video
  (NFS `exists()` on a 4K MKV while Kodi opens it was stalling `.trickplay`
  discovery). Sprite JPEG size is read from the header past 64 KB so ffprobe is
  not required. The first playhead cell is cropped and shown before the 100-cell
  episode encode, which now starts only after the preview is visible. Already
  copied/decoded tiles are not re-queued on every seek.

## [8.15.1] - 2026-08-17

### Fixed

- **First sprite first** — playback load copies and crops `0.jpg` before any later
  sprite. The last-tile dimension probe and remaining NFS copies run afterwards,
  so the first thumbnails are not blocked behind `2.jpg` / the final tile.

## [8.15.0] - 2026-08-17

### Added

- **Sprite preload worker** — as soon as playback starts, every sprite tile is
  copied to local temp and decoded into RAM (up to the sprite RAM setting). When
  **Preload all sprites on playback** is on, cells are pre-cropped in the
  background so scrubbing hits ready thumbs.
- **Cropped thumbs in RAM** — optional JPEG-bytes cache so scrubbing does not
  re-encode. 0 MB disables it for low-RAM devices.
- **Sprite tiles in RAM** — cap decoded sprite JPGs during playback (default 24,
  0 = local copies only). Each default 320×10×10 tile is about 16 MB.

### Changed

- **Seek poll interval** is a 25–250 ms slider (default 100).
- **Crop cache limit** default is 1000 MB.
- Fast scrub shows the **nearest already-cropped thumb** instead of freezing on
  the last frame, and no longer cancels prefetch of tiles that are already local.
- Pillow load prefers the add-on PyPI wheel when present so **libjpeg-turbo** is
  used for sprite decode.

## [8.14.0] - 2026-08-16

### Changed

- **Prefetch window is time-based** — the setting is now seconds (default 120 =
  ±2 minutes) instead of thumb indices. Index count is derived from the sidecar
  interval, so 5 s and 10 s thumbs cover the same timeline. During playback the
  window is still capped at 50 seconds so watching does not flood the crop queue.

## [8.13.0] - 2026-08-16

### Changed

- **Upcoming sprite warm** — when playhead prefetch (or scrub neighbors) reaches
  the last 20% of a sprite tile, the next tile is copied locally and decoded into
  RAM before you cross into it. Reverse scrub warms the previous tile in the first
  20%. First cell of `1.jpg` no longer waits for a cold NFS copy/decode.
- **Session-pinned decoded tiles** — during playback, decoded sprites stay in RAM
  for the whole file (up to 24 tiles; ~16 MiB each for 320@10x10) instead of an
  8-tile LRU, so pause-and-scrub-back stays instant. The pin is released when
  playback stops.

## [8.12.1] - 2026-08-16

### Fixed

- **Stock Estuary handling** — protected stock Estuary is excluded from overlay
  missing/stale reminders and installation prompts because Kodi does not allow the
  addon to modify its files.

## [8.12.0] - 2026-08-16

### Fixed

- **Final hardening** — completed the 8.x improvement sequence with full regression
  coverage, Python compilation checks, XML validation, and safer Kodi-stub behavior
  for missing runtime APIs.

## [8.11.0] - 2026-08-16

### Documentation

- Reconciled setup instructions with the guided wizard and documented rollback,
  diagnostic export, generator states, resume identity, network modes, and
  sidecar compatibility diagnostics.

## [8.10.0] - 2026-08-16

### Added

- **Diagnostic report export** — writes a redacted report containing addon health,
  generator settings summary, cache counters, and supported worker states.

## [8.9.0] - 2026-08-16

### Tests

- **Service lifecycle coverage** — reset behavior now has regression coverage for
  playback state, prefetch cancellation, preview cleanup, and Skippy properties.

## [8.8.0] - 2026-08-16

### Added

- **Per-skin calibration** — active skin scale and horizontal/vertical placement
  can be adjusted and persisted independently through the calibration action.

## [8.7.0] - 2026-08-16

### Added

- **Sidecar compatibility diagnostics** — resolution folders can now be classified
  as valid or invalid with a specific naming, grid, or interval reason.

## [8.6.0] - 2026-08-16

### Changed

- **Playback cache diagnostics** — bounded decoded-tile caching now exposes hit,
  miss, entry, and capacity counters and resets them when preview cache is cleared.

## [8.5.0] - 2026-08-16

### Changed

- **Network diagnostics** — NFS/SMB preflight now distinguishes mapped atomic
  operation from unmapped VFS writes and explains how to make remote generation safer.

## [8.4.0] - 2026-08-16

### Changed

- **Resume identity** — completed generation entries now retain media size and
  modification time and are discarded when a file is replaced at the same path.

## [8.3.0] - 2026-08-16

### Changed

- **Generator lifecycle states** — idle generation now exposes explicit queued,
  running, paused, cancelling, failed, and complete states; active ffmpeg work is
  terminated through the existing cancellation callback.

## [8.2.0] - 2026-08-16

### Added

- **Safer skin integration** — merged and replacement XML is parsed before it is
  promoted, skin writes are atomic, and the newest available backup can be restored.

## [8.1.0] - 2026-08-16

### Added

- **Setup wizard** — checks the active skin overlay, Pillow, and ffmpeg, then offers
  the relevant installation actions for missing prerequisites.

## [8.0.0] - 2026-08-16

### Added

- **First-run / stale overlay prompt** — playback asks once per session to install the
  skin snippet when the active overlay is missing or outdated. Show addon status offers
  **Install** in the same cases.
- **Update toast** — service start notifies when the installed overlay is missing or
  stale after an add-on update.

### Changed

- **Settings levels** — TV-facing controls stay on Basic (install snippet, library
  folder, extract mode, status, preview geometry). Prefetch internals, fps-batch
  timeout, CUDA, dovi_tool, and JPEG quality are Standard/Advanced/Expert.
- **Idle generation** — background idle jobs share restart-safe completed-file state
  with library batch, including overwrite-profile separation.
- **Atomic network sidecars** — nfs/smb mounts that map to a local path use the same
  staging + `os.replace` promote as local disks.
- **Script split** — `script_generator.py` is a RunScript dispatcher; batch, skin,
  tools, and status dialogs live in dedicated modules.
- **Service split** — Skippy suppress and seek-hold helpers moved out of `service.py`.
- **Shared path/overlay helpers** — VFS local paths, writable OS mapping, skin-root
  resolution, and overlay revision are centralized.

### Tests

- Coverage for idle resume, mapped-NFS atomic promote, snippet prompts, settings
  levels, and RunScript dispatch.

## [7.5.1] - 2026-08-15

### Fixed

- **Skin snippet result dialog** — install/restore for the current skin (including Arctic
  Zephyr Rounded) now shows the success/failure modal and a toast before scheduling
  `ReloadSkin`. The previous 3-second reload raced the result dialog and often swallowed it.

## [7.5.0] - 2026-08-14

### Added

- **Restart-safe batch generation** — completed media is persisted for the selected
  folder and generation profile, allowing an interrupted batch to resume after reboot.
- **Atomic sidecar generation** — local sidecars are staged and promoted only after
  every tile succeeds, preserving the previous complete sidecar on failure.
- **More accurate diagnostics** — runtime CUDA/Vulkan probes and CoreELEC-aware
  platform policy are now reported alongside ffmpeg capabilities.
- **Simple validation cache** — valid sidecar folders record tile signatures in
  `valid.json`; changed or missing tiles invalidate the cache automatically.
- **Preflight warnings** — batch confirmation warns about network/VFS media and low
  disk space.
- **Expanded batch summaries** — failed filenames and failure reasons are included.

### Tests

- Added coverage for restart state, validation-cache invalidation, and atomic promotion.

## [7.3.5] - 2026-08-02

### Added

- **Generation summaries** — batch runs now report successes, failures, cancellation, elapsed worker time, tiles written, and extraction fallbacks.
- **Validation / repair** — the new category checks the configured sidecar profile for missing, corrupt, incomplete, and incorrectly sized JPEG tiles, then optionally repairs affected media after confirmation.
- **Generator diagnostics** — read-only ffmpeg build, hardware accelerator, and decode-path report, including why unsupported CoreELEC accelerators such as `rkmpp` are not selected.
- **Configurable fps-batch timeout cap** — adjust the continuous decode timeout from 180 to 3600 seconds for different storage and hardware.

### Changed

- **Documentation** — documented all four extraction modes and clarified that Pillow is normally supplied by Kodi/CoreELEC; the add-on only downloads it when unavailable.
- **Test Kodi stubs** — centralized missing `translatePath` and `executebuiltin` behavior so the complete test suite runs outside Kodi.

## [7.3.4] - 2026-08-01

### Changed

- **Fast-seek fallback diagnostics** — per-frame extraction now reports elapsed time and an estimated remaining time for each tile.

### Fixed

- **Safer sticky fallback** — fps-batch is skipped for later tiles only after the per-frame seek fallback successfully produces the complete current tile. Partial or failed fallback results do not permanently change the strategy.

## [7.3.3] - 2026-07-30

### Added

- **Fast seek (weaker devices)** — fourth **Frame extraction mode** that always uses one ffmpeg seek per thumbnail (skips fps-batch). Prefer this on Amlogic/CoreELEC and similar weak hardware, especially 4K or network media.

### Fixed

- **Sticky fps-batch → seek fallback** — if fps-batch times out or yields no frames and per-frame seek is used, remaining tiles on that file skip fps-batch instead of waiting out another timeout.

## [7.3.1] - 2026-07-29

### Fixed

- **Batch Run confirmation dismissed immediately** — after a long scan, the “Generate …?” dialog used Kodi’s default focus on **No**, so Enter/OK cancelled the job. Confirmation now labels **Generate** / **Cancel**, focuses Generate (Kodi 20+), and waits briefly after the scan progress dialog closes so a click cannot fall through.

## [7.3.0] - 2026-07-29

### Added

- **Prefer CUDA / NVDEC (NVIDIA)** — optional setting under Hardware decode. When on and CUDA probes OK, uses NVIDIA NVDEC → `hwdownload` → existing tonemap filters instead of D3D11VA (Windows) or VA-API (Linux). NVIDIA GPUs only; leave off on AMD/Intel.

### Changed

- **Windows HW decode** — dropped preference for D3D11VA→Vulkan (`vk@dx`) zero-copy (not available in current ffmpeg). Default remains **D3D11VA → hwdownload**; enable CUDA for NVDEC on NVIDIA.

## [7.2.3] - 2026-07-29

### Added

- **Windows zero-copy HW decode** — when **Hardware decode (HDR HEVC)** + tone mapping are on, prefer **D3D11VA → Vulkan (`vk@dx`) → libplacebo**; else **D3D11VA → hwdownload**; else software (same tiered model as Linux VA-API).
- **jellyfin-ffmpeg upgrade prompt** — if a legacy **Gyan/BtbN** build is already in the add-on install folder, **Install preview tools** / **Install generator tools** / batch **Run** offer to replace it with jellyfin-ffmpeg instead of only toasting “already installed”.

## [7.2.2] - 2026-07-29

### Added

- **Generator ffmpeg identity logging** — on resolve, logs vendor (`jellyfin-ffmpeg` / `Gyan` / `BtbN` / …), the first `-version` line, and available `-hwaccels` so you can confirm which build is used.

## [7.2.1] - 2026-07-29

### Changed

- **HDR ffmpeg auto-install** — primary download is now [jellyfin-ffmpeg](https://github.com/jellyfin/jellyfin-ffmpeg/releases) **portable** builds (`linux64` / `linuxarm64` / `win64` / `winarm64`, pinned **v8.1.2-2**). Flat archive layout (`ffmpeg` + `ffprobe` at root). On failure, retries legacy **BtbN** (Linux / Win ARM64) or **Gyan full** (Win x64).

## [7.2.0] - 2026-07-29

### Added

- **Linux hardware decode (VA-API + Vulkan)** — **Hardware decode (HDR HEVC)** now works on Linux as well as Windows. Tiered path: prefer zero-copy **VA-API → Vulkan (`vk@va`) → libplacebo**, else **VA-API → hwdownload**, else software. Capability probes log what is missing. Point **Generator ffmpeg path** at jellyfin-ffmpeg or a self-built binary with VA-API (+ Vulkan/libplacebo for zero-copy); optional `TRICKPLAY_VAAPI_DEVICE` overrides `/dev/dri/renderD*`. Windows D3D11VA path unchanged.

### Changed

- Setting label **Windows hardware decode** → **Hardware decode (HDR HEVC)** (same `generator_hw_decode` id).

## [7.1.14] - 2026-07-27

### Fixed

- **Seekbar unlocked immediately after skip** — poll was treating playhead lag vs the skip landing as a “user scrub” and clearing `Skippy.Skipping` right away. Poll now only clears on Video OSD / pause-scrub / SeekNumeric; seek-away clear is only from `onPlayBackSeek` after a 1.5s grace.

## [7.1.13] - 2026-07-27

### Fixed

- **Post-skip seekbar unlock** — skins use Skippy’s `Skippy.Skipping` again. On user scrub (seek away from the skip landing) or Video OSD open, Trickplay clears `Skippy.Skipping` (and any legacy `Trickplay.SuppressAfterSkip`) so the seekbar/thumb can show. Overlay revision **9**.

## [7.1.12] - 2026-07-27

### Fixed

- **Post-skip hide could not be cleared** — while `Skippy.Skipping` was set, user seeks were ignored and the AF3 seekbar stayed locked behind that property. Suppress now records the skip landing seek, clears on any later seek or when Video OSD opens, and installed seekbar visibility should use `Trickplay.SuppressAfterSkip` (not sticky `Skippy.Skipping` alone). Force-reinstall skin snippet if the seekbar still will not appear after a skip.

## [7.1.11] - 2026-07-27

### Fixed

- **Post-skip hide is skip-signal only** — no Skippy toast/dialog detection. Suppress starts when `Skippy.Skipping` rises (real segment skip; requires Skippy **Hide OSD display during skip**), stays until you scrub again or open OSD and focus the seekbar (not a short timer). Skin snippets use `Trickplay.SuppressAfterSkip` (overlay revision **8**).

## [7.1.10] - 2026-07-27

### Fixed

- **Skippy suppress still blocked scrubbing** — hide now stamps only on Skippy’s segment-skip seek (not while the toast sits open), lasts **1.5s**, and clears on any later seek (including +10s relative skips while playing). Previously every seek during the toast re-armed a 5s timer, so play-scrub never restored the thumb.

## [7.1.9] - 2026-07-27

### Fixed

- **Skippy suppress blocked scrubbing** — lingering skip toast no longer refreshes the 5s hide timer every poll (that made hide feel much longer than 5s). User scrubbing (pause-scrub, SeekNumeric, or play-scrub away from the skip landing) clears suppress immediately so the thumb can show again.

## [7.1.8] - 2026-07-27

### Fixed

- **Show timestamp toggle ignored** — the long-lived service kept a stale `xbmcaddon.Addon()` instance, so `show_timestamp=false` in settings never reached preview publish (placement still reserved label height and `ShowTimestamp` stayed on). Settings reads now use a fresh Addon object, `onSettingsChanged` invalidates the cache and re-syncs display props, and disabled timestamp clears `Trickplay.ShowTimestamp` / `PreviewTime`.

## [7.1.7] - 2026-07-27

### Fixed

- **Preview flash after Skippy skip** — service now suppresses the thumb during Skippy segment skips (detects `Skippy.Skipping` and SkipDialog windows, plus a 5s grace). Skin-only hide was not enough: Skippy’s `signal_skipping_for_skins` defaults to off, and Trickplay was treating the skip seek as a normal scrub. AF3/AF2 overlay groups also require empty `Skippy.Skipping`. Overlay revision **7**.

## [7.1.6] - 2026-07-27

### Fixed

- **Preview stuck / missing during play scrub** — reverted Fuse/Estuary/Home skin snippets from dynamic `$INFO` Left/Top (Kodi does not apply those on many skins) back to **PreviewSlot slide animations**. Slot count increased **51 → 101** for finer tracking. During fast scrub the last/cached thumb stays visible so the overlay **moves on every seek** instead of waiting until scrub settles. Overlay revision **6** — reinstall skin snippet.

## [7.1.5] - 2026-07-27

### Changed

- **Preview thumb tracks the seek marker continuously** — `Trickplay.PreviewLeft` / `PreviewLeftWide` / `PreviewTop` now follow the scrub position second-by-second instead of jumping only when the discrete `PreviewSlot` (0–50) changes. Skin snippets bind `$INFO[…PreviewLeft…]` (overlay revision **5**); reinstall or let auto-refresh update installed overlays.

## [7.1.4] - 2026-07-24

### Fixed

- **SDR MJPEG encode on modern ffmpeg** — JPEG thumb extraction always uses `-strict unofficial` + `yuvj420p` (not only when HDR tonemap runs). Fixes last-tile failures like `Non full-range YUV is non-standard` on 1-frame fps batches for H.264 remuxes.

## [7.1.3] - 2026-07-22

### Removed

- **Estuary (stock) skin support** — stock Kodi Estuary (`skin.estuary`) cannot be edited, so the dedicated snippet, skin profile, and settings option are removed. Use **Estuary Mod v2** (or another editable skin) for trickplay overlays.

## [7.1.2] - 2026-07-22

### Fixed

- **Fast (batch seeks) + Windows HW decode** — multi-input batch seeks is also skipped when **D3D11VA** is active (10-bit HEVC without HDR tags, e.g. NF WEBRip Main10). Same `yuv420p10le` filter-graph failure and ~16 minute chunk timeouts as the HDR path; uses **Fast** immediately instead.

## [7.1.1] - 2026-07-21

### Fixed

- **Fast (batch seeks) + HDR/DV** — when tone mapping is active, multi-input batch seeks is skipped immediately and **Fast** is used instead. Avoids ~16 minute per-chunk timeouts from broken libplacebo/zscale + 10-bit filter graphs before falling back frame-by-frame.

## [7.1.0] - 2026-07-20

### Changed

- **Frame extraction: Fast (batch seeks)** — renames former **Experimental** mode. Setting value is now `batch_seeks` (legacy `experimental` still loads as batch seeks). Hardened: ffmpeg multi-seek chunks capped at **8** inputs, **per-frame Fast fallback** on misses, and **full-tile Fast retry** if a mid-file tile is still incomplete. Optional PyAV remains for local SDR when installed. Biggest speed gains on local SDR files.

## [7.0.0] - 2026-07-20

### Changed

- **RAM-first scrub crops** — on cache miss, cells are cropped from the in-memory decoded sprite and written to a ping-pong live JPEG under `special://temp/service.trickplay/live/` for immediate skin display. The durable thumb-cache copy is filled asynchronously afterward.
- **Decoded sprite LRU** — raised from 2 to **8** tiles (~33 MiB → ~132 MiB peak for default Jellyfin `320` / 10×10 sprites), so scrubbing across more tile boundaries reuses RAM instead of re-decoding.

## [6.5.1] - 2026-07-20

### Fixed

- **NFS/SMB generation on Windows** — library scans and sidecar paths no longer use `os.path.join` on `nfs://` / `smb://` URLs, which injected `\` (e.g. `February\Season 1\…`) and broke VFS reads (`write to closed file`, empty pipe probes, “Could not determine duration”). Paths are now joined and normalized with forward slashes.

## [6.5.0] - 2026-07-20

### Added

- **European language localizations** — full settings/dialog translations for French (`fr_fr`), Dutch (`nl_nl`), German (`de_de`), Spanish (`es_es`), Italian (`it_it`), Greek (`el_gr`), Norwegian Bokmål (`nb_no`), Danish (`da_dk`), and Swedish (`sv_se`). English remains the default fallback.

## [6.4.5] - 2026-07-19

### Fixed

- **HLG HDR generation** — HLG (`arib-std-b67`) tonemap no longer requests `bt2390`, which stock ffmpeg `tonemap` does not support (only libplacebo/jellyfin-ffmpeg forks do). Uses `hable` like HDR10 so batch generation no longer aborts immediately on HLG WEB releases.
- **Batch retry dialog buttons** — failed-file retry prompt now shows **Retry** / **Cancel** instead of reusing the Install / Continue without labels from the tools installer.

## [6.4.4] - 2026-07-18

### Added

- **Clear preview cache** — settings action (with confirm) deletes cropped seek thumbs under addon_data and local sprite tile copies in temp. Does not touch media `.trickplay` sidecars or generator workdirs. Shows a toast with file counts and sizes.

## [6.4.3] - 2026-07-18

### Fixed

- **Playback warm radius** — during-playback playhead follow now uses the capped `playback_warm_radius` (min of scrub radius and 5) instead of the full scrub radius, so a large prefetch radius no longer floods the queue while watching.

## [6.4.2] - 2026-07-18

### Added

- **Cached thumb JPEG quality** — setting (50–95, default 90) controls Pillow compression for cropped preview JPEGs on disk. Lower values write/load faster; does not change source trickplay sprites.

## [6.4.1] - 2026-07-18

### Changed

- **Background sprite tile copies** — after trickplay loads, all sprite JPGs are copied to local temp on a dedicated worker (playhead tile first). Scrubbing re-prioritizes the current/next tile without cancelling the copy queue on fast scrub.

## [6.4.0] - 2026-07-18

### Changed

- **Batch tile prefetch crops** — the prefetch worker drains queued cells for the same sprite JPG and crops them in one Pillow decode pass (`crop_tile_cells_batch`), instead of open/decode per cell.

## [6.3.9] - 2026-07-18

### Changed

- **Faster same-tile scrub crops** — decoded sprite JPGs are kept in memory (up to 2 tiles, LRU) so Pillow no longer re-decodes the full tile for every cell crop during scrub/prefetch.

## [6.3.8] - 2026-07-17

### Changed

- **Skin install result modal** — restored the pre-6.3.5 flow: after install/restore, show `Dialog().ok` with the per-skin summary immediately (the path that actually displayed the modal). Deferred AlarmClock/`skin_result` approaches removed. `ReloadSkin` is armed during install again, so the old OK-vs-reload race may return.

## [6.3.7] - 2026-07-17

### Fixed

- **Skin install result modal never appearing** — a second `Dialog().ok` inside the settings `RunScript` action is often swallowed on Windows after the confirm dialog. Results are now saved and shown ~1s later via a deferred `RunScript(skin_result)` (plus an immediate notification). `ReloadSkin` still waits until that result dialog is dismissed.

## [6.3.6] - 2026-07-17

### Fixed

- **Skin install result dialog** — after Install, the per-skin ok/failed/skipped summary is shown again more reliably (short pause after the progress dialog so the result modal is not swallowed), plus a notification with the result counts. `ReloadSkin` still waits until you dismiss that summary.

## [6.3.5] - 2026-07-17

### Fixed

- **Skin snippet install crash on summary OK** — `ReloadSkin` was armed during install (2s alarm) while the result OK dialog was still open, so dismissing OK raced the reload. Reload is now scheduled only after the summary dialog closes (3s defer).

## [6.3.4] - 2026-07-17

### Fixed

- **Generator fps-batch hang on corrupt H.264/MKV** — tile timeout was `duration×3+60` (~51 min for a 1000s tile). Cap is now **15 minutes** (floor 3 min), with `+discardcorrupt`, and empty/failed fps batch falls back to per-frame fast seek instead of aborting the file immediately.

## [6.3.3] - 2026-07-16

### Fixed

- **First scrub thumb latency on NFS** — prefetch was running, but idle whole-tile crops flooded the queue and a single large seek jump was treated as “fast scrub” (skipping cache/eager crop). High-priority neighbor work now goes to the front of the queue, scrub yields drop idle backlog before the foreground crop, and a lone big jump uses cache/eager crop again. Idle tile enqueue cap reduced (100 → 24).

## [6.3.2] - 2026-07-16

### Fixed

- **Arctic Zephyr Rounded stub false positive** — DialogSeekBar that hosts the seek bar via `<include>` (no other top-level `<control>` besides the trickplay overlay) is no longer skipped as “empty / seek bar elsewhere”.
- **Disabled / unlisted skins (e.g. Plextuary)** — skin folder is resolved from the addons directory when `xbmcaddon.Addon()` fails; install-all merges JSON-RPC results with a filesystem scan so skins missing from Settings → Interface → Skin still appear.

## [6.3.1] - 2026-07-16

### Fixed

- **Addon status always STALE on Arctic Fuse / Estuary Mod v2** — those replace snippets correctly use `Window.Property(Trickplay.*)` on DialogSeekBar; the stale checker no longer treats that as a legacy Home-property overlay.
- **Install skin snippet (all skins)** — JSON-RPC now queries `xbmc.gui.skin` with `enabled=all` (was wrong type + `enabled=false`, which only returned disabled skins). Falls back to scanning the addons folder for `skin.*` packages when RPC returns nothing.

## [6.3.0] - 2026-07-16

### Added

- **Show addon status** — settings button reports active skin, profile, snippet target (`DialogSeekBar.xml` / Bello `VideoFullScreen.xml`), snippet state (missing / stale / OK), Pillow, and ffmpeg.
- **Force reinstall skin snippet** — reinstalls the overlay even when the installer would otherwise skip as `already_installed`.

### Fixed

- **Stale overlay detection for all snippets** — replace-mode skins (Estuary Mod v2, Arctic Fuse 2/3) and merge snippets now share `trickplay-overlay-rev:4`. Missing revision or Skippy visibility marks the install as stale so **Install skin snippet** updates instead of skipping.
- **Skin install messaging** — help text and service warnings mention Bello’s `VideoFullScreen.xml` target; install plan tags stale overlays as `stale_overlay`.

### Changed

- Removed leftover sprite-atlas setting strings (atlas preview was removed earlier; Pillow is always required for crops).

## [6.2.1] - 2026-07-16

### Added

- **Bello Skippy seek OSD suppression** — **Install skin snippet** now patches Bello’s native seek OSD groups in `VideoFullScreen.xml` (center `osd_controls_bg` box and both `SeekBarSimple` bars) with `Skippy.Skipping` visibility, not just the trickplay overlay.

## [6.2.0] - 2026-07-16

### Added

- **Skippy skip OSD suppression** — skin snippets and **Install skin snippet** now add `<visible>String.IsEmpty(Window(Home).Property(Skippy.Skipping))</visible>` so the seek bar stays hidden during [service.skippy](https://github.com/Skippy-McSkipface/service.skippy) auto-skips. Merge installs inject it on the host `DialogSeekBar.xml` window; replace snippets (Estuary Mod v2, Arctic Fuse 2/3) include it at window level. Overlay revision bumped to `trickplay-overlay-rev:3`; reinstall when upgrading from older snippets.

## [6.1.9] - 2026-07-05

### Fixed

- **Bingie preview position** — removed the manual `top=550/570` override; preview now uses seek-bar geometry (`top=717`, aligned above `SeekBar_Bingie`).
- **Skin snippet reinstall** — legacy dynamic `$INFO[Window.Property(Trickplay.PreviewLeft)]` overlays and missing `trickplay-overlay-rev:2` marker are treated as stale, so **Install skin snippet** updates them instead of reporting `already_installed`.

## [6.1.8] - 2026-07-04

### Changed

- **Bingie preview position** — lowered 20px (`top` 550 → 570). Re-install the Bingie skin snippet to apply.

## [6.1.7] - 2026-07-04

### Fixed

- **Bingie preview (install + position)** — installer now treats legacy `Window.Property(Trickplay.*)` overlays as stale and reinstalls the Home-property / slot-slide snippet. Preview anchor raised to **top=550** (above the 290px Bingie OSD bottom panel). **Re-install the skin snippet** after upgrading; your `DialogSeekBar.xml` still had the old dynamic overlay.

## [6.1.6] - 2026-07-04

### Fixed

- **Bingie preview** — snippet now uses `Window(Home).Property` bindings, fixed anchor **(384, 717)**, and slot-slide group **94100** (Bingie OSD bar geometry).

### Tested skins

The following skins have been tested with trickplay preview while scrubbing:

- Aeon Nox SiLVO
- Arctic Fuse 2
- Arctic Fuse 3
- Arctic Horizon 2
- Arctic Zephyr 2 Resurrection
- Arctic Zephyr Rounded
- Bingie
- Estuary Mod v2

## [6.1.5] - 2026-07-04

### Fixed

- **Arctic Zephyr 2 Resurrection preview position** — raised 80px (`top` 820 → 740) so the thumbnail sits above `OSD_Progress_Text` and the progress bar.

## [6.1.4] - 2026-07-04

### Fixed

- **Aeon Nox SiLVO preview** — snippet uses `Window(Home).Property` bindings, fixed anchor **(0, 799)**, slot-slide group **94100**, and **-90px** lift when video OSD is open (matches `DefaultSeekbar`). Preview session is no longer cleared when VideoOSD opens on skins where the seek bar stays visible alongside the OSD.

## [6.1.3] - 2026-07-04

### Fixed

- **Arctic Horizon, Arctic Zephyr, Arctic Zephyr 2 Resurrection previews** — snippets now use `Window(Home).Property` bindings, fixed anchors, and slot-slide group **94100** (same approach as Arctic Horizon 2 / Arctic Zephyr Rounded). Horizon skins include **+80px** compact-seekbar slide; Zephyr / Z2 Resurrection use fixed placement without dynamic `$INFO` coordinates.

## [6.1.2] - 2026-07-04

### Fixed

- **Arctic Horizon 2 preview** — snippet now uses `Window(Home).Property` bindings, fixed anchor **(20, 480)**, and slot-slide group **94100** (same approach as Arctic Zephyr Rounded). Includes **+80px** vertical slide when the compact seek bar is shown, matching `Animation_OSD_Seekbar_NoCodecs`. **AH2.1 Arizen** updated the same way.

## [6.1.1] - 2026-07-04

### Fixed

- **Bello preview flash** — seek polling now treats Bello's fullscreen center seek OSD as seek UI (was only DialogSeekBar / VideoOSD), so the preview session is no longer cleared every poll tick.
- **Bello preview position** — raised 10px (`top` 570 → 560).

## [6.1.0] - 2026-07-04

### Added

- **Bello 10 seek OSD preview** — new `VideoFullScreen-skin.bello.xml` snippet merges into `VideoFullScreen.xml` (not the empty `DialogSeekBar.xml`). Fixed preview at **478, 570** (320×180) directly below the center seek box, visible with the same conditions as Bello's seek OSD. Uses `Window(Home).Property(Trickplay.*)` bindings.
- **Installer target XML** — skin snippet registry can specify merge target (`VideoFullScreen.xml` for Bello). Stub `DialogSeekBar` overlays are cleaned up after Bello install.

### Changed

- **Bello skin profile** — seek UI detection uses fullscreen center seek OSD visibility; geometry updated for 720p center box layout.

## [6.0.9] - 2026-07-04

### Fixed

- **Skin snippet install crash (Windows)** — `ReloadSkin()` is deferred by 2 seconds via `AlarmClock` instead of running immediately from the Python installer (avoids Kodi crashes in add-on settings).
- **Stub DialogSeekBar skins** — skins whose `DialogSeekBar.xml` has no seek bar controls (e.g. Bello) are skipped and no longer trigger a skin reload.

## [6.0.8] - 2026-07-04

### Fixed

- **Arctic Zephyr Rounded full video OSD** — preview group **94100** slides up 74px when `videoosd` is open, matching the skin's seek bar shift so playback controls no longer overlap the thumbnail.

## [6.0.7] - 2026-07-04

### Fixed

- **Arctic Zephyr Rounded preview (rendering)** — snippet now uses fixed anchor coordinates and slot-slide group **94100** (Estuary-style) instead of dynamic `$INFO` left/top/width, which Kodi was not applying on this skin. Preview textures use `special://profile/` paths for reliable loading on Windows.

## [6.0.6] - 2026-07-04

### Fixed

- **Arctic Zephyr Rounded preview** — snippet now binds trickplay properties on `Window(Home)` (this skin's OSD pattern); `DialogSeekBar` reload no longer leaves empty coordinates. Stale overlays are detected and offered for reinstall.
- **Preview during seek** — opening full video OSD while `Player.Seeking` no longer clears the preview session.
- **Windows texture paths** — preview image paths use forward slashes for Kodi skin textures.

## [6.0.5] - 2026-07-04

### Fixed

- **Prefetch during playback** — `schedule_playhead_follow()` no longer raises `NameError: lookup is not defined` (broke seek polling and playback prefetch).
- **Skin profile matching** — longest skin-id prefix wins (e.g. `skin.arctic.zephyr.rounded` no longer resolves as stock Arctic Zephyr).
- **Arctic Zephyr Rounded snippet** — higher `zorder`, skin-native `InfoNetflix` font and `progress/progress-bg.png` border texture.

## [6.0.4] - 2026-05-22

### Added

- **Skin snippets** for Arctic Fuse 2, Arctic Horizon 2, Arctic Horizon 2.1 Arizen, Arctic Zephyr 2 Resurrection, Arctic Zephyr Rounded, Bello, and Bingie — each with matching skin profile auto-detection and settings override.
- **DialogSeekBar** install targets: `DialogSeekBar-skin.arctic.fuse.2.xml` (replace, slot slides), `DialogSeekBar-skin.arctic.horizon.2.xml`, `DialogSeekBar-skin.arctic.horizon.2.1.arizen.xml`, `DialogSeekBar-skin.arctic.zephyr.2.resurrection.xml`, `DialogSeekBar-skin.arctic.zephyr.rounded.xml`, and `DialogSeekBar-skin.bingie.xml` (merge overlays). **Bello** uses `VideoFullScreen-skin.bello.xml` → `VideoFullScreen.xml`.

### Changed

- **Arctic Horizon 2.1 Arizen** — separate snippet and skin profile from Arctic Horizon 2 (no longer shares `DialogSeekBar-skin.arctic.horizon.2.xml`).

## [6.0.3] - 2026-06-29

### Added

- **Prefetch during playback** — while a video plays, the service now keeps the configured prefetch radius (thumb indices, symmetric both directions) warm around the **current playhead**, not only at load time or when the seek bar opens. Seeks force an immediate re-warm. Setting: **Prefetch during playback** (default on).

### Changed

- **Prefetch on start** — uses the full prefetch radius (not a separate smaller cap).
- **Prefetch radius** help text clarifies indices vs sprite tile files.

## [6.0.2] - 2026-06-29

### Removed

- **Sprite atlas preview** — Kodi's skin engine does not clip child image controls inside a parent group the way CSS sprite sheets do (confirmed on CoreELEC / Arctic Fuse 3: negative offsets show the full tile JPG, not a single cell). The experimental atlas path, settings, and skin viewport groups are removed. Previews use **Pillow per-cell crops** (`Trickplay.PreviewImage`) only, as in 5.2.x.

### Changed

- **Skin snippets** — reverted to crop-only `PreviewImage` controls. **Re-install the skin snippet** after upgrading (current skin or all skins).

## [6.0.1] - 2026-06-29

### Fixed

- **Sprite atlas preview showed nothing** — `Trickplay.TileImage` was overwritten with the raw `nfs://` tile path on every scrub; Kodi cannot texture that in DialogSeekBar. TileImage now always uses the local temp copy. Sprite atlas is **off by default** again (5.2-style crop path).
- **Crop fallback** — when sprite atlas is enabled, optional **Sprite atlas crop fallback** (default on) also publishes `Trickplay.PreviewImage` so previews work with older skin snippets and when atlas clipping fails on a device.
- **Skin snippets** — dual atlas + crop controls; outer visibility accepts either `PreviewImage` or `TileImage`.

## [6.0.0] - 2026-05-22

### Added

- **Sprite atlas preview (YouTube-style)** — the skin displays a viewport into the Jellyfin sprite sheet JPG (`Trickplay.TileImage` + offset properties) instead of per-cell Pillow crops. Scrubbing within the same tile updates only window properties (no new JPEG per frame).
- **Setting: Sprite atlas preview** — under Preview adjustment; disable to restore 5.2-style per-cell crop (`Trickplay.PreviewImage`).

### Changed

- **Skin snippets** — all `DialogSeekBar-*.xml` reference files use a clipping group + negative offset into the sprite sheet. **Re-install the skin snippet** after upgrading (current skin or all skins).
- **Prefetch** — in atlas mode, warms local copies of sprite tile JPGs instead of pre-cropping cells.
- **Pillow** — no longer required for preview display when sprite atlas is enabled (still used for sidecar dimension probing and crop fallback).

## [5.2.0] - 2026-05-22

### Added

- **Restore skin snippet** — **Restore skin snippet (current skin)** and **(all skins)** under Preview tools. Restores `DialogSeekBar.xml` from `DialogSeekBar.xml.bak` when a backup exists.
- **Split install actions** — **Install Pillow (preview)**, **Install generator tools (ffmpeg)**, and **Install preview tools (all)** as separate Preview tools buttons.
- **Skin snippet installer** — skips paths that already contain the trickplay overlay; writable preflight; progress bar for multi-path install/restore; inactive-skin note after install-all; full `DialogSeekBar.xml` paths in debug log; JSON-RPC skin list fallback warning.
- **Skin snippet registry** — known skins and snippet files centralized in `skin_profiles.py` (`SKIN_SNIPPET_REGISTRY`). Unknown skins use universal merge only (no full-file replace).
- **Batch retry** — after batch generation completes, offers to retry failed files.
- **Generator temp cleanup** — generation lock file and minimum age (1 hour) so active or recent jobs are not deleted on service start or add-on update.
- **Service hint** — one-time warning per session when trickplay loads but the active skin has no preview controls installed.
- **Unit tests** — pure-text merge/remove helpers in `tests/test_skin_snippet_installer.py`.

### Changed

- **Text-based skin merge** — overlay install preserves original `DialogSeekBar.xml` formatting instead of re-serializing via ElementTree.
- **Install summary** — reports ok, failed, skipped (already installed), and skin count.

### Fixed

- **Pillow debug log** — when debug logging is on, logs `PIL.__file__` after Pillow loads.
- **README** — Arctic Fuse 3 snippet documents groups **94090**, **94100**, and **94103**.

## [5.1.1] - 2026-06-21

### Fixed

- **Windows / Kodi install startup** — `pillow_installer` no longer calls `xbmcaddon.Addon()` at import time (unused, and failed with “Unknown addon id” while the add-on was still registering). Service, script, and preview entry points now pass `"service.trickplay"` explicitly.
- **Python 3.8 compatibility** — `ThumbCacheKey` used a runtime `tuple[...]` alias that fails on Kodi’s embedded Python before 3.9; switched to `typing.Tuple`.

## [5.1.0] - 2026-05-22

### Added

- **Install skin snippet** settings actions — **Install skin snippet (current skin)** and **Install skin snippet (all skins)** under Preview tools. Lists installed skins and resolved `DialogSeekBar.xml` paths, backs up each file to `DialogSeekBar.xml.bak`, then merges overlay group 94090 or replaces the full file for Estuary Mod v2 / Arctic Fuse 3. Reloads the active skin after install.

## [5.0.1] - 2026-05-22

### Fixed

- **Fast backward scrub preview slideshow** — cached thumbs no longer publish immediately during fast scrub (same coalescing as forward). Scrub burst detection keeps coalescing active across stepped seeks (~250 ms gap) so one-thumb-at-a-time backward scrub does not flash every cached frame.

## [5.0.0] - 2026-05-22

### Fixed

- **Install preview tools** settings action used `RunScript($ID,install_tools)`; Kodi did not expand `$ID`, so the button did nothing (`ExecuteAsync - Not executing non-existing script $ID`). Now uses `RunScript(service.trickplay,install_tools)`.
- **Install preview tools** crashed with `'GeneratorSettings' object has no attribute 'generator_enabled'` — use `settings.enabled` instead.

### Changed

- **Preview cropping uses Pillow** — playback/scrub preview tiles are cropped with Pillow (JPEG sprite cells). ffmpeg/ffprobe are no longer required for preview display.
- **Install preview tools** — downloads Pillow into add-on site-packages for preview. ffmpeg/HDR/dovi_tool installs run only when the generator is enabled or HDR tone mapping is on (batch **Run** still prompts for generator ffmpeg as before).

## [4.3.0] - 2026-05-22

### Added

- **Skin profiles** — auto-detect and manual override for **Estuary (stock)**, **Aeon Nox SiLVO**, **Arctic Zephyr**, and **Arctic Horizon** (geometry from upstream skin repos on GitHub).
- **Universal skin snippet** — `DialogSeekBar-universal-dynamic.xml` positions the preview via `Trickplay.PreviewLeft/Top/Width/Height` (no per-slot slide table). Per-skin copies with merge notes for Estuary, Aeon Nox SiLVO, Arctic Zephyr, and Arctic Horizon.
- **Preview adjustment** settings category — preview scale (%), horizontal/vertical offset (px), hold time, timestamp, opacity, and **Show preview when play controls focused** (keeps preview visible while the OSD play/pause row has focus).

### Removed

- Legacy unused `TrickplayPreview.xml` overlay window under `resources/skins/Default/` (preview is skin-snippet + window properties only).

## [4.2.0] - 2026-05-22

### Fixed

- **Duration probe for generation** — thumb count now uses the shorter of container `format=duration` and the primary video stream (stream `duration`, `DURATION` tag, or `NUMBER_OF_FRAMES` / frame rate). Fixes NF WEB-DL and similar files where the container is longer than decodable video (e.g. hybrid DV/HDR with ~45 s audio tail).
- **Tail tile tolerance** — an empty or failed **last** tile no longer fails the whole job when at least one prior tile was written; empty tiles in the middle still fail. Partial last tiles are kept.

## [4.1.1] - 2026-05-22

### Added

- **Batch Run scan progress** — after confirming the library folder, a cancellable progress dialog shows while the tree is scanned and sidecars are checked (“Calculating number of videos…”), instead of a long UI freeze before the start-generation prompt.

## [4.1.0] - 2026-05-22

### Added

- **Orphaned generator temp cleanup** — on service start and at the beginning of each generation job, removes leftover files under `special://temp/service.trickplay/generate/` and `.../dovi/` from crashes or hard kills (normal completion already deletes these in `finally`). Playback sprite copies in the parent temp folder are kept.

## [4.0.8] - 2026-05-22

### Added

- **Install preview tools** — new action at the top of add-on settings downloads ffmpeg/ffprobe (and optional HDR extras: zscale/libplacebo, Vulkan loader on Windows, dovi_tool) without enabling the generator or batch **Run**. Uses the same install location as batch auto-install.
- **First-playback ffmpeg prompt** — when trickplay sidecars load but no ffmpeg is found for preview cropping, the service offers a one-time yes/no install dialog per Kodi session (decline with “Continue without” to skip until restart).

### Changed

- **Generator ffmpeg path** is always visible in settings (not hidden when the generator is off) so preview-only users can point at a custom install.
- **Batch Run** now offers base ffmpeg download when missing even if HDR tone mapping is off (same pinned BtbN/Gyan builds as Install preview tools).
- Log messages for missing ffmpeg mention **Install preview tools** instead of batch Run only.

## [4.0.7] - 2026-05-22

### Fixed

- **Windows hardware decode on non-HEVC / SDR:** D3D11VA is now enabled only when ffprobe reports **HEVC** with 10-bit and/or HDR/DV signals. AVC and 8-bit SDR HEVC skip HW decode entirely (no per-frame failed HW attempt + software retry).
- **Windows HW decode per-file fallback:** after the first hardware decode failure on a file, HW decode is disabled for the remainder of that job (logged once; ffmpeg stderr included when debug logging is on).
- **Fast extract on long-interval SDR:** intervals above 5 s now use a single **fps batch** decode per tile on SDR software-only paths (no tonemap, no active HW decode), instead of one ffmpeg seek per thumb — much faster on large Blu-ray remuxes.

### Changed

- **Docs:** Windows hardware decode help/README clarify it targets **4K HDR/DV HEVC**, not general HW acceleration — 1080p H.264 SDR is faster on software decode (+ fps-batch) in testing.

## [4.0.6] - 2026-05-22

### Fixed

- **Arctic Fuse 3 full OSD preview placement:** full OSD now uses `Trickplay.PreviewLayout=center` — same height as minimal seek-bar mode (just above the bar at **670**), horizontally centered on the seek bar (**800**), without slot tracking. Replaces the previous top-of-screen placement (which could appear stuck at the top-left when dynamic `$INFO` coordinates did not apply).

## [4.0.5] - 2026-05-22

### Fixed

- **Arctic Fuse 3 full OSD:** preview moves to a dedicated group when the full video OSD is open (plot, end time, etc.), via `Trickplay.PreviewLayout` and group **94103** in the AF3 `DialogSeekBar` snippet. Compact seek-bar mode keeps group **94100** with slot slide animations.
- **Scrub lag / stale preview queue:** a single coalesced crop worker now drops intermediate frames during fast scrubbing (updates faster than ~120 ms or thumb index jumps ≥3). Synchronous eager crops are skipped while scrubbing is backed up; prefetch is cancelled during fast scrub so foreground crops are not starved. The latest seek target wins when you stop scrubbing.

## [4.0.4] - 2026-05-22

### Fixed

- **Sidecar loading on SMB and OS-mounted shares:** playback preview now tries every usable path form for the playing file — Kodi VFS URL (`nfs://`, `smb://`), `translatePath` result, and OS bind mount (e.g. `/storage/remote-shares/…` on CoreELEC). Directory and tile listing prefer the OS mount when available, then fall back to `xbmcvfs.listdir`. Fixes preview when Jellyfin sidecars are visible on disk but not via the VFS URL alone.

## [4.0.3] - 2026-05-22

### Fixed

- **Playback preview broken on Kodi/CoreELEC (NFS):** removed all uses of **`xbmcvfs.isdir`** / **`xbmcvfs.isfile`** — they do not exist on Kodi's Python API and caused `Trickplay load failed: module 'xbmcvfs' has no attribute 'isdir'`. New **`vfs_paths.py`** uses `os.path` on translated paths and **`xbmcvfs.listdir`** for `nfs://` directories.

## [4.0.2] - 2026-05-22

### Removed

- **tools.ffmpeg-tools** — all code paths that searched the legacy Kodi add-on are gone. Generation and playback use **Generator ffmpeg path**, auto-installed **BtbN / Gyan** builds, or system `PATH` only (same as 3.3.0).

## [4.0.1] - 2026-05-22

### Fixed

- **Playback preview regression (3.3.0+):** thumb cropping called non-existent `load_generator_settings()` so **Generator ffmpeg path** was never applied during scrubbing. Restored **`read_generator_settings()`**.
- **Diagnostics:** log **`Preview unavailable during playback: …`** once per cause when the seek bar is open but trickplay cannot run; warn at load time if ffmpeg is missing for cropping.

## [4.0.0] - 2026-05-22

### Added

- **Windows hardware decode** — optional generator setting **Windows hardware decode** (default off). On Windows, uses D3D11VA GPU HEVC decode with `hwdownload,format=p010le` before zscale or libplacebo (Vulkan) tonemapping (~25–30% faster on 4K HDR/Dolby Vision in testing). Skipped for VFS stream paths. Falls back to software decode automatically when a frame or batch extract fails. No effect on Linux or CoreELEC.

## [3.3.0] - 2026-06-14

### Changed

- **Removed `tools.ffmpeg-tools` dependency** — generation and playback preview cropping both use the same ffmpeg resolution: custom **Generator ffmpeg path**, auto-installed **`/storage/.kodi/system/ffmpeg/`** (Linux/CoreELEC) or **`addon_data/.../system/ffmpeg/`** (Windows), then system `PATH`. Run batch **Run** once with HDR tone mapping to install ffmpeg if needed.

## [3.2.0] - 2026-06-14

### Changed

- **dovi_tool auto-install** now installs beside generator ffmpeg (**`/storage/.kodi/system/ffmpeg/bin/dovi_tool`** on CoreELEC/Linux, **`addon_data/.../system/ffmpeg/bin/dovi_tool.exe`** on Windows) instead of the add-on package root. Survives add-on updates like the HDR ffmpeg install. Legacy add-on-root copies are migrated automatically on first detection.

## [3.1.11] - 2026-06-14

### Fixed

- **Fast extract progress logging:** log each thumb as it is written during per-frame fast seek (`Tile 1/3: thumb 42/100 at 378.0s`). Reverts the 3.1.10 batch-threshold / libplacebo batch changes — fast seek + libplacebo was already working well for Jellyfin-style intervals.

## [3.1.10] - 2026-06-14

### Fixed

- *(Superseded by 3.1.11 — batch-threshold change reverted; logging fix only.)*

## [3.1.9] - 2026-06-14

### Fixed

- Batch generation crash: `creationflags` was accidentally passed to `resolve_thumb_filter_context()` after the 3.1.8 hide-window change (only subprocess calls should get it).

## [3.1.8] - 2026-06-14

### Fixed

- **Windows:** ffmpeg/ffprobe/dovi_tool subprocesses now use `CREATE_NO_WINDOW` so batch generation and playback cropping no longer flash a **cmd.exe** window on every frame extract or probe.

## [3.1.7] - 2026-06-14

### Fixed

- **libplacebo filter chain** for ffmpeg 8.x (Gyan full / BtbN with libplacebo): replaced removed options **`desaturation`** and **`color_mapping`** with **`gamut_mode=perceptual`**. Fixes `Option not found` failures on Dolby Vision Profile 5 generation.

## [3.1.6] - 2026-06-14

### Fixed

- **libplacebo filter detection** on ffmpeg 8.x: Gyan full builds list `libplacebo` as **`N->V`**, not **`V->V`**. Install verification and Dolby Vision routing no longer falsely report “lacks libplacebo” when the filter is present.

## [3.1.5] - 2026-05-22

### Fixed

- **Windows HDR ffmpeg auto-install** now downloads [Gyan **ffmpeg-8.1.1-full_build.zip**](https://github.com/GyanD/codexffmpeg/releases/download/8.1.1/ffmpeg-8.1.1-full_build.zip) from GitHub (static **zscale + libplacebo**). Reverts the 3.1.4 essentials fallback — essentials lacks libplacebo and cannot handle Dolby Vision Profile 5 via Vulkan.

## [3.1.4] - 2026-05-22

### Fixed

- **Windows HDR ffmpeg auto-install** URL corrected to Gyan **ffmpeg-release-essentials.zip** *(superseded by 3.1.5 — essentials is not suitable for libplacebo / DV Profile 5)*.

## [3.1.3] - 2026-06-14

### Changed

- **Windows HDR ffmpeg auto-install** now downloads Gyan **ffmpeg-release-full.zip** instead of BtbN **gpl-8.1**. *(URL was invalid — fixed in 3.1.4.)*
- Windows x64 with Vulkan re-requires **libplacebo** in the installed ffmpeg for “fully HDR capable” checks; Linux / CoreELEC still uses BtbN **gpl-8.1** (zscale + **dovi_tool** for Profile 5). *(Relaxed in 3.1.4 for Gyan essentials.)*

## [3.1.2] - 2026-06-14

### Fixed

- **Dolby Vision Profile 5** frame extraction after **dovi_tool** convert: **`converted.hevc`** is an elementary stream with no seek index — per-tile **fast seek** (`-ss` before `-i`) failed silently on Windows. Generation now uses a **single sequential decode** with **`-f hevc`** and the **fps** batch filter (same strategy as VFS pipe extract), then assembles tiles as before.

## [3.1.1] - 2026-06-13

### Fixed

- **Windows HDR ffmpeg install** no longer fails verification when **Vulkan** is available but the BtbN **gpl-8.1** build has **zscale** only (no **libplacebo** filter). Install is accepted; HDR10 and DV P7/P8 use zscale, Profile 5 uses **dovi_tool + zscale** (same as no-Vulkan hosts). Re-run **Run** is not prompted again after a successful zscale install.
- Wrong-architecture **dovi_tool** binaries in the add-on folder are removed automatically so batch **Run** can offer the correct Windows download.
- Windows HDR ffmpeg install now **bundles `vulkan-1.dll`** into `bin/` (copied from System32 when present) even when Vulkan already works system-wide, so the folder is self-contained.

## [3.1.0] - 2026-05-22

### Added

- **Windows Vulkan loader install** — when HDR tonemapping is enabled and ffmpeg cannot init Vulkan, batch **Run** offers to install **`vulkan-1.dll`** beside the generator ffmpeg (copies from `%SystemRoot%\System32` when present, otherwise downloads the NuGet **Vulkan.Loader** redistributable). Dolby Vision via **libplacebo** needs this on many Windows Kodi setups. Silent install is also attempted immediately after HDR ffmpeg auto-install.

### Fixed

- **Windows HDR ffmpeg install folder** — auto-install and default generator ffmpeg resolution now use **`special://profile/addon_data/service.trickplay/system/ffmpeg/`** on Windows Kodi instead of the Linux-only **`/storage/.kodi/system/ffmpeg/`** path (which broke download prompts and left ffmpeg undetected on PC).
- Windows generator subprocesses resolve **`ffmpeg.exe` / `ffprobe.exe`**, prepend the install **`bin/`** (and **`lib/`** when present) plus **System32** to **`PATH`**, so BtbN **gpl-8.1** builds and the bundled Vulkan loader load correctly.

## [3.0.19] - 2026-05-22

### Added

- Generator setting **Skip Dolby Vision Profile 5** (`generator_skip_dv_profile_5`): when HDR tonemapping is enabled, batch scans skip Profile 5 files (web `.DV.` releases) that need a full **dovi_tool** convert. Skipped files are counted separately in the batch confirmation dialog and logged as `Skipping DV Profile 5 (setting): …`.

## [3.0.18] - 2026-06-13

### Fixed

- Profile 5 **dovi_tool** convert temp files now use **`special://temp/service.trickplay/dovi/`** (on `/storage`) instead of OS **`/tmp`**, which is often too small on CoreELEC for a full 4K HEVC rewrite (`No space left on device`).
- Skip redundant MKV remux after convert — frame extraction reads the **`.hevc`** elementary stream directly (halves peak temp disk use).
- Preflight disk-space check before Profile 5 convert with a clear log message when space is insufficient.

## [3.0.17] - 2026-06-13

### Fixed

- **dovi_tool convert** for Profile 5: `convert` does not accept Matroska — ffmpeg now demuxes to annex-B HEVC (`hevc_mp4toannexb`) and pipes into `dovi_tool -m 3 convert -`.
- Dolby Vision **profile detection** uses dovi_tool RPU info when ffprobe lacks `DOVI configuration record`; Profile **7/8** (e.g. DSNP FLUX) skip dovi_tool convert and use zscale only; Profile **5** (web `.DV.`) uses dovi_tool + zscale on no-Vulkan hosts.
- README: static BtbN **libplacebo** on desktop Linux may need `VK_ICD_FILENAMES` (and related `VK_*` env) so the static ffmpeg binary can load system Vulkan ICDs; logged when ICD configs exist but init fails.

## [3.0.16] - 2026-06-13

### Fixed

- Batch **Run** no longer prompts to re-download **gpl-shared** ffmpeg when **zscale** already works but **libplacebo** is absent — on no-Vulkan hosts (CoreELEC) libplacebo is not required; Profile 5 DV uses **dovi_tool + zscale**.
- Linux HDR ffmpeg auto-install uses static **gpl-8.1** again (zscale on CoreELEC without `lib/` / Vulkan).
- **dovi_tool** detection skips wrong-architecture binaries (`Exec format error`); broken installs are removed before re-download.

## [3.0.15] - 2026-06-13

### Fixed

- **Dolby Vision on CoreELEC / no-Vulkan hosts** — Profile **5** (web-DV, no HDR10 base layer) uses **dovi_tool** `-m 3 convert` then **zscale + tonemap**. Profiles **7** and **8** keep the original **zscale + tonemap** path on the HDR10 base layer (no dovi_tool convert). libplacebo is used for any DV profile when Vulkan is available.

## [3.0.14] - 2026-06-13

### Added

- **Run batch in background** generator setting — batch **Run** can show a start notification and run without the blocking progress dialog; progress goes to the Kodi log and a notification appears when finished.

### Fixed

- **Dolby Vision** tone mapping: Linux auto-install again uses BtbN **gpl-shared-8.1** (zscale + libplacebo with clean `LD_LIBRARY_PATH`). Re-run **Run** to replace a static `-gpl-8.1` install that has zscale but no libplacebo.
- libplacebo Vulkan init (`-init_hw_device vulkan`) is passed on every frame-extract ffmpeg invocation when DV/HDR uses libplacebo.

## [3.0.13] - 2026-06-13

### Fixed

- **Dolby Vision** trickplay thumbs (green/purple tint): DV sources are detected (DOVI side_data, dovi_tool, or `.DV.` in filename) and routed through **libplacebo** with `apply_dolbyvision=1` instead of the HDR10 zscale chain, which cannot apply DV RPU metadata.

## [3.0.12] - 2026-06-13

### Fixed

- HDR trickplay generation on ffmpeg 8.x (BtbN `-gpl-8.1`): tone-mapped output now uses full-range **yuvj420p** with `-strict unofficial` and `-color_range pc`. Fixes mjpeg encoder failure: `Non full-range YUV is non-standard`.

## [3.0.11] - 2026-06-13

### Fixed

- BtbN auto-install URLs: correct asset names use **`-gpl-8.1`** suffix (e.g. `linuxarm64-gpl-8.1.tar.xz`), not `-gpl.tar.xz` — fixes HTTP 404 on download.

## [3.0.10] - 2026-06-13

### Changed

- Linux HDR ffmpeg auto-install now uses BtbN **`-gpl`** (static) builds instead of **`-gpl-shared`**. On CoreELEC the shared build often exposes only `tonemap` even with `LD_LIBRARY_PATH` set; the static `-gpl` tarball includes **zscale** and **libplacebo** without a separate `lib/` folder. Windows still uses gpl-shared zip. Re-run **Run** to replace a broken shared install.

## [3.0.9] - 2026-06-13

### Fixed

- HDR ffmpeg filter detection after auto-install: tonemap capability cache now keys on `LD_LIBRARY_PATH` as well as binary path, and is cleared when generator ffmpeg is re-resolved. Fixes false "lacks zscale/libplacebo" results for BtbN **gpl-shared** builds when an earlier probe ran without `lib/` on the path.
- Install verification logs `lib/` shared-library count and probe details; fails clearly when `lib/` is missing or empty (shared build required — static `-gpl` is not used).
- **Generator ffmpeg path** setting missing `<control>` tag (Kodi log spam: `unable to read setting "generator_ffmpeg_path"`).

## [3.0.8] - 2026-06-13

### Added

- **HDR ffmpeg auto-install on Run** — when **HDR tone mapping** is enabled and the generator ffmpeg lacks **zscale** or **libplacebo**, batch **Run** offers to download and install a pinned [BtbN gpl-shared](https://github.com/BtbN/FFmpeg-Builds/releases) build (linux64, linuxarm64, win64, winarm64). Installs to `/storage/.kodi/system/ffmpeg/` on Linux Kodi or `special://profile/addon_data/service.trickplay/system/ffmpeg/` on Windows.
- **dovi_tool auto-install on Run** — when **HDR dovi_tool fallback** is enabled and `dovi_tool` is missing, **Run** offers to download and install pinned [dovi_tool 2.3.2](https://github.com/quietvoid/dovi_tool/releases/tag/2.3.2) into the add-on folder (same location as a manual `dovi_tool` beside `addon.xml`).

## [3.0.7] - 2026-06-13

### Added

- **Generator ffmpeg path** setting (optional folder or binary). When empty, generation auto-uses `/storage/.kodi/system/ffmpeg/` if present, then falls back to **tools.ffmpeg-tools**. Playback cropping still uses **tools.ffmpeg-tools**. Documented [BtbN FFmpeg-Builds](https://github.com/BtbN/FFmpeg-Builds/releases) for CoreELEC (linuxarm64-gpl-shared) and x86_64 Linux (linux64-gpl-shared) with install layout under `/storage/.kodi/system/ffmpeg/`.

### Changed

- HDR tonemap capability detection is cached per ffmpeg binary path (custom vs tools.ffmpeg-tools).

## [3.0.6] - 2026-06-13

### Fixed

- HDR tone mapping filter chain now matches Jellyfin-style processing: `setparams` (BT.2020/PQ tags), linearize with `zscale`, gamut map to BT.709 (`zscale=p=bt709`), `tonemap=hable:desat=0`, then BT.709 limited-range output. Fixes washed-out, grey trickplay tiles caused by tonemapping without gamut/transfer conversion.
- When `zscale` is unavailable, prefers **libplacebo** if present; otherwise logs a warning and uses an improved best-effort `tonemap` chain with explicit HDR tags and float workspace.
- Tone-mapped JPEG extraction sets BT.709 output color metadata on ffmpeg.

## [3.0.5] - 2026-06-13

### Fixed

- Batch cancel cleanup on NFS/local mounts: removes the in-progress resolution folder (e.g. `320 - 10x10 - 9000`) including partial tile JPEGs via the OS filesystem, not only `xbmcvfs`. Drops the parent `.trickplay` folder when no other resolution subfolders remain; keeps siblings such as `320 - 10x10` untouched.

## [3.0.4] - 2026-05-22

### Added

- Optional **HDR dovi_tool fallback** generator setting (default off, visible when HDR tone mapping is enabled). When on, ffprobe misses can be confirmed by extracting a short HEVC sample and running `dovi_tool` (local paths only; looks for `dovi_tool` in the add-on folder or on PATH). Logs when the setting is enabled and when fallback is used or skipped.

### Changed

- HDR ffprobe detection: scans all video streams (not only `v:0`), parses DOVI configuration record profiles from `side_data_list`, and detects Dolby Vision enhancement-layer streams.

## [3.0.3] - 2026-06-13

### Fixed

- HDR source detection for Dolby Vision / HDR10 remuxes: ffprobe now reads `side_data_list`, 10-bit `pix_fmt`, and bt2020 primaries (including DV streams tagged with bt709 transfer). Falls back to first-frame probe when stream-level metadata is missing.

## [3.0.2] - 2026-06-13

### Fixed

- HDR tone-map detection: recognise `tonemap` in ffmpeg 8.x `-filters` output (e.g. `.S tonemap V->V`) so CoreELEC **tools.ffmpeg-tools** builds with tonemap but without zscale use **tonemap-only** mode instead of falsely reporting the filter as missing.

## [3.0.1] - 2026-06-12

### Fixed

- Batch skip detection for existing Jellyfin sidecars (`320 - 10x10/`, etc.) now lists `.trickplay` folders via `os.listdir` on OS/NFS mounts when `xbmcvfs.listdir` misses them, and checks multiple media path variants (library path, resolved local path, ffmpeg path).

## [3.0.0] - 2026-06-12

### Added

- Optional **HDR tone mapping for previews** generator setting (default off). When enabled, HDR and Dolby Vision sources are tone-mapped to SDR during JPEG extraction. Only applies to HDR/DV files; SDR is unchanged. Requires ffmpeg `tonemap` filter support; significantly slower on 4K HEVC.

## [2.1.6] - 2026-06-12

### Added

- **Interval selection** playback setting: **Preferred interval** (match **Preview thumbnail interval**) or **Shortest interval** when multiple sidecar folders exist (e.g. `320 - 10x10 - 5000` vs `320 - 10x10 - 10000`).

### Fixed

- Batch and idle generation now skip existing Jellyfin sidecars in legacy folder names (`320 - 10x10/` without an interval suffix, treated as 10000 ms) when generator width, grid, and interval match — not only folders named `320 - 10x10 - 10000`.

## [2.1.5] - 2026-06-12

### Fixed

- Missing trickplay no longer spams `kodi.log` during playback: the service loads each file once per playback session instead of re-scanning on every poll tick when no sidecar exists.

## [2.1.4] - 2026-06-01

### Changed

- **Run library batch generation** removed from Configure settings. Batch generation is started from the add-on **Information** page **Run** button (`script_generator.py` with `provides executable`), so Configure changes are saved with OK before Run.

## [2.1.3] - 2026-06-01

### Fixed

- Generator VFS stream fallback for `nfs://` / `smb://` paths: read media with `xbmcvfs.File.readBytes()` instead of `read()`, which tried to decode MKV data as UTF-8 and broke ffprobe/ffmpeg pipe probing (`0xa3` invalid start byte).
- NFS URL → OS mount mapping accepts paths visible via Kodi VFS when `os.path.isfile` fails on embedded mounts.
- Batch library folder picker rejects invalid selections such as `special://home` with a clear message.

## [2.1.2] - 2026-06-01

### Changed

- Batch library folder picker uses Kodi's full folder browser (local drives and network shares) instead of the limited file-shares list; starts at the current path, `/storage/` on embedded installs, or `root://`.
- Folder chosen in the batch picker is saved to addon settings immediately so you do not need to press OK in settings first.

### Added

- README and Library folder setting help: addon settings are only written when you press **OK** and leave the settings screen (Kodi limitation); use **Run library batch generation…** to pick and save a folder without leaving settings.

## [2.1.1] - 2026-06-01

### Changed

- Estuary Mod v2 skin snippet: preview anchor raised 25 px total (`top` 624 → 599) so the thumbnail clears the episode info panel above the seek bar.
- Seek OSD open: sync-crop playhead and prefetch neighbors so the first scrub shows a thumbnail immediately; scrubbing uses synchronous crop on cache miss instead of waiting for a background crop.

## [2.1.0] - 2026-05-22

### Added

- **Generate on library update** (generator setting, off by default): listens for `VideoLibrary.OnAdd` and `VideoLibrary.OnUpdate` with `added: true`, accumulates paths during a library scan, and enqueues trickplay generation for those new items when the scan finishes (`VideoLibrary.OnScanFinished`).
- **Library update: only when not playing** (on by default): defers the post-scan batch until Kodi is not playing video.

## [2.0.15] - 2026-05-31

### Fixed

- Batch generation crash when the sidecar resolution folder does not exist yet: `_list_jpg_files` no longer raises on missing NFS paths (`os.listdir` wrapped; skip when directory absent).

## [2.0.14] - 2026-05-31

### Fixed

- Experimental ffmpeg multi-seek: register all `-ss`/`-i` inputs first, then `-map N:v:0` per output. Interleaved input/output syntax duplicated the first frame across each 25-frame chunk.

## [2.0.13] - 2026-05-31

### Fixed

- Batch candidate scan detects existing sidecar tile JPEGs via local filesystem listing (NFS/mounted paths), so videos that already have trickplay are excluded when overwrite is off.

### Changed

- Batch confirmation dialog reports how many videos will be generated and how many matching sidecars are skipped (e.g. “4 of 8 … 4 already have matching sidecars”).

## [2.0.12] - 2026-05-31

### Fixed

- Cancel during generation removes partial tile JPEGs and deletes the empty sidecar resolution folder (and empty parent `.trickplay` when nothing else remains).

## [2.0.11] - 2026-05-31

### Added

- Generator **Frame extraction mode** selector: **Accurate (slow)**, **Fast**, or **Experimental**. Replaces the fast on/off toggle (legacy toggle still maps to accurate/fast when upgrading).
- **Experimental** mode: one open file with seek between captures — PyAV when installed, otherwise one ffmpeg process with multiple `-ss` seeks per tile (chunked).

## [2.0.10] - 2026-05-31

### Fixed

- Fast extraction for intervals above 5s: one `-ss` before `-i` seek per thumbnail instead of decoding the entire interval span with `fps`. A 20s interval no longer spends ~20s of decode per thumb.

### Changed

- Fast extraction for intervals of 5s or less still uses a single continuous `fps` decode pass (faster for dense sampling).

## [2.0.9] - 2026-05-31

### Changed

- Accurate per-frame timeout increment: 200ms per thumb index (was 10s). Thumb 99 timeout is ~620s instead of ~1590s.

## [2.0.8] - 2026-05-31

### Changed

- Accurate per-frame extraction timeout: 600s base plus 200ms per thumb index (was a fixed 120s in 2.0.7; 10s per thumb in 2.0.8).
- **Fast batch extraction** defaults to on for new installs.

### Added

- Generator setting **Stop batch on first failure** (off by default).

### Fixed

- Failed generation removes empty sidecar resolution folders (and an empty parent `.trickplay` when nothing else remains).

## [2.0.7] - 2026-05-31

### Fixed

- Fast batch extraction: temp JPEG sequences are listed via the local filesystem (ffmpeg writes outside VFS), `-start_number 0` removed, and tile progress is logged so generation no longer fails silently.

### Added

- Generator setting **Fast batch extraction** (off by default): one ffmpeg pass per tile with seek-before-input when enabled; accurate per-frame seek-after-input when disabled.

## [2.0.6] - 2026-05-31

### Changed

- Trickplay frame extraction: one ffmpeg pass per tile with `-ss` before `-i`, `fps`, deinterlace, and scale/pad. Replaces per-frame seeks (~35s/tile vs minutes on long REMUX files).

## [2.0.5] - 2026-05-31

### Fixed

- Batch trickplay generation cancel: the progress dialog only checked cancel between files, so a long episode could block for hours. Cancel is now polled during frame extract and tile assembly, in-flight ffmpeg processes are killed, and partial sidecars for the current file are removed.

## [2.0.4] - 2026-05-31

### Fixed

- Trickplay tile assembly: ffmpeg's `tile` filter needs a numbered image sequence, not one `-i` per JPEG. Grids were rendering as a single thumbnail on black; they now build full 10×10 (or configured) sprites.
- Frame extraction for interlaced sources: deinterlace with `yadif`, seek after input, and pad thumbs to 16:9 cells matching Jellyfin sidecar layout.

## [2.0.3] - 2026-05-31

### Fixed

- Trickplay generation on Kodi `nfs://` / `smb://` library paths: ffmpeg cannot open VFS URLs directly, so the generator now maps OS-mounted shares when available and otherwise streams media through Kodi's VFS into ffmpeg (sequential read).

### Changed

- Duration probing logs the resolved ffmpeg path and ffprobe/ffmpeg stderr when parsing fails.

## [2.0.2] - 2026-05-31

### Fixed

- Batch generation progress dialog no longer crashes on Kodi 21: `DialogProgress.update()` only accepts percent and one message line (the third line argument was removed in Kodi v19).

## [2.0.1] - 2026-05-31

### Fixed

- **Run library batch generation** action now uses `RunScript(service.trickplay,batch)` so Kodi invokes the script entry point correctly (the previous `script_generator.py` argument was treated as the mode and the script exited silently).

### Changed

- Batch generation logs startup, settings, folder selection, candidate counts, per-file progress, and early exits under `[service.trickplay.generator.batch]`.

## [2.0.0] - 2026-05-31

### Added

- **Generator thumbnail interval (ms)** setting (default 10000). Generated sidecar folders now include the interval in the name, e.g. `320 - 10x10 - 1000` or `320 - 10x10 - 10000`.

### Changed

- Playback reads the thumbnail interval from the sidecar folder name when present; legacy folders without an interval suffix (`320 - 10x10`) fall back to **10000 ms**.
- Resolution selection prefers a folder matching both preferred tile width and playback interval setting.
- Preview lookup uses the loaded folder's interval instead of always using the playback settings value.

## [1.7.0] - 2026-05-31

### Changed

- First seek preview is faster: the 3-second startup gate no longer blocks preview when trickplay data is loaded — it only suppresses false automatic scrub detection during playback start.
- Poll interval stays at configured `poll_ms` for the whole time video is playing, so opening the seek OSD is detected promptly.
- Playhead thumbnail is cropped eagerly when trickplay loads, before background prefetch neighbours.
- Pre-1.6.11 crop cache files are migrated into fingerprinted cache paths on first access instead of forcing a full re-crop.

## [1.6.13] - 2026-05-31

### Fixed

- Service appeared dead with almost no logs: trickplay loading now runs on a background thread so NFS/ffprobe enrichment cannot freeze the service loop or player callbacks.
- Poll loop detects new playback files when `onAVStarted`/`onPlayBackStarted` are missed, with duplicate-load guards.
- Poll errors are logged instead of silently stopping the service.
- Preview publish force-resyncs to DialogSeekBar when visible after each update.

## [1.6.12] - 2026-05-31

### Fixed

- Trickplay previews missing after 1.6.8: resync no longer skips solely because home-window properties are unchanged — DialogSeekBar reloads (e.g. `LOAD_ON_GUI_INIT`) clear window properties, so resync now verifies the seekbar actually matches before skipping. Force-resync when the seekbar opens with an active preview session.

## [1.6.11] - 2026-05-29

### Changed

- Crop cache keys and on-disk filenames now include the source sprite tile mtime and size, so regenerated Jellyfin sidecars no longer reuse stale cropped thumbs. Tile fingerprints are cached for 2 seconds to limit VFS stat traffic during scrub/prefetch.

## [1.6.10] - 2026-05-29

### Changed

- Service poll interval adapts to workload: configured `poll_ms` during scrubbing, seek UI, and active previews; ~200–500 ms during calm playback; 500 ms when idle with background generation; 1000 ms when fully idle.

## [1.6.9] - 2026-05-29

### Changed

- Preview placement (slot and geometry window properties) is skipped when only the thumbnail image updates, such as when an async crop finishes for the same seek position.

## [1.6.8] - 2026-05-29

### Changed

- `resync_preview_to_seekbar()` skips work when the seekbar is hidden, when home-window properties are unchanged since the last resync, or when the seekbar already matches; still runs on seekbar open (visibility transition) or when properties differ.

## [1.6.7] - 2026-05-29

### Changed

- Addon settings reads are cached for 2 seconds on hot paths (prefetch, generator, runtime playback, display sync) to reduce repeated Kodi settings API calls during scrub polling.

## [1.6.6] - 2026-05-29

### Changed

- Sprite tile temp copies are shared across threads: in-memory index keyed by source path and fingerprint, per-tile locks prevent duplicate NFS copies when prefetch and preview crop the same JPG concurrently.

## [1.6.5] - 2026-05-29

### Changed

- Crop cache: in-memory index avoids repeated VFS stat checks for known-good thumbs; concurrent foreground/prefetch crops for the same cell share one in-flight ffmpeg job.

## [1.6.4] - 2026-05-29

### Changed

- Crop cache LRU prune is debounced: runs after a batch of new crops, a minimum interval, or when estimated cache size exceeds the limit — not after every single crop.

## [1.6.3] - 2026-05-29

### Changed

- **Preview tile grid layout** is now a single always-visible dropdown (From folder name, 10×10, 20×20, 5×5, 15×15, Custom) replacing the separate Automatic tile calculation toggle and hidden manual grid options.

## [1.6.2] - 2026-05-29

### Fixed

- Service crash on startup (`Invalid setting type`) when reading generator settings: removed legacy lookup of deleted `generator_skip_existing` setting; setting readers now fail safely to defaults.

## [1.6.1] - 2026-05-22

### Changed

- Generator **Overwrite existing sidecars** toggle (default off) replaces **Skip existing sidecars**; when enabled, existing tile JPGs are deleted before regeneration.

## [1.6.0] - 2026-05-22

### Added

- **Trickplay generator** (optional, off by default): writes Jellyfin-compatible `.trickplay` sidecars with ffmpeg.
- Generator settings: enable/disable (hides all generator options when off), tile grid preset (10×10, 20×20, 5×5, 15×15, custom), library folder, skip existing, generate while idle, and **Run library batch generation** action.
- **Display tile grid layout** preset selector when automatic tile calculation is off (for custom or non-Jellyfin sprite grids).

### Changed

- Batch generation runs from addon settings via progress dialog; idle generation runs one file at a time in the background service when Kodi is not playing video.

## [1.5.4] - 2026-05-22

### Fixed

- Estuary Mod v2 (and AF3): preview overlay no longer shows a white box when scrubbing content without trickplay sidecars — border control no longer fills the frame, and visibility requires a preview image.
- Service no longer sets `Trickplay.PreviewVisible` when trickplay data is unavailable or lookup fails during scrub.

## [1.5.3] - 2026-05-22

### Added

- **Preview opacity (%)** setting (0–100, default 100). Publishes `Trickplay.PreviewColorDiffuse` for skin `colordiffuse`.

### Fixed

- Preview thumbnail no longer inherits border transparency: border is a separate control; opacity applies to the preview group only.

## [1.5.2] - 2026-05-22

### Changed

- Estuary Mod v2 snippet: preview anchor raised 132 px (`top` 756 → 624) for normal and small/wide OSD.
- Estuary preview border switched to light `colors/white.png` frame (`colordiffuse` B3FFFFFF) instead of dark `dialog-bg-nobo.png`.

## [1.5.1] - 2026-05-22

### Changed

- Skin snippets: subtle preview border — AF3 uses `panel_fg_70` on a 2 px frame; Estuary Mod v2 uses `dialog-bg-nobo.png`.

## [1.5.0] - 2026-05-22

### Added

- **Thumbnail prefetch settings**: enable/disable prefetch, playback-start warm, whole-tile batching, idle tile prefetch, radius, queue size, and crop cache limit (LRU prune by oldest access time).
- **Idle prefetch**: while the seek OSD is open and not scrubbing, remaining cells in the current sprite tile are queued (once per tile, throttled every 3 s).
- **Crop cache LRU**: cached thumbs track last access; oldest files are deleted when over the MB limit (default 500, 0 = unlimited).

## [1.4.0] - 2026-05-22

### Added

- **Thumbnail prefetch**: playhead warm on playback start (±3 indices + up to 20 cells in the current sprite tile), scrub-direction bias (+5 ahead / −2 behind when seeking forward, mirrored when rewinding), and local sprite copy before batching crops from the same tile file. Queue size raised to 48.

## [1.3.0] - 2026-05-22

### Added

- **Thumbnail prefetch**: after each preview, a background worker pre-crops the ±3 neighbouring trickplay cells (deduped, skips already-cached). Queue capped at 24; cancelled on playback stop.

## [1.2.5] - 2026-05-22

### Fixed

- Timestamp hidden when **Show timestamp** is disabled: `Trickplay.PreviewTime` is no longer published, layout omits label height, and `Trickplay.ShowTimestamp` is cleared with the preview session.
- Estuary Mod v2 skin snippet uses conditional group height (180 vs 224) when the timestamp is off.

## [1.2.4] - 2026-05-22

### Fixed

- Arctic Fuse 3 full OSD is detected via custom overlay windows (1140–1149, 1152, 1153), not only `videoosd`. Stale compact-seek previews now clear when those overlays open.
- Play-button focus hide includes AF3 overlay button ids (6101–6109).
- Preview properties are cleared on DialogSeekBar window 10115 even when Kodi visibility checks are ambiguous.

## [1.2.3] - 2026-05-22

### Fixed

- Stale trickplay preview no longer persists when opening the full video OSD after seeking via the compact seekbar.
- Preview session state is cleared whenever seek UI closes, not only after an active scrub.
- Full video OSD hides preview unless the seekbar is focused, play controls are not focused, or a preview session is actively held/scrubbing.
- Transition from compact seekbar to full video OSD ends the prior preview session unless still scrubbing.

## [1.2.2] - 2026-05-22

### Changed

- **tools.ffmpeg-tools** is now a required dependency (no longer optional).
- Removed Pillow fallback and all references to `script.module.pillow`.

## [1.2.1] - 2026-05-22

### Fixed

- Preview hold time **0** now advances the thumbnail with playback while the OSD stays open (not frozen on the last seek frame).

## [1.2.0] - 2026-05-22

### Added

- **Preview hold time** setting (0–10 s, default 4; 0 = until OSD closes).
- **Show timestamp** setting toggles `Trickplay.ShowTimestamp` for skin label visibility.

### Fixed

- Preview no longer stays visible indefinitely during playback after a seek (`Player.Seeking` stuck / paused OSD rule removed).
- Arctic Fuse 3 snippet anchor lowered by 132 px (`top` 538 → 670).

## [1.1.2] - 2026-05-22

### Fixed

- Preview stays visible for a few seconds after seeking and while paused with the OSD open.
- No longer treats playhead movement during playback as scrubbing (stops thumbnail flash with OSD open).

## [1.1.1] - 2026-05-22

### Fixed

- Skin auto-detect no longer reads `xbmc.gui` addon id; uses `lookandfeel.skin` setting and `getSkinDir()` instead.

## [1.1.0] - 2026-05-22

### Added

- **Skin profile auto-detection** via active Kodi skin id (`skin_profiles.py`).
- Built-in profiles for **Estuary Mod v2** and **Arctic Fuse 3** (geometry + OSD focus ids).
- **Skin profile** addon setting to override auto-detect.
- Reference skin snippet for Arctic Fuse 3: `DialogSeekBar-skin.arctic.fuse.3.xml`.

### Changed

- `osd_layout.py` reads seek bar geometry from the active skin profile instead of hardcoded constants.

## [1.0.0] - 2026-05-22

### Added

- Initial release of **Trickplay Preview** (`service.trickplay`).
- Background service that reads Jellyfin `.trickplay` sprite folders next to local/NFS media.
- Thumbnail lookup by seek position with configurable preferred resolution and interval.
- Async cropping via `script.module.pillow` or `tools.ffmpeg-tools`, with local cache.
- DialogSeekBar skin integration through window properties (`Trickplay.PreviewImage`, `Trickplay.PreviewVisible`, `Trickplay.PreviewSlot`, etc.).
- Reference skin snippet for Estuary Mod v2: `resources/skin-snippet/DialogSeekBar-skin.estuary.modv2.xml`.
- Preview positioning aligned to seek bar geometry (51 horizontal slots, normal and wide OSD layouts).
- Preview visibility while seeking or when the seek bar has focus; hidden when focus moves to play controls.
- Reliable multi-step seek handling using Kodi `onPlayBackSeek` and committed seek targets.
- Addon settings for tile width, thumb interval, poll interval, tile grid, and debug logging.

### Notes

- **Skin edit required:** merge the snippet into your skin’s `DialogSeekBar.xml` before previews will appear. See `README.md`.
