"""Roku/Plex/Emby .bif reader and .trickplay -> .bif converter."""

from __future__ import annotations

import os
import struct
import threading
from dataclasses import dataclass
from io import BytesIO
from typing import Callable

import xbmc
import xbmcvfs

from pillow_installer import ensure_pillow_loaded
from vfs_paths import (
    extended_length_path,
    local_path as _local_path,
    path_variants,
    vfs_join,
    writable_os_path,
)

BIF_MAGIC = b"\x89BIF\r\n\x1a\n"
BIF_VERSION = 0
BIF_HEADER_SIZE = 64
BIF_DEFAULT_INTERVAL_MS = 10000
_INDEX_ENTRY_FMT = "<II"
_INDEX_ENTRY_SIZE = 8
_HEADER_FMT = "<8sIII44s"

_BIF_CACHE_LOCK = threading.Lock()
_BIF_INDEX_CACHE: dict[str, tuple[float, int, "BifIndex"]] = {}
_BIF_RAM_MAX_BYTES = 64 * 1024 * 1024
_BIF_DATA_CACHE: dict[str, tuple[float, int, bytes]] = {}


@dataclass(frozen=True)
class BifIndex:
    path: str
    interval_ms: int
    frame_count: int
    offsets: tuple[int, ...]  # length frame_count + 1 (end offset included)
    thumb_width: int = 0
    thumb_height: int = 0


def _log(message: str, level=xbmc.LOGINFO) -> None:
    xbmc.log(f"[service.trickplay] {message}", level)


def _stat_file(path: str) -> tuple[float, int]:
    local = _local_path(path)
    if local and "://" not in local:
        try:
            st = os.stat(extended_length_path(local))
            return float(st.st_mtime), int(st.st_size)
        except OSError:
            pass
    try:
        st = xbmcvfs.Stat(path)
        return float(st.st_mtime()), int(st.st_size())
    except (OSError, RuntimeError, AttributeError):
        return 0.0, 0


def _file_exists(path: str) -> bool:
    if not path:
        return False
    local = _local_path(path)
    if local and "://" not in local and os.path.isfile(extended_length_path(local)):
        return True
    try:
        return bool(xbmcvfs.exists(path))
    except (OSError, RuntimeError):
        return False


def _read_slice(path: str, offset: int, size: int) -> bytes:
    if size <= 0 or offset < 0:
        return b""
    local = _local_path(path)
    if local and "://" not in local:
        try:
            with open(extended_length_path(local), "rb") as handle:
                handle.seek(offset)
                return handle.read(size)
        except OSError:
            return b""
    try:
        with xbmcvfs.File(path, "r") as handle:
            handle.seek(offset, 0)
            data = handle.readBytes(size)
            return bytes(data) if data else b""
    except (OSError, RuntimeError, AttributeError):
        return b""


def probe_jpeg_bytes_dimensions(data: bytes) -> tuple[int, int]:
    """Parse width and height from raw JPEG bytes without Pillow."""
    if not data or len(data) < 4 or data[:2] != b"\xff\xd8":
        return 0, 0
    idx = 2
    n = len(data)
    while idx + 3 < n:
        if data[idx] != 0xFF:
            idx += 1
            continue
        while idx < n and data[idx] == 0xFF:
            idx += 1
        if idx >= n:
            break
        marker = data[idx]
        idx += 1
        if marker in (0xD8, 0xD9, 0x01) or 0xD0 <= marker <= 0xD7:
            continue
        if idx + 2 > n:
            break
        seg_len = struct.unpack(">H", data[idx : idx + 2])[0]
        if seg_len < 2 or idx + seg_len > n:
            break
        if marker in (
            0xC0,
            0xC1,
            0xC2,
            0xC3,
            0xC5,
            0xC6,
            0xC7,
            0xC9,
            0xCA,
            0xCB,
            0xCD,
            0xCE,
            0xCF,
        ) and seg_len >= 7:
            height, width = struct.unpack(">HH", data[idx + 3 : idx + 7])
            return int(width), int(height)
        idx += seg_len
    return 0, 0


def _read_all_bytes(path: str) -> bytes:
    local = _local_path(path)
    if local and "://" not in local:
        try:
            with open(extended_length_path(local), "rb") as handle:
                return handle.read()
        except OSError:
            return b""
    try:
        with xbmcvfs.File(path, "r") as handle:
            data = handle.readBytes()
            return bytes(data) if data else b""
    except (OSError, RuntimeError, AttributeError):
        return b""


def bif_is_warm(bif_path: str) -> bool:
    with _BIF_CACHE_LOCK:
        return bif_path in _BIF_DATA_CACHE


def warm_bif_in_ram(bif_path: str) -> bool:
    """Load an entire .bif file (typically 5-15 MB) into RAM for <1ms scrubbing."""
    if not bif_path or not _file_exists(bif_path):
        return False
    mtime, size = _stat_file(bif_path)
    if size > _BIF_RAM_MAX_BYTES:
        return False
    with _BIF_CACHE_LOCK:
        cached = _BIF_DATA_CACHE.get(bif_path)
        if cached is not None and cached[0] == mtime and cached[1] == size:
            return True
    raw = _read_all_bytes(bif_path)
    if not raw or len(raw) > _BIF_RAM_MAX_BYTES:
        return False
    with _BIF_CACHE_LOCK:
        # Keep only the active video's .bif in RAM so memory stays bounded.
        _BIF_DATA_CACHE.clear()
        _BIF_DATA_CACHE[bif_path] = (mtime, size, raw)
    return True


def _get_ram_bif_bytes(bif_path: str) -> bytes | None:
    with _BIF_CACHE_LOCK:
        entry = _BIF_DATA_CACHE.get(bif_path)
        return entry[2] if entry is not None else None


def parse_bif_index(bif_path: str) -> BifIndex | None:
    """Parse and cache the BIF header and frame offset table."""
    if not bif_path or not _file_exists(bif_path):
        return None
    mtime, size = _stat_file(bif_path)
    with _BIF_CACHE_LOCK:
        cached = _BIF_INDEX_CACHE.get(bif_path)
        if cached is not None and cached[0] == mtime and cached[1] == size:
            return cached[2]

    ram = _get_ram_bif_bytes(bif_path)
    if ram is None and 0 < size <= _BIF_RAM_MAX_BYTES:
        if warm_bif_in_ram(bif_path):
            ram = _get_ram_bif_bytes(bif_path)

    if ram is not None:
        header = ram[:BIF_HEADER_SIZE]
    else:
        header = _read_slice(bif_path, 0, BIF_HEADER_SIZE)
    if len(header) < BIF_HEADER_SIZE:
        return None
    magic, version, count, multiplier_ms, _pad = struct.unpack(_HEADER_FMT, header)
    if magic != BIF_MAGIC or version != BIF_VERSION or count <= 0:
        return None
    if count > 1_000_000:
        return None

    table_size = (count + 1) * _INDEX_ENTRY_SIZE
    if ram is not None:
        table_bytes = ram[BIF_HEADER_SIZE : BIF_HEADER_SIZE + table_size]
    else:
        table_bytes = _read_slice(bif_path, BIF_HEADER_SIZE, table_size)
    if len(table_bytes) < table_size:
        return None

    offsets: list[int] = []
    for i in range(count + 1):
        _frame_ts, offset = struct.unpack_from(
            _INDEX_ENTRY_FMT, table_bytes, i * _INDEX_ENTRY_SIZE
        )
        offsets.append(int(offset))

    if any(offsets[i + 1] < offsets[i] for i in range(count)):
        return None

    interval_ms = int(multiplier_ms) if multiplier_ms > 0 else BIF_DEFAULT_INTERVAL_MS
    first_len = max(offsets[1] - offsets[0], 0)
    if ram is not None:
        first_jpeg = ram[offsets[0] : offsets[0] + min(first_len, 65536)]
    else:
        first_jpeg = _read_slice(bif_path, offsets[0], min(first_len, 65536))
    thumb_w, thumb_h = probe_jpeg_bytes_dimensions(first_jpeg)

    index = BifIndex(
        path=bif_path,
        interval_ms=interval_ms,
        frame_count=int(count),
        offsets=tuple(offsets),
        thumb_width=thumb_w,
        thumb_height=thumb_h,
    )
    with _BIF_CACHE_LOCK:
        _BIF_INDEX_CACHE[bif_path] = (mtime, size, index)
    return index


def read_bif_frame_bytes(bif_path: str, frame_index: int) -> bytes:
    """Read raw JPEG bytes for ``frame_index`` directly from RAM or .bif file."""
    index = parse_bif_index(bif_path)
    if index is None or index.frame_count <= 0:
        return b""
    clamped = max(0, min(int(frame_index), index.frame_count - 1))
    start = index.offsets[clamped]
    end = index.offsets[clamped + 1]
    if end <= start:
        return b""
    ram = _get_ram_bif_bytes(bif_path)
    if ram is not None and end <= len(ram):
        return ram[start:end]
    return _read_slice(bif_path, start, end - start)


def find_bif_for_media(media_path: str, preferred_width: int = 320) -> str:
    """Locate a sibling .bif file for ``media_path``, if present."""
    if not media_path:
        return ""
    for variant in path_variants(media_path):
        stem, _ext = os.path.splitext(variant)
        if not stem:
            continue
        candidates = (
            f"{stem}-{preferred_width}.bif",
            f"{stem}.bif",
            vfs_join(f"{stem}.trickplay", f"{preferred_width}.bif"),
            vfs_join(f"{stem}.trickplay", "trickplay.bif"),
        )
        for cand in candidates:
            if _file_exists(cand):
                return cand
    return ""


def bif_output_path_for_media(media_path: str, preferred_width: int = 320) -> str:
    """Return the canonical sibling .bif output path for ``media_path``."""
    stem, _ext = os.path.splitext(media_path)
    return f"{stem}-{int(preferred_width)}.bif"


def write_bif_file(
    output_path: str,
    frames: list[bytes],
    interval_ms: int,
) -> bool:
    """Write a standard BIF v0 file atomically without modifying .trickplay."""
    if not output_path or not frames:
        return False

    count = len(frames)
    header = struct.pack(
        _HEADER_FMT,
        BIF_MAGIC,
        BIF_VERSION,
        count,
        max(int(interval_ms), 1),
        b"\x00" * 44,
    )
    offset = BIF_HEADER_SIZE + (count + 1) * _INDEX_ENTRY_SIZE
    index_chunks: list[bytes] = []
    for idx, frame in enumerate(frames):
        index_chunks.append(struct.pack(_INDEX_ENTRY_FMT, idx, offset))
        offset += len(frame)
    index_chunks.append(struct.pack(_INDEX_ENTRY_FMT, 0xFFFFFFFF, offset))

    payload = b"".join([header, *index_chunks, *frames])

    target = writable_os_path(output_path) or _local_path(output_path)
    if target and "://" not in target:
        target_io = extended_length_path(target)
        tmp_io = f"{target_io}.tmp"
        try:
            parent = os.path.dirname(target_io)
            if parent:
                os.makedirs(parent, exist_ok=True)
            with open(tmp_io, "wb") as handle:
                handle.write(payload)
            os.replace(tmp_io, target_io)
            return True
        except OSError as exc:
            _log(f"OS write failed for BIF {target}: {exc}; trying VFS", xbmc.LOGWARNING)
            try:
                if os.path.exists(tmp_io):
                    os.remove(tmp_io)
            except OSError:
                pass

    if "://" in output_path:
        try:
            with xbmcvfs.File(output_path, "w") as handle:
                handle.write(payload)
            return True
        except (OSError, RuntimeError, TypeError) as exc:
            _log(f"VFS write failed for BIF {output_path}: {exc}", xbmc.LOGWARNING)
    return False


def _is_blank_cell(cell_image) -> bool:
    """Return True if a cropped sprite cell is solid black padding."""
    try:
        luma = cell_image.convert("L")
        # Ignore 2px JPEG block-boundary bleed from adjacent cells.
        w, h = luma.size
        if w > 8 and h > 8:
            luma = luma.crop((4, 4, w - 4, h - 4))
        extrema = luma.getextrema()
        return extrema[1] <= 4
    except Exception:
        return False


def convert_trickplay_to_bif(
    resolution,
    output_path: str,
    *,
    quality: int = 90,
    should_cancel: Callable[[], bool] | None = None,
) -> tuple[bool, int]:
    """Convert an existing .trickplay resolution into a .bif file (keeps .trickplay).

    Returns ``(success, frame_count)``.
    """
    if resolution is None or not resolution.tile_paths:
        return False, 0
    if not ensure_pillow_loaded():
        return False, 0

    from PIL import Image

    cols = max(int(resolution.tile_width), 1)
    rows = max(int(resolution.tile_height), 1)
    thumb_w = int(resolution.thumb_width)
    thumb_h = int(resolution.thumb_height)
    if thumb_w <= 0 or thumb_h <= 0:
        return False, 0

    frames: list[bytes] = []
    blank_flags: list[bool] = []
    total_tiles = len(resolution.tile_paths)
    clamped_q = max(50, min(int(quality), 95))

    for tile_idx, tile_path in enumerate(resolution.tile_paths):
        if should_cancel and should_cancel():
            return False, 0
        local = _local_path(tile_path)
        raw_bytes = b""
        if local and "://" not in local and os.path.isfile(extended_length_path(local)):
            with open(extended_length_path(local), "rb") as handle:
                raw_bytes = handle.read()
        else:
            try:
                with xbmcvfs.File(tile_path, "r") as handle:
                    raw_bytes = bytes(handle.readBytes())
            except (OSError, RuntimeError, AttributeError):
                raw_bytes = b""
        if not raw_bytes:
            _log(f"BIF convert: failed to read sprite tile {tile_path}", xbmc.LOGWARNING)
            return False, 0

        with Image.open(BytesIO(raw_bytes)) as sprite:
            sprite_rgb = sprite.convert("RGB")
            sw, sh = sprite_rgb.size
            max_cols = min(cols, max(sw // thumb_w, 1))
            max_rows = min(rows, max(sh // thumb_h, 1))
            is_last_tile = tile_idx == total_tiles - 1
            for r in range(max_rows):
                for c in range(max_cols):
                    x0 = c * thumb_w
                    y0 = r * thumb_h
                    if x0 + thumb_w > sw or y0 + thumb_h > sh:
                        continue
                    cell = sprite_rgb.crop((x0, y0, x0 + thumb_w, y0 + thumb_h))
                    buf = BytesIO()
                    cell.save(buf, format="JPEG", quality=clamped_q, optimize=False)
                    frames.append(buf.getvalue())
                    blank_flags.append(is_last_tile and _is_blank_cell(cell))

    # Trim trailing solid-black padding cells at the end of the last sprite tile.
    while len(frames) > 1 and blank_flags and blank_flags[-1]:
        frames.pop()
        blank_flags.pop()

    if not frames:
        return False, 0
    ok = write_bif_file(output_path, frames, resolution.interval_ms)
    return ok, (len(frames) if ok else 0)
