"""Optional HDR/DV to SDR tone mapping for trickplay thumbnail generation."""

from __future__ import annotations

import json
import os
import subprocess
import threading
from dataclasses import dataclass

import xbmc

from ffmpeg_media import _stream_to_pipe, resolve_ffmpeg_media_path

_HDR_TRANSFERS = frozenset({"smpte2084", "arib-std-b67"})
_HDR_PRIMARIES = frozenset({"bt2020", "bt2020nc", "bt2020c"})
_TONEMAP_MODE_NONE = "none"
_TONEMAP_MODE_SIMPLE = "simple"
_TONEMAP_MODE_ZSCALE = "zscale"
_tonemap_support_cache: str | None = None


def _log(message: str, level=xbmc.LOGINFO) -> None:
    xbmc.log(f"[service.trickplay.generator] {message}", level)


@dataclass(frozen=True)
class ThumbFilterContext:
    """Precomputed video filter chain for one generation job."""

    apply_tonemap: bool
    tonemap_mode: str
    thumb_vf: str


def _scale_pad_filter(tile_width: int) -> str:
    thumb_height = max(int(round(tile_width * 9 / 16)), 2)
    return (
        f"scale={tile_width}:{thumb_height}:force_original_aspect_ratio=decrease,"
        f"pad={tile_width}:{thumb_height}:(ow-iw)/2:(oh-ih)/2"
    )


def _tonemap_prefix(mode: str) -> str:
    if mode == _TONEMAP_MODE_ZSCALE:
        return (
            "zscale=transfer=linear:npl=100,format=gbrpf32le,"
            "tonemap=tonemap=hable:desat=0,"
            "zscale=primaries=709:transfer=709:matrix=709,format=yuv420p,"
        )
    if mode == _TONEMAP_MODE_SIMPLE:
        return "tonemap=tonemap=hable:desat=0,format=yuv420p,"
    return ""


def build_thumb_video_filter(tile_width: int, apply_tonemap: bool, tonemap_mode: str) -> str:
    scale_pad = _scale_pad_filter(tile_width)
    if apply_tonemap and tonemap_mode in (_TONEMAP_MODE_ZSCALE, _TONEMAP_MODE_SIMPLE):
        return f"{_tonemap_prefix(tonemap_mode)}{scale_pad}"
    return f"yadif=0:-1:0,{scale_pad}"


def build_fps_batch_filter(
    tile_width: int,
    interval_sec: float,
    apply_tonemap: bool,
    tonemap_mode: str,
) -> str:
    if interval_sec == int(interval_sec):
        fps_expr = f"1/{int(interval_sec)}"
    else:
        fps_expr = f"{1.0 / interval_sec:.8g}"
    thumb_vf = build_thumb_video_filter(tile_width, apply_tonemap, tonemap_mode)
    return f"fps={fps_expr},{thumb_vf}"


def detect_tonemap_support(ffmpeg: str, env: dict[str, str] | None) -> str:
    global _tonemap_support_cache
    if _tonemap_support_cache is not None:
        return _tonemap_support_cache

    mode = _TONEMAP_MODE_NONE
    try:
        completed = subprocess.run(
            [ffmpeg, "-filters"],
            check=False,
            capture_output=True,
            text=True,
            timeout=30,
            env=env,
        )
        text = f"\n{completed.stdout or ''}\n{completed.stderr or ''}\n"
        has_tonemap = "\n tonemap " in text or "\n T.. tonemap " in text
        has_zscale = "\n zscale " in text or "\n T.. zscale " in text
        if has_tonemap and has_zscale:
            mode = _TONEMAP_MODE_ZSCALE
        elif has_tonemap:
            mode = _TONEMAP_MODE_SIMPLE
    except (OSError, subprocess.SubprocessError) as exc:
        _log(f"Could not detect ffmpeg tonemap filters: {exc}", xbmc.LOGWARNING)

    _tonemap_support_cache = mode
    if mode == _TONEMAP_MODE_NONE:
        _log("ffmpeg tonemap filter not available; HDR tone mapping disabled", xbmc.LOGWARNING)
    elif mode == _TONEMAP_MODE_ZSCALE:
        _log("HDR tone mapping: using zscale + tonemap")
    else:
        _log("HDR tone mapping: using tonemap only (no zscale)")
    return mode


def _stream_looks_hdr(stream: dict) -> bool:
    transfer = (stream.get("color_transfer") or "").strip().lower()
    primaries = (stream.get("color_primaries") or "").strip().lower()
    color_space = (stream.get("color_space") or "").strip().lower()

    if transfer in _HDR_TRANSFERS:
        return True
    if color_space in _HDR_PRIMARIES and transfer not in ("bt709", "smpte170m", "bt601"):
        return True
    if primaries in _HDR_PRIMARIES and transfer in _HDR_TRANSFERS:
        return True

    for side in stream.get("side_data_list") or []:
        side_type = (side.get("side_data_type") or "").lower()
        if "dovi" in side_type or side_type == "hdr dynamic metadata":
            return True

    return False


def _parse_hdr_from_ffprobe_json(payload: str, debug: bool) -> bool:
    try:
        data = json.loads(payload)
    except json.JSONDecodeError:
        return False

    for stream in data.get("streams") or []:
        if stream.get("codec_type") != "video":
            continue
        if _stream_looks_hdr(stream):
            if debug:
                _log(
                    "HDR stream detected: "
                    f"transfer={stream.get('color_transfer')!r} "
                    f"primaries={stream.get('color_primaries')!r}"
                )
            return True
    return False


def _ffprobe_hdr_local(ffprobe: str, local_path: str, env: dict[str, str] | None, debug: bool) -> bool:
    cmd = [
        ffprobe,
        "-v",
        "error",
        "-select_streams",
        "v:0",
        "-show_entries",
        "stream=color_transfer,color_primaries,color_space",
        "-show_entries",
        "stream_side_data=side_data_type",
        "-of",
        "json",
        local_path,
    ]
    try:
        completed = subprocess.run(
            cmd,
            check=False,
            capture_output=True,
            text=True,
            timeout=120,
            env=env,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        _log(f"HDR probe failed for {local_path!r}: {exc}", xbmc.LOGWARNING)
        return False

    if completed.returncode != 0:
        detail = (completed.stderr or completed.stdout or "").strip()
        if debug and detail:
            _log(f"HDR probe ffprobe failed: {detail[:300]}")
        return False

    return _parse_hdr_from_ffprobe_json(completed.stdout or "{}", debug)


def _ffprobe_hdr_via_pipe(
    media_path: str,
    ffprobe: str,
    env: dict[str, str] | None,
    debug: bool,
) -> bool:
    cmd = [
        ffprobe,
        "-v",
        "error",
        "-probesize",
        "50M",
        "-analyzeduration",
        "50M",
        "-select_streams",
        "v:0",
        "-show_entries",
        "stream=color_transfer,color_primaries,color_space",
        "-show_entries",
        "stream_side_data=side_data_type",
        "-of",
        "json",
        "pipe:0",
    ]
    try:
        proc = subprocess.Popen(
            cmd,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            env=env,
        )
    except OSError as exc:
        _log(f"HDR pipe probe failed to start for {media_path}: {exc}", xbmc.LOGWARNING)
        return False

    feeder = threading.Thread(
        target=_stream_to_pipe,
        args=(media_path, proc),
        daemon=True,
    )
    feeder.start()
    try:
        stdout, stderr = proc.communicate(timeout=120)
    except subprocess.TimeoutExpired:
        proc.kill()
        proc.communicate()
        _log(f"HDR pipe probe timed out for {media_path}", xbmc.LOGWARNING)
        return False
    finally:
        feeder.join(timeout=1)

    if proc.returncode != 0:
        detail = (stderr or b"").decode("utf-8", errors="replace").strip()
        if debug and detail:
            _log(f"HDR pipe probe failed: {detail[:300]}")
        return False

    return _parse_hdr_from_ffprobe_json(
        (stdout or b"").decode("utf-8", errors="replace"),
        debug,
    )


def probe_video_is_hdr(
    media_path: str,
    ffprobe: str,
    env: dict[str, str] | None,
    *,
    debug: bool = False,
) -> bool:
    if not ffprobe or not media_path:
        return False

    ffmpeg_input, use_vfs_stream = resolve_ffmpeg_media_path(media_path)
    if use_vfs_stream:
        return _ffprobe_hdr_via_pipe(media_path, ffprobe, env, debug)

    local_path = ffmpeg_input
    if not local_path or not os.path.isfile(local_path):
        return False
    return _ffprobe_hdr_local(ffprobe, local_path, env, debug)


def resolve_thumb_filter_context(
    *,
    hdr_tone_map_enabled: bool,
    tile_width: int,
    media_path: str,
    ffmpeg: str,
    ffprobe: str,
    env: dict[str, str] | None,
    debug: bool = False,
) -> ThumbFilterContext:
    tonemap_mode = _TONEMAP_MODE_NONE
    apply_tonemap = False

    if hdr_tone_map_enabled:
        tonemap_mode = detect_tonemap_support(ffmpeg, env)
        if tonemap_mode != _TONEMAP_MODE_NONE and probe_video_is_hdr(
            media_path, ffprobe, env, debug=debug
        ):
            apply_tonemap = True
            _log(
                f"HDR tone mapping enabled for {os.path.basename(media_path)} "
                f"({tonemap_mode})"
            )
        elif tonemap_mode != _TONEMAP_MODE_NONE and debug:
            _log(f"SDR source; HDR tone mapping not applied for {os.path.basename(media_path)}")

    thumb_vf = build_thumb_video_filter(tile_width, apply_tonemap, tonemap_mode)
    return ThumbFilterContext(
        apply_tonemap=apply_tonemap,
        tonemap_mode=tonemap_mode if apply_tonemap else _TONEMAP_MODE_NONE,
        thumb_vf=thumb_vf,
    )
