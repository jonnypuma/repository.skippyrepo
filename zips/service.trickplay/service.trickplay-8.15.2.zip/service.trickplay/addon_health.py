"""Collect addon health for the settings status dialog."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

import xbmcaddon

from pillow_installer import pillow_is_available
from skin_profiles import (
    active_profile,
    current_skin_id,
    snippet_install_supported,
    snippet_spec_for_skin_id,
)
from skin_snippet_installer import (
    OVERLAY_REVISION,
    _skin_addon_path,
    current_skin_overlay_installed,
    find_skin_xml_paths,
    overlay_already_installed,
    overlay_needs_refresh,
)


@dataclass(frozen=True)
class AddonHealth:
    skin_id: str
    skin_name: str
    profile_label: str
    snippet_file: str
    target_xml: str
    snippet_state: str  # missing | installed | stale | no_target
    pillow_ok: bool
    ffmpeg: str
    overlay_revision: int


@dataclass(frozen=True)
class SetupCheck:
    """One actionable prerequisite check shown by the setup wizard."""

    name: str
    ok: bool
    detail: str
    action: str = ""


def _skin_display_name(skin_id: str) -> str:
    if not skin_id:
        return "(unknown)"
    try:
        return xbmcaddon.Addon(skin_id).getAddonInfo("name") or skin_id
    except (RuntimeError, AttributeError):
        return skin_id


def _ffmpeg_status() -> str:
    try:
        from ffmpeg_tools import resolve_generator_ffmpeg_tools
        from generator_settings import read_generator_settings

        custom = read_generator_settings().ffmpeg_path
        ffmpeg, _, _ = resolve_generator_ffmpeg_tools(custom)
        return ffmpeg or "(not found)"
    except Exception:
        return "(not found)"


def collect_addon_health() -> AddonHealth:
    skin_id = current_skin_id() or ""
    profile = active_profile()
    spec = snippet_spec_for_skin_id(skin_id) if skin_id else None
    install_supported = snippet_install_supported(skin_id)
    snippet_file = spec.filename if spec and spec.filename else "(not applicable)"
    target_xml = spec.target_xml if spec else "DialogSeekBar.xml"
    root = _skin_addon_path(skin_id, quiet=True) or "" if skin_id else ""

    snippet_state = "not_applicable" if not install_supported else "no_target"
    if install_supported and skin_id and spec and root:
        paths = find_skin_xml_paths(root, target_xml)
        if not paths:
            snippet_state = "no_target"
        elif any(
            overlay_already_installed(p) and not overlay_needs_refresh(p, spec.filename)
            for p in paths
        ):
            snippet_state = "installed"
        elif any(overlay_already_installed(p) for p in paths):
            snippet_state = "stale"
        else:
            snippet_state = "missing"
    elif install_supported and skin_id and spec:
        snippet_state = "no_target"

    return AddonHealth(
        skin_id=skin_id or "(none)",
        skin_name=_skin_display_name(skin_id),
        profile_label=profile.label if profile else "(unknown)",
        snippet_file=snippet_file,
        target_xml=target_xml,
        snippet_state=snippet_state,
        pillow_ok=pillow_is_available(),
        ffmpeg=_ffmpeg_status(),
        overlay_revision=OVERLAY_REVISION,
    )


def format_health_report(health: AddonHealth) -> str:
    state_labels = {
        "installed": "OK (up to date)",
        "stale": "Installed but STALE — reinstall snippet",
        "missing": "Not installed",
        "no_target": f"Target {health.target_xml} not found",
        "not_applicable": "Not applicable to protected stock Estuary",
    }
    snippet_line = state_labels.get(health.snippet_state, health.snippet_state)
    pillow_line = "OK" if health.pillow_ok else "Missing — Install Pillow"
    return (
        f"Active skin: {health.skin_name}\n"
        f"  ({health.skin_id})\n"
        f"Skin profile: {health.profile_label}\n"
        f"Snippet: {health.snippet_file}\n"
        f"Target: {health.target_xml}\n"
        f"Snippet status: {snippet_line}\n"
        f"Expected overlay rev: {health.overlay_revision}\n"
        f"Pillow: {pillow_line}\n"
        f"ffmpeg: {health.ffmpeg}"
    )


def collect_setup_checks(health: AddonHealth | None = None) -> tuple[SetupCheck, ...]:
    """Return deterministic, actionable setup checks for the guided wizard."""
    health = health or collect_addon_health()
    checks = [
        SetupCheck(
            "Skin overlay",
            health.snippet_state in ("installed", "not_applicable"),
            {
                "installed": "Installed and current",
                "not_applicable": "Stock Estuary is protected; no overlay installation is required",
                "stale": "Installed but outdated",
                "missing": "Not installed",
                "no_target": f"Target {health.target_xml} was not found",
            }.get(health.snippet_state, health.snippet_state),
            "install_skin",
        ),
        SetupCheck(
            "Pillow",
            health.pillow_ok,
            "Available" if health.pillow_ok else "Missing; install preview tools",
            "install_tools",
        ),
        SetupCheck(
            "ffmpeg",
            health.ffmpeg != "(not found)",
            health.ffmpeg if health.ffmpeg != "(not found)" else "Not found; install generator tools",
            "install_generator_tools",
        ),
    ]
    return tuple(checks)


def format_setup_report(checks: Iterable[SetupCheck]) -> str:
    """Format setup checks without exposing local credentials or VFS URLs."""
    lines = ["Trickplay setup checks:"]
    for check in checks:
        state = "OK" if check.ok else "ACTION NEEDED"
        lines.append(f"{state}: {check.name} — {check.detail}")
    return "\n".join(lines)


def current_skin_snippet_is_current() -> bool:
    """True when the active skin has a non-stale trickplay overlay."""
    return current_skin_overlay_installed()
