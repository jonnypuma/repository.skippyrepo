"""Tests for Skippy.Skipping clear on user scrub/OSD."""
from __future__ import annotations

import sys
import types
import unittest
from pathlib import Path
from unittest.mock import MagicMock, patch

ROOT = str(Path(__file__).resolve().parents[1])
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

for _name in ("xbmc", "xbmcaddon", "xbmcvfs", "xbmcgui"):
    sys.modules.setdefault(_name, types.ModuleType(_name))

sys.modules["xbmc"].LOGINFO = 1
sys.modules["xbmc"].LOGWARNING = 2
sys.modules["xbmc"].LOGERROR = 3
sys.modules["xbmc"].getCondVisibility = MagicMock(return_value=False)
sys.modules["xbmc"].getInfoLabel = MagicMock(return_value="")
sys.modules["xbmc"].executeJSONRPC = MagicMock(return_value="{}")
sys.modules["xbmc"].log = MagicMock()
sys.modules["xbmc"].Monitor = type("Monitor", (), {"__init__": lambda self: None})
sys.modules["xbmc"].Player = type("Player", (), {"__init__": lambda self, *a, **k: None})
sys.modules["xbmcvfs"].translatePath = lambda path: path
sys.modules["xbmcaddon"].Addon = MagicMock(
    return_value=MagicMock(
        getAddonInfo=MagicMock(return_value=ROOT),
        getSettingInt=MagicMock(return_value=100),
        getSettingString=MagicMock(return_value=""),
        getSettingBool=MagicMock(return_value=False),
        getLocalizedString=MagicMock(return_value=""),
    )
)
sys.modules["xbmcgui"].Window = MagicMock()
sys.modules["xbmcgui"].Dialog = MagicMock()

import service as trickplay_service  # noqa: E402


def _bind(svc, name: str):
    return getattr(trickplay_service.TrickplayService, name).__get__(
        svc, trickplay_service.TrickplayService
    )


class SkippySkippingClearTests(unittest.TestCase):
    def setUp(self) -> None:
        self.svc = MagicMock()
        self.svc._skippy_skipping_latched = False
        self.svc._skip_landing_second = -1
        self.svc._video_osd_visible = MagicMock(return_value=False)
        self.svc._seek_ui_visible = MagicMock(return_value=False)
        self.home = MagicMock()
        self.home.getProperty = MagicMock(return_value="true")
        self.home.clearProperty = MagicMock()
        for name in (
            "_skippy_skipping_set",
            "_clear_skippy_skipping",
            "_user_releases_skippy_hide",
            "_skippy_suppress_active",
        ):
            setattr(self.svc, name, _bind(self.svc, name))

    def test_landing_seek_keeps_skipping(self) -> None:
        self.svc._skip_landing_second = 26
        self.svc._skippy_skipping_latched = True
        with patch.object(
            trickplay_service.xbmc,
            "getCondVisibility",
            side_effect=lambda cond: "Skippy.Skipping" in cond,
        ):
            self.assertTrue(
                self.svc._skippy_suppress_active(scrubbing=True, target_second=26)
            )

    def test_later_seek_clears_skippy_skipping(self) -> None:
        self.svc._skip_landing_second = 26
        self.svc._skippy_skipping_latched = True
        with patch.object(
            trickplay_service, "HOME_WINDOW", self.home
        ), patch.object(
            trickplay_service, "clear_trickplay_property", MagicMock()
        ), patch.object(
            trickplay_service.xbmc,
            "getCondVisibility",
            side_effect=lambda cond: "Skippy.Skipping" in cond,
        ):
            self.assertFalse(
                self.svc._skippy_suppress_active(scrubbing=True, target_second=88)
            )
        self.home.clearProperty.assert_called_with("Skippy.Skipping")

    def test_video_osd_clears_skippy_skipping(self) -> None:
        self.svc._skip_landing_second = 26
        self.svc._skippy_skipping_latched = True
        self.svc._video_osd_visible.return_value = True
        with patch.object(
            trickplay_service, "HOME_WINDOW", self.home
        ), patch.object(
            trickplay_service, "clear_trickplay_property", MagicMock()
        ), patch.object(
            trickplay_service.xbmc,
            "getCondVisibility",
            side_effect=lambda cond: "Skippy.Skipping" in cond,
        ):
            self.assertFalse(self.svc._skippy_suppress_active(scrubbing=False))
        self.home.clearProperty.assert_called_with("Skippy.Skipping")


if __name__ == "__main__":
    unittest.main()
